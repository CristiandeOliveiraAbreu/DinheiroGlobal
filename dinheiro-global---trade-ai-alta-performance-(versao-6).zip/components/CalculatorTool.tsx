
import React, { useState } from 'react';
import { XIcon, CalculatorIcon } from './Icons';

interface CalculatorToolProps {
  onClose: () => void;
}

const CalculatorTool: React.FC<CalculatorToolProps> = ({ onClose }) => {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [isFinished, setIsFinished] = useState(false);

  const handleNumber = (num: string) => {
    if (display === '0' || isFinished) {
      setDisplay(num);
      setIsFinished(false);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOperator = (op: string) => {
    setEquation(display + ' ' + op + ' ');
    setDisplay('0');
    setIsFinished(false);
  };

  const calculate = () => {
    try {
      // Usando Function em vez de eval por segurança básica
      const result = new Function(`return ${equation + display}`)();
      setDisplay(String(Number(result.toFixed(4))));
      setEquation('');
      setIsFinished(true);
    } catch (e) {
      setDisplay('Erro');
    }
  };

  const clear = () => {
    setDisplay('0');
    setEquation('');
  };

  const buttons = [
    { label: 'C', action: clear, color: 'bg-rose-500/20 text-rose-400' },
    { label: '/', action: () => handleOperator('/'), color: 'bg-slate-800 text-indigo-400' },
    { label: '*', action: () => handleOperator('*'), color: 'bg-slate-800 text-indigo-400' },
    { label: '-', action: () => handleOperator('-'), color: 'bg-slate-800 text-indigo-400' },
    { label: '7', action: () => handleNumber('7') },
    { label: '8', action: () => handleNumber('8') },
    { label: '9', action: () => handleNumber('9') },
    { label: '+', action: () => handleOperator('+'), color: 'bg-slate-800 text-indigo-400', rowSpan: 2 },
    { label: '4', action: () => handleNumber('4') },
    { label: '5', action: () => handleNumber('5') },
    { label: '6', action: () => handleNumber('6') },
    { label: '1', action: () => handleNumber('1') },
    { label: '2', action: () => handleNumber('2') },
    { label: '3', action: () => handleNumber('3') },
    { label: '=', action: calculate, color: 'bg-emerald-600 text-white', rowSpan: 2 },
    { label: '0', action: () => handleNumber('0'), colSpan: 2 },
    { label: '.', action: () => handleNumber('.') },
  ];

  return (
    <div className="fixed bottom-24 right-12 z-[400] w-72 bg-slate-900 border border-emerald-500/30 rounded-[32px] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-10">
      <div className="p-4 bg-slate-800/50 flex justify-between items-center border-b border-slate-800">
        <div className="flex items-center gap-2 text-emerald-400">
          <CalculatorIcon size={14} />
          <span className="text-[10px] font-black uppercase tracking-widest">Suporte Tático</span>
        </div>
        <button onClick={onClose} className="p-1.5 hover:bg-slate-700 rounded-full text-slate-500 transition-colors">
          <XIcon size={14} />
        </button>
      </div>

      <div className="p-6 space-y-4">
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-right overflow-hidden">
          <div className="text-[9px] font-mono text-slate-600 h-4 uppercase tracking-tighter truncate">{equation}</div>
          <div className="text-2xl font-mono font-black text-emerald-400 tracking-tighter truncate">{display}</div>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {buttons.map((btn, i) => (
            <button
              key={i}
              onClick={btn.action}
              className={`
                h-12 rounded-xl text-xs font-black transition-all active:scale-90
                ${btn.color || 'bg-slate-800/50 text-slate-200 hover:bg-slate-700'}
                ${btn.colSpan === 2 ? 'col-span-2' : ''}
                ${btn.rowSpan === 2 ? 'row-span-2 h-auto' : ''}
              `}
            >
              {btn.label}
            </button>
          ))}
        </div>
      </div>
      
      <div className="bg-emerald-500/5 py-2 text-center border-t border-slate-800">
        <span className="text-[8px] font-bold text-slate-600 uppercase tracking-[0.3em]">Cálculo Institucional DG-AI</span>
      </div>
    </div>
  );
};

export default CalculatorTool;
