
import React, { useState, useEffect, useMemo } from 'react';
import { Trade, TradeType, TradeResult, CurrencyType, Asset, Broker } from '../types';
import { XIcon, DashboardIcon, CalculatorIcon } from './Icons';

interface TradeModalProps {
  onClose: () => void;
  onExitToDashboard?: () => void;
  onSave: (trade: Trade) => void;
  onOpenAssetManager?: () => void;
  editingTrade?: Trade;
  brokers: Broker[];
  defaultCapital: number;
  exchangeRate: number;
  registeredAssets?: Asset[];
}

// Fixed: Added missing onOpenAssetManager and defaultCapital to prop destructuring.
const TradeModal: React.FC<TradeModalProps> = ({ 
  onClose, 
  onExitToDashboard,
  onSave, 
  onOpenAssetManager,
  editingTrade, 
  brokers,
  defaultCapital,
  exchangeRate, 
  registeredAssets = [] 
}) => {
  const [asset, setAsset] = useState('');
  const [type, setType] = useState<TradeType>('Compra');
  const [currency, setCurrency] = useState<CurrencyType>('BRL');
  const [contracts, setContracts] = useState('1');
  const [entryPrice, setEntryPrice] = useState('');
  const [stopPrice, setStopPrice] = useState('');
  const [takeProfit, setTakeProfit] = useState('');
  const [result, setResult] = useState<TradeResult>('Pendente');
  const [brokerId, setBrokerId] = useState('');
  const [loading, setLoading] = useState(false);
  
  const [ptValue, setPtValue] = useState('1.00');
  const [assetCategory, setAssetCategory] = useState<'Ações/FII' | 'CI'>('Ações/FII');

  useEffect(() => {
    if (editingTrade) {
      setAsset(editingTrade.asset);
      setType(editingTrade.type);
      setCurrency(editingTrade.currency || 'BRL');
      setContracts(editingTrade.contracts.toString());
      setEntryPrice(editingTrade.entryPrice.toString());
      setStopPrice(editingTrade.stopPrice.toString());
      setTakeProfit(editingTrade.takeProfit?.toString() || '');
      setResult(editingTrade.result);
      setBrokerId(editingTrade.brokerId || '');
      
      const found = registeredAssets.find(a => a.name === editingTrade.asset);
      if (found) {
        setPtValue(found.point_value.toString());
        setAssetCategory(found.category);
      }
    }
  }, [editingTrade, registeredAssets]);

  const orderSummary = useMemo(() => {
    const entry = parseFloat(entryPrice) || 0;
    const stop = parseFloat(stopPrice) || 0;
    const target = parseFloat(takeProfit) || 0;
    const lote = parseFloat(contracts) || 0;
    const pointValRaw = assetCategory === 'Ações/FII' ? 1 : (parseFloat(ptValue) || 1);
    const pointValBRL = currency === 'USD' ? pointValRaw * exchangeRate : pointValRaw;
    
    // Distâncias em pontos absolutos
    const stopPts = entry > 0 && stop > 0 ? Math.abs(entry - stop) : 0;
    const targetPts = entry > 0 && target > 0 ? Math.abs(target - entry) : 0;
    
    // Risco e Retorno em valor financeiro
    const riskVal = stopPts * lote * pointValBRL;
    const gainVal = targetPts * lote * pointValBRL;
    
    const rr = stopPts > 0 ? (targetPts / stopPts).toFixed(2) : '0';
    return { riskVal, gainVal, rr };
  }, [entryPrice, stopPrice, takeProfit, contracts, ptValue, currency, assetCategory, exchangeRate]);

  const onFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!asset || !entryPrice || !stopPrice || !brokerId || loading) return;

    setLoading(true);
    try {
      const tradePayload: any = {
        asset: asset.trim().toUpperCase(),
        type,
        currency,
        contracts: parseFloat(contracts),
        entryPrice: parseFloat(entryPrice),
        stopPrice: parseFloat(stopPrice),
        takeProfit: parseFloat(takeProfit) || 0,
        initialStopPrice: editingTrade?.initialStopPrice || parseFloat(stopPrice),
        guarantee: orderSummary.riskVal,
        result,
        profit: editingTrade?.profit || 0,
        brokerId,
        date: editingTrade?.date || new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }),
        timestamp: editingTrade?.timestamp || Date.now(),
        archived: editingTrade?.archived || false,
      };
      if (editingTrade?.id) tradePayload.id = editingTrade.id;
      
      onSave(tradePayload);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl" onClick={onClose}></div>
      <div className="relative bg-[#0f1421] border border-slate-800 w-full max-w-4xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="px-10 py-8 flex justify-between items-center">
          <h2 className="text-2xl font-black uppercase tracking-widest text-white">
            {editingTrade ? 'Revisar Ordem' : 'Abertura de Operação'}
          </h2>
          <div className="flex gap-2">
            {onExitToDashboard && (
              <button type="button" onClick={onExitToDashboard} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-500 hover:text-white" title="Dashboard">
                <DashboardIcon size={24}/>
              </button>
            )}
            <button type="button" onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-500 hover:text-white">
              <XIcon size={24}/>
            </button>
          </div>
        </div>
        
        <form onSubmit={onFormSubmit} className="p-10 pt-0 space-y-10 overflow-y-auto custom-scrollbar flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            
            {/* Coluna Esquerda: Configuração */}
            <div className="space-y-8">
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Instituição de Execução</label>
                  <div className="relative">
                    <select 
                      value={brokerId} 
                      onChange={e => setBrokerId(e.target.value)} 
                      className="w-full bg-[#090d16] border border-slate-800 rounded-[20px] p-5 text-sm font-black text-white outline-none appearance-none focus:border-emerald-500/50 transition-colors" 
                      required
                    >
                      <option value="">SELECIONAR CORRETORA...</option>
                      {brokers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                    <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                    </div>
                  </div>
               </div>

               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Ativo Operado</label>
                  <div className="relative">
                    <select 
                      value={asset} 
                      onChange={(e) => {
                        const val = e.target.value;
                        setAsset(val);
                        const found = registeredAssets.find(a => a.name === val);
                        if (found) { 
                          setPtValue(found.point_value.toString());
                          setAssetCategory(found.category);
                          setCurrency(found.currency);
                        }
                      }} 
                      className="w-full bg-[#090d16] border border-slate-800 rounded-[20px] p-5 text-sm font-black text-white outline-none appearance-none focus:border-emerald-500/50 transition-colors" 
                      required
                    >
                      <option value="">BUSCAR ATIVO NA LISTA...</option>
                      {registeredAssets.map(a => <option key={a.id} value={a.name}>{a.name}</option>)}
                    </select>
                    <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                    </div>
                  </div>
                  {onOpenAssetManager && (
                    <button type="button" onClick={onOpenAssetManager} className="text-[9px] font-black text-emerald-500 hover:text-white uppercase tracking-widest mt-2 flex items-center gap-1 transition-colors">
                      + Gerenciar Biblioteca de Ativos
                    </button>
                  )}
               </div>

               <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Tipo de Ordem</label>
                    <div className="grid grid-cols-2 gap-2 bg-[#090d16] p-1 rounded-2xl border border-slate-800">
                      <button type="button" onClick={() => setType('Compra')} className={`py-3 rounded-xl text-[10px] font-black transition-all ${type === 'Compra' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500'}`}>COMPRA</button>
                      <button type="button" onClick={() => setType('Venda')} className={`py-3 rounded-xl text-[10px] font-black transition-all ${type === 'Venda' ? 'bg-rose-600 text-white shadow-lg' : 'text-slate-500'}`}>VENDA</button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Lote / Contratos</label>
                    <input type="number" step="any" value={contracts} onChange={e => setContracts(e.target.value)} className="w-full bg-[#090d16] border border-slate-800 rounded-[20px] p-5 text-sm font-black text-white outline-none focus:border-emerald-500/50 transition-colors" required />
                  </div>
               </div>
            </div>

            {/* Coluna Direita: Preços e Alvos */}
            <div className="space-y-8">
               <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Preço de Entrada</label>
                    <input type="number" step="any" value={entryPrice} onChange={e => setEntryPrice(e.target.value)} className="w-full bg-[#090d16] border border-slate-800 rounded-[20px] p-5 text-sm font-black text-white outline-none focus:border-emerald-500/50 transition-colors" placeholder="0.00" required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 text-rose-500">Stop Loss (Risco)</label>
                    <input type="number" step="any" value={stopPrice} onChange={e => setStopPrice(e.target.value)} className="w-full bg-[#090d16] border border-rose-900/30 rounded-[20px] p-5 text-sm font-black text-white outline-none focus:border-rose-500/50 transition-colors" placeholder="0.00" required />
                  </div>
               </div>

               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 text-emerald-500">Take Profit (Alvo)</label>
                  <input type="number" step="any" value={takeProfit} onChange={e => setTakeProfit(e.target.value)} className="w-full bg-[#090d16] border border-emerald-900/30 rounded-[20px] p-5 text-sm font-black text-white outline-none focus:border-emerald-500/50 transition-colors" placeholder="0.00" />
               </div>

               <div className="bg-[#0c101a] border border-slate-800/50 p-8 rounded-[32px] space-y-6">
                  <div className="flex justify-between items-center">
                    <div className="space-y-1">
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Risco Estimado</p>
                      <p className="text-xl font-mono font-black text-rose-500">
                        {currency === 'USD' ? '$' : 'R$'} {orderSummary.riskVal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </p>
                    </div>
                    <div className="text-right space-y-1">
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Alvo Estimado</p>
                      <p className="text-xl font-mono font-black text-emerald-500">
                        {currency === 'USD' ? '$' : 'R$'} {orderSummary.gainVal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </p>
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-800/50 flex justify-between items-center">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                      <CalculatorIcon size={12} /> Relação Risco:Retorno
                    </p>
                    <p className={`text-sm font-black ${parseFloat(orderSummary.rr) >= 2 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      1 : {orderSummary.rr}
                    </p>
                  </div>
               </div>
            </div>
          </div>

          <div className="pt-10 flex flex-col md:flex-row gap-4">
             <button type="button" onClick={onClose} className="flex-1 py-5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-[24px] font-black uppercase text-xs tracking-widest transition-all">
               Descartar
             </button>
             <button 
              type="submit" 
              disabled={loading}
              className="flex-[2] py-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-[24px] font-black uppercase text-xs tracking-[0.2em] transition-all shadow-xl shadow-emerald-600/20 flex items-center justify-center gap-3 active:scale-[0.98]"
             >
               {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : (editingTrade ? 'Atualizar Ordem' : 'Efetivar Ordem')}
             </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TradeModal;
