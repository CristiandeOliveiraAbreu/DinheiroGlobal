
import React, { useState, useMemo } from 'react';
import { Trade, Asset, ExtraIncome, Contribution } from '../types';
import { CheckIcon, ArchiveIcon, PlusIcon, ActivityIcon, BriefcaseIcon, TargetIcon, WalletIcon, EditIcon, TrashIcon, XIcon, CalculatorIcon, MoneyIcon } from './Icons';
import CalculatorTool from './CalculatorTool';
import ProtectionPanel from './ProtectionPanel';

interface HistoryProps {
  trades: Trade[];
  extraIncomes: ExtraIncome[];
  contributions: Contribution[];
  onEdit: (trade: Trade) => void;
  onDelete: (id: string) => void;
  onDeleteAsset?: (assetName: string) => void;
  onArchive: (id: string) => void;
  onUpdateStop?: (id: string, newStop: number) => void;
  onAddIncome: (assetName: string) => void;
  onFinishTrade?: (trade: Trade) => void;
  registeredAssets?: Asset[];
  exchangeRate: number;
  totalEquityBRL: number;
}

const History: React.FC<HistoryProps> = ({ 
  trades, 
  extraIncomes, 
  contributions,
  onEdit, 
  onDelete,
  onDeleteAsset,
  onArchive, 
  onUpdateStop, 
  onAddIncome,
  onFinishTrade,
  registeredAssets = [],
  exchangeRate,
  totalEquityBRL
}) => {
  const [activeTab, setActiveTab] = useState<'CI' | 'INVEST'>('CI');
  const [editingStopId, setEditingStopId] = useState<string | null>(null);
  const [tempStop, setTempStop] = useState<string>('');
  const [selectedTradesDetail, setSelectedTradesDetail] = useState<string | null>(null);
  const [selectedIncomeDetail, setSelectedIncomeDetail] = useState<string | null>(null);
  const [showCalculator, setShowCalculator] = useState(false);

  const visibleTrades = useMemo(() => trades.filter(t => !t.archived), [trades]);

  // Cálculo do Capital Disponível (Caixa livre nas corretoras)
  const availableCapitalBRL = useMemo(() => {
    // 1. Saldo de movimentações (Aportes - Saques + Proventos)
    const cashMovementsBRL = contributions.reduce((sum, c) => {
      const val = c.currency === 'USD' ? Number(c.amount) * exchangeRate : Number(c.amount);
      const costVal = (c.costs || 0) * (c.currency === 'USD' ? exchangeRate : 1);
      if (c.type === 'Retirada' || c.type === 'Custo') return sum - (val + costVal);
      return sum + val;
    }, 0);

    // 2. Resultado Realizado de Trades
    const realizedProfitBRL = trades
      .filter(t => t.result !== 'Pendente')
      .reduce((sum, t) => sum + (t.currency === 'USD' ? Number(t.profit) * exchangeRate : Number(t.profit)), 0);

    // 3. Valor Investido em Ativos Abertos (Custo de Entrada)
    const openTradesInvestedBRL = trades
      .filter(t => t.result === 'Pendente' && t.type === 'Compra')
      .reduce((sum, t) => {
        const cost = Number(t.contracts) * Number(t.entryPrice);
        return sum + (t.currency === 'USD' ? cost * exchangeRate : cost);
      }, 0);

    return (cashMovementsBRL + realizedProfitBRL) - openTradesInvestedBRL;
  }, [contributions, trades, exchangeRate]);

  const ciTrades = useMemo(() => {
    return visibleTrades.filter(t => {
      const assetInfo = registeredAssets.find(a => a.name.toUpperCase() === t.asset.toUpperCase());
      return assetInfo?.category !== 'Ações/FII' && t.result === 'Pendente';
    });
  }, [visibleTrades, registeredAssets]);

  const investGroups = useMemo(() => {
    const groups: Record<string, { 
      trades: Trade[], 
      totalQty: number, 
      totalCostBRL: number,
      latestTrade: Trade 
    }> = {};

    visibleTrades.forEach(t => {
      const assetKey = t.asset.toUpperCase();
      const assetInfo = registeredAssets.find(a => a.name.toUpperCase() === assetKey);
      
      if (assetInfo?.category === 'Ações/FII') {
        if (!groups[assetKey]) {
          groups[assetKey] = { trades: [], totalQty: 0, totalCostBRL: 0, latestTrade: t };
        }
        
        if (t.type === 'Compra') {
          const qty = Number(t.contracts);
          const price = Number(t.entryPrice);
          const operationCost = qty * price;
          
          groups[assetKey].totalQty += qty;
          groups[assetKey].totalCostBRL += (t.currency === 'USD' ? operationCost * exchangeRate : operationCost);
        }
        
        if (t.timestamp > groups[assetKey].latestTrade.timestamp) {
          groups[assetKey].latestTrade = t;
        }
        groups[assetKey].trades.push(t);
      }
    });

    return Object.entries(groups).map(([name, data]) => {
      const incomes = extraIncomes.filter(i => i.assetName.toUpperCase() === name.toUpperCase());
      const totalIncomesBRL = incomes.reduce((sum, i) => {
        const amount = Number(i.amount);
        return sum + (i.currency === 'USD' ? amount * exchangeRate : amount);
      }, 0);

      const netInvestmentBRL = data.totalCostBRL - totalIncomesBRL;
      const avgPriceGross = data.totalQty > 0 ? data.totalCostBRL / data.totalQty : 0;
      const avgPriceAdjusted = data.totalQty > 0 ? netInvestmentBRL / data.totalQty : 0;
      
      const isProtected = data.latestTrade.stopPrice > avgPriceAdjusted;
      const protectedEquity = (data.latestTrade.stopPrice * data.totalQty) + totalIncomesBRL;
      const profitAtStop = protectedEquity - data.totalCostBRL;

      return {
        name,
        totalQty: data.totalQty,
        totalCostBRL: data.totalCostBRL,
        netInvestmentBRL,
        avgPriceGross,
        avgPriceAdjusted,
        totalIncomesBRL,
        isProtected,
        protectedEquity,
        profitAtStop,
        latestTrade: data.latestTrade,
        allBuyTrades: data.trades.filter(t => t.type === 'Compra' && t.result === 'Pendente')
      };
    });
  }, [visibleTrades, registeredAssets, extraIncomes, exchangeRate]);

  const handleStopEdit = (trade: Trade) => {
    setEditingStopId(trade.id);
    setTempStop(trade.stopPrice.toString());
  };

  const saveStopUpdate = (id: string) => {
    if (onUpdateStop && tempStop !== '') {
      onUpdateStop(id, parseFloat(tempStop));
    }
    setEditingStopId(null);
  };

  const calculateCIRiskStatus = (trade: Trade) => {
    const assetConfig = registeredAssets.find(a => a.name.toUpperCase() === trade.asset.toUpperCase());
    const ptVal = assetConfig?.point_value || 1;
    const dist = trade.type === 'Compra' ? trade.stopPrice - trade.entryPrice : trade.entryPrice - trade.stopPrice;
    const riskValue = ptVal * trade.contracts * dist;
    const valueBRL = trade.currency === 'USD' ? riskValue * exchangeRate : riskValue;
    return { value: valueBRL, isPositive: valueBRL > 0 };
  };

  const calculateCITargetGain = (trade: Trade) => {
    if (!trade.takeProfit || trade.takeProfit === 0) return null;
    const assetConfig = registeredAssets.find(a => a.name.toUpperCase() === trade.asset.toUpperCase());
    const ptVal = assetConfig?.point_value || 1;
    const dist = Math.abs(trade.takeProfit - trade.entryPrice);
    const gainValue = ptVal * trade.contracts * dist;
    return trade.currency === 'USD' ? gainValue * exchangeRate : gainValue;
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 relative">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight uppercase">Monitoramento Tático</h1>
          <p className="text-slate-400 mt-1 font-medium">Gestão de ordens ativas e acompanhamento de custódia.</p>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setShowCalculator(!showCalculator)} className={`p-4 rounded-2xl border transition-all ${showCalculator ? 'bg-emerald-600 border-emerald-500 text-white shadow-lg' : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-white'}`} title="Abrir Calculadora"><CalculatorIcon size={20} /></button>
          <div className="flex bg-slate-900 p-1 rounded-2xl border border-slate-800">
            <button onClick={() => setActiveTab('CI')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'CI' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}><ActivityIcon size={14} /> CI</button>
            <button onClick={() => setActiveTab('INVEST')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'INVEST' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}><BriefcaseIcon size={14} /> Ações/FII</button>
          </div>
        </div>
      </header>

      {/* Painel de Proteção e Risco */}
      <ProtectionPanel 
        openTrades={visibleTrades.filter(t => t.result === 'Pendente')}
        assets={registeredAssets}
        exchangeRate={exchangeRate}
        totalEquityBRL={totalEquityBRL}
        availableCapitalBRL={availableCapitalBRL}
      />

      {showCalculator && <CalculatorTool onClose={() => setShowCalculator(false)} />}

      <div className="bg-slate-900 border border-slate-800 rounded-[40px] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-800/20 border-b border-slate-800 text-[10px] font-black text-slate-500 uppercase tracking-widest">
                <th className="px-8 py-6">Ativo / Qtd</th>
                {activeTab === 'CI' ? (
                  <>
                    <th className="px-8 py-6">Execução</th>
                    <th className="px-8 py-6">Trailing Stop</th>
                    <th className="px-8 py-6">Alvo</th>
                    <th className="px-8 py-6">Est. Alvo</th>
                    <th className="px-8 py-6">Risco</th>
                    <th className="px-8 py-6 text-right">Ações</th>
                  </>
                ) : (
                  <>
                    <th className="px-8 py-6">Bruto / PM</th>
                    <th className="px-8 py-6">Líquido / PM Aj.</th>
                    <th className="px-8 py-6">Proventos</th>
                    <th className="px-8 py-6">Proteção</th>
                    <th className="px-8 py-6">Patrimônio</th>
                    <th className="px-8 py-6">Lucro/Prejuízo</th>
                    <th className="px-8 py-6 text-right">Ações</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {activeTab === 'CI' ? (
                ciTrades.length === 0 ? <NoTradesMsg activeTab={activeTab} /> : ciTrades.map(trade => {
                  const riskStatus = calculateCIRiskStatus(trade);
                  const targetGain = calculateCITargetGain(trade);
                  return (
                    <tr key={trade.id} className="group hover:bg-slate-800/10 transition-colors">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full ${trade.type === 'Compra' ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.5)]'}`}></div>
                          <span className="font-black text-white text-lg tracking-tighter">{trade.asset}</span>
                        </div>
                        <div className="text-[9px] text-slate-500 uppercase mt-1 font-bold tracking-widest">{trade.date}</div>
                      </td>
                      <td className="px-8 py-6">
                        <span className="text-sm font-mono font-black text-slate-200">{trade.entryPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                      </td>
                      <td className="px-8 py-6">
                        {editingStopId === trade.id ? (
                          <input autoFocus type="number" className="bg-slate-950 border border-indigo-500 rounded-xl px-3 py-2 text-xs w-28 text-white outline-none font-mono" value={tempStop} onChange={e => setTempStop(e.target.value)} onBlur={() => saveStopUpdate(trade.id)} />
                        ) : (
                          <span className="cursor-pointer font-mono text-sm font-bold border-b border-dashed border-slate-700 text-slate-300" onClick={() => handleStopEdit(trade)}>{trade.stopPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                        )}
                      </td>
                      <td className="px-8 py-6 font-mono text-sm text-emerald-500/50">{trade.takeProfit > 0 ? trade.takeProfit.toLocaleString(undefined, { minimumFractionDigits: 2 }) : '--'}</td>
                      <td className="px-8 py-6">
                        {targetGain !== null ? <span className="text-xs font-mono font-black text-emerald-400">R$ {targetGain.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span> : '--'}
                      </td>
                      <td className="px-8 py-6">
                        <div className={`text-[10px] font-black px-4 py-2 rounded-full inline-flex items-center gap-2 ${riskStatus.isPositive ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' : 'text-rose-400 bg-rose-500/10 border-rose-500/20'}`}>
                          R$ {Math.abs(riskStatus.value).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => onFinishTrade?.(trade)} className="p-3 bg-emerald-600/20 rounded-xl text-emerald-400 hover:bg-emerald-600 hover:text-white transition-all"><CheckIcon size={14}/></button>
                          <button onClick={() => onEdit(trade)} className="p-3 bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all"><EditIcon size={14}/></button>
                          <button onClick={() => onArchive(trade.id)} className="p-3 bg-indigo-900/10 rounded-xl text-indigo-400 transition-all"><ArchiveIcon size={14}/></button>
                          <button onClick={() => { if(window.confirm('Excluir ordem permanentemente?')) onDelete(trade.id) }} className="p-3 bg-rose-900/10 rounded-xl text-rose-500 transition-all"><TrashIcon size={14}/></button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                investGroups.length === 0 ? <NoTradesMsg activeTab={activeTab} /> : investGroups.map(group => (
                  <tr key={group.name} className="group hover:bg-slate-800/10 transition-colors">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                        <span className="font-black text-white text-lg tracking-tighter">{group.name}</span>
                      </div>
                      <div className="text-[9px] text-slate-500 uppercase mt-1 font-bold">{group.totalQty.toLocaleString()} Unidades</div>
                    </td>
                    <td className="px-8 py-6">
                      <p className="text-sm font-mono font-black text-slate-200">R$ {group.totalCostBRL.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                      <button onClick={() => setSelectedTradesDetail(group.name)} className="text-[8px] font-black text-emerald-500 uppercase tracking-tighter underline">Notas de Compra</button>
                    </td>
                    <td className="px-8 py-6">
                      <span className="text-sm font-mono font-black text-emerald-400">R$ {group.netInvestmentBRL.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                    </td>
                    <td className="px-8 py-6">
                      <button onClick={() => setSelectedIncomeDetail(group.name)} className="text-sm font-mono font-black text-indigo-400 underline decoration-indigo-500/30">R$ {group.totalIncomesBRL.toLocaleString(undefined, { minimumFractionDigits: 2 })}</button>
                    </td>
                    <td className="px-8 py-6">
                      <span className="font-mono text-sm font-bold text-slate-300">{group.latestTrade.stopPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                    </td>
                    <td className="px-8 py-6">
                       <span className={`text-xs font-mono font-black ${group.isProtected ? 'text-emerald-400' : 'text-slate-500'}`}>
                         {group.isProtected ? `R$ ${group.protectedEquity.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : 'SEM PROTEÇÃO'}
                       </span>
                    </td>
                    <td className="px-8 py-6">
                       <span className={`text-xs font-mono font-black ${group.profitAtStop >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                         R$ {group.profitAtStop.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                       </span>
                    </td>
                    <td className="px-8 py-6 text-right">
                       <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button onClick={() => onFinishTrade?.(group.latestTrade)} className="p-3 bg-emerald-600/20 rounded-xl text-emerald-400 hover:bg-emerald-600 hover:text-white transition-all"><CheckIcon size={14}/></button>
                         <button onClick={() => onAddIncome(group.name)} className="p-3 bg-indigo-900/10 rounded-xl text-indigo-400 transition-all"><WalletIcon size={14}/></button>
                         <button onClick={() => onEdit(group.latestTrade)} className="p-3 bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all"><EditIcon size={14}/></button>
                         <button onClick={() => { if(window.confirm(`Excluir todas as ordens e notas de ${group.name}?`)) onDeleteAsset?.(group.name) }} className="p-3 bg-rose-900/10 rounded-xl text-rose-500 transition-all"><TrashIcon size={14}/></button>
                       </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {selectedIncomeDetail && (
        <DetailModal title={`Proventos: ${selectedIncomeDetail}`} onClose={() => setSelectedIncomeDetail(null)}>
          <div className="space-y-4">
            {extraIncomes.filter(i => i.assetName.toUpperCase() === selectedIncomeDetail.toUpperCase()).map((inc, idx) => (
              <div key={idx} className="flex justify-between items-center p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <p className="text-[10px] font-black text-slate-500 uppercase">{inc.date} • {inc.type}</p>
                <p className="text-sm font-mono font-black text-emerald-400">R$ {Number(inc.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
              </div>
            ))}
          </div>
        </DetailModal>
      )}

      {selectedTradesDetail && (
        <DetailModal title={`Notas: ${selectedTradesDetail}`} onClose={() => setSelectedTradesDetail(null)}>
          <div className="space-y-4">
             {visibleTrades.filter(t => t.asset.toUpperCase() === selectedTradesDetail.toUpperCase() && t.type === 'Compra').map((trade, idx) => (
               <div key={idx} className="flex justify-between items-center p-5 bg-slate-950 rounded-3xl border border-slate-800">
                 <div>
                    <p className="text-[10px] font-black text-slate-500 uppercase">{trade.date} • {trade.contracts.toLocaleString()} UNID.</p>
                    <p className="text-sm font-black text-white">Preço: R$ {trade.entryPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                 </div>
                 <button onClick={() => { if(window.confirm('Excluir esta nota de compra específica?')) onDelete(trade.id) }} className="p-3 text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all"><TrashIcon size={16}/></button>
               </div>
             ))}
          </div>
        </DetailModal>
      )}
    </div>
  );
};

const DetailModal: React.FC<{ title: string, onClose: () => void, children: React.ReactNode }> = ({ title, onClose, children }) => (
  <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
    <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl" onClick={onClose}></div>
    <div className="relative bg-slate-900 border border-slate-800 w-full max-w-lg rounded-[40px] shadow-2xl p-10">
      <div className="flex justify-between items-center mb-8">
        <h3 className="text-xl font-black uppercase">{title}</h3>
        <button onClick={onClose} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-full text-slate-500 hover:text-white"><XIcon size={20}/></button>
      </div>
      <div className="max-h-[60vh] overflow-y-auto custom-scrollbar">{children}</div>
    </div>
  </div>
);

const NoTradesMsg = ({ activeTab }: { activeTab: 'CI' | 'INVEST' }) => (
  <tr><td colSpan={8} className="px-8 py-20 text-center opacity-20"><TargetIcon size={48} className="mx-auto mb-4" /><p className="text-[10px] font-black uppercase">Nenhum registro ativo</p></td></tr>
);

export default History;
