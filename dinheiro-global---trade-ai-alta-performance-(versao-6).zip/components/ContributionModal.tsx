
import React, { useState } from 'react';
import { Contribution, CurrencyType } from '../types';
import { XIcon, WalletIcon } from './Icons';

interface ContributionModalProps {
  onClose: () => void;
  onSave: (contribution: Contribution) => void;
  defaultType: 'Inicial' | 'Adicional';
}

const ContributionModal: React.FC<ContributionModalProps> = ({ onClose, onSave, defaultType }) => {
  const [amount, setAmount] = useState('');
  const [broker, setBroker] = useState('');
  const [currency, setCurrency] = useState<CurrencyType>('BRL');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0 || !broker || loading) return;

    setLoading(true);
    try {
      const newContribution: Contribution = {
        id: Math.random().toString(36).substr(2, 9),
        amount: parseFloat(amount),
        currency,
        type: defaultType,
        brokerId: broker.trim().toUpperCase(),
        date: new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }),
        timestamp: Date.now()
      };

      await onSave(newContribution);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose}></div>
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-md rounded-[32px] shadow-2xl overflow-hidden animate-in zoom-in-95 fade-in duration-300">
        <div className="px-8 py-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
          <div className="flex items-center gap-3">
            <WalletIcon className="text-blue-400" />
            <h2 className="text-xl font-bold uppercase tracking-tight">{defaultType === 'Inicial' ? 'Capital Inicial' : 'Novo Aporte'}</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-700 rounded-full transition-colors"><XIcon size={20} className="text-slate-400" /></button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Moeda de Lançamento</label>
              <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-2xl border border-slate-800">
                <button type="button" onClick={() => setCurrency('USD')} className={`py-3 rounded-xl text-[10px] font-black transition-all ${currency === 'USD' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}>USD ($)</button>
                <button type="button" onClick={() => setCurrency('BRL')} className={`py-3 rounded-xl text-[10px] font-black transition-all ${currency === 'BRL' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}>BRL (R$)</button>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Instituição Vinculada</label>
              <input autoFocus type="text" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white outline-none focus:ring-2 focus:ring-blue-500/40 font-black uppercase tracking-widest text-sm" placeholder="Ex: Binance, XP, BTG..." value={broker} onChange={e => setBroker(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Valor Financeiro</label>
              <input type="number" step="any" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white text-2xl font-mono focus:ring-2 focus:ring-blue-500/40 outline-none font-black" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} required />
            </div>
          </div>
          <button type="submit" disabled={loading} className="w-full bg-blue-600 hover:bg-blue-500 py-4 rounded-2xl font-black uppercase tracking-widest text-sm shadow-lg active:scale-95 transition-all flex items-center justify-center">
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Confirmar Registro'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ContributionModal;
