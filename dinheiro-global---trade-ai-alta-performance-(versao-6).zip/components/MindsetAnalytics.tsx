
import React, { useMemo } from 'react';
import { DiaryEntry } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, PieChart, Pie, LabelList, ReferenceLine } from 'recharts';
import { BrainIcon, TargetIcon, ActivityIcon, CheckIcon, AlertIcon } from './Icons';

interface MindsetAnalyticsProps {
  entries: DiaryEntry[];
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];
const FEELING_COLORS: Record<string, string> = {
  Disciplinado: '#10b981',
  Indiferente: '#64748b',
  Eufórico: '#f59e0b',
  Frustrado: '#ef4444',
  Esgotado: '#8b5cf6'
};

const SESSION_SHORT: Record<string, string> = {
  'Madrugada (24h até 5h)': 'MAD',
  'Manhã (5h até 12h)': 'MAN',
  'Tarde (12h até 18h)': 'TAR',
  'Noite (18h até 24h)': 'NOI'
};

const MindsetAnalytics: React.FC<MindsetAnalyticsProps> = ({ entries }) => {
  const stats = useMemo(() => {
    if (entries.length === 0) return null;
    
    const disciplineRate = (entries.filter(e => e.objectiveReached).length / entries.length) * 100;
    const emotionalStability = (entries.filter(e => e.emotionalAudit).length / entries.length) * 100;
    const strategicSuccess = (entries.filter(e => e.strategicAudit).length / entries.length) * 100;
    
    const moodImpact: Record<string, { count: number, success: number }> = {
      Calmo: { count: 0, success: 0 },
      Ansioso: { count: 0, success: 0 },
      Eufórico: { count: 0, success: 0 },
      Frustrado: { count: 0, success: 0 }
    };

    const feelingDistribution: Record<string, number> = {
      Disciplinado: 0,
      Indiferente: 0,
      Eufórico: 0,
      Frustrado: 0,
      Esgotado: 0
    };

    entries.forEach(e => {
      if (moodImpact[e.emotionalState]) {
        moodImpact[e.emotionalState].count++;
        if (e.objectiveReached) moodImpact[e.emotionalState].success++;
      }
      if (e.postSessionFeeling && feelingDistribution[e.postSessionFeeling] !== undefined) {
        feelingDistribution[e.postSessionFeeling]++;
      }
    });

    const moodData = Object.entries(moodImpact)
      .filter(([_, val]) => val.count > 0)
      .map(([name, val], index) => ({
        name: `${name.toUpperCase()} (${val.count})`,
        taxa: (val.success / val.count) * 100,
        raw: val,
        color: COLORS[index % COLORS.length]
      }));

    const feelingData = Object.entries(feelingDistribution)
      .filter(([_, value]) => value > 0)
      .map(([name, value]) => ({ name, value }));

    const chartData = [...entries]
      .sort((a, b) => a.timestamp - b.timestamp)
      .slice(-20)
      .map(e => {
        const score = (Number(e.objectiveReached) + Number(e.emotionalAudit) + Number(e.strategicAudit) + Number(e.financialAudit)) * 25;
        let status = "Regular";
        if (score >= 75) status = "Excelente";
        else if (score >= 50) status = "Atenção";
        else status = "Crítico";

        const shortDate = e.date.split('/')[0] + '/' + e.date.split('/')[1];
        const shortSession = SESSION_SHORT[e.session] || '';

        return {
          label: `${shortDate} ${shortSession}`,
          fullSession: e.session,
          score,
          status
        };
      });

    const recentFeelings = entries.slice(-3).map(e => e.postSessionFeeling);
    const hasHangoverRisk = recentFeelings.length >= 3 && recentFeelings.every(f => f === 'Frustrado' || f === 'Esgotado');

    return { disciplineRate, emotionalStability, strategicSuccess, moodData, feelingData, chartData, hasHangoverRisk };
  }, [entries]);

  if (!stats) return <div className="py-20 text-center text-slate-500 uppercase font-black text-[10px] tracking-widest">Aguardando fluxo de dados para gerar inteligência...</div>;

  return (
    <div className="space-y-10 animate-in fade-in zoom-in-95 duration-700 pb-12">
      
      {stats.hasHangoverRisk && (
        <div className="bg-rose-500/10 border border-rose-500/20 p-6 rounded-[32px] flex items-center gap-6 animate-pulse">
           <div className="w-12 h-12 bg-rose-500/20 rounded-2xl flex items-center justify-center text-rose-500">
             <AlertIcon size={24} />
           </div>
           <div>
             <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Alerta de Ressaca Operacional</p>
             <p className="text-sm font-medium text-slate-300">Detectamos recorrência de exaustão ou frustração pós-sessão. Recomenda-se pausa de 24h para restauração mental.</p>
           </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard label="Aderência ao Plano" value={`${stats.disciplineRate.toFixed(1)}%`} icon={<TargetIcon className="text-emerald-500"/>} color="text-emerald-400" />
        <StatCard label="Estabilidade Mental" value={`${stats.emotionalStability.toFixed(1)}%`} icon={<BrainIcon className="text-indigo-400"/>} color="text-indigo-400" />
        <StatCard label="Consistência Estratégica" value={`${stats.strategicSuccess.toFixed(1)}%`} icon={<CheckIcon className="text-blue-400"/>} color="text-blue-400" />
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-[40px] p-8 shadow-2xl">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-3">
               <ActivityIcon className="text-emerald-500" /> Evolução Cronológica do Rigor Técnico
            </h3>
            <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Sessão / Rigor</span>
          </div>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.chartData}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                    <stop offset="50%" stopColor="#f59e0b" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} opacity={0.3} />
                <XAxis dataKey="label" stroke="#475569" fontSize={9} axisLine={false} tickLine={false} />
                <YAxis stroke="#475569" fontSize={10} axisLine={false} tickLine={false} domain={[0, 100]} ticks={[0, 25, 50, 75, 100]} />
                <Tooltip 
                  labelStyle={{ color: '#f8fafc', fontWeight: '800', textTransform: 'uppercase', fontSize: '10px' }}
                  itemStyle={{ color: '#fff', fontSize: '11px' }}
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }} 
                  formatter={(value: number, name: string, props: any) => {
                    return [
                      `${value}% (${props.payload.status})`, 
                      `Rigor: ${props.payload.fullSession}`
                    ];
                  }}
                />
                <ReferenceLine y={75} stroke="#10b981" strokeDasharray="3 3" opacity={0.5} label={{ position: 'right', value: 'ELITE', fill: '#10b981', fontSize: 8, fontWeight: 900 }} />
                <ReferenceLine y={50} stroke="#f59e0b" strokeDasharray="3 3" opacity={0.5} label={{ position: 'right', value: 'ALERTA', fill: '#f59e0b', fontSize: 8, fontWeight: 900 }} />
                <Area type="monotone" dataKey="score" stroke="#10b981" strokeWidth={3} fill="url(#colorScore)" animationDuration={1500} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-6 pt-6 border-t border-slate-800/50">
             <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                   <span className="text-[9px] font-black text-white uppercase tracking-widest">75-100% Elite</span>
                </div>
                <p className="text-[8px] text-slate-500 uppercase font-bold">Foco institucional. técnica plena.</p>
             </div>
             <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-amber-500"></div>
                   <span className="text-[9px] font-black text-white uppercase tracking-widest">50-74% Atenção</span>
                </div>
                <p className="text-[8px] text-slate-500 uppercase font-bold">Leve interferência emocional.</p>
             </div>
             <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-rose-500"></div>
                   <span className="text-[9px] font-black text-white uppercase tracking-widest">0-49% Crítico</span>
                </div>
                <p className="text-[8px] text-slate-500 uppercase font-bold">Viés emocional dominante.</p>
             </div>
          </div>
        </div>

        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-[40px] p-8 shadow-2xl flex flex-col">
          <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-500 mb-6 flex items-center gap-3">
             <BrainIcon className="text-indigo-400" /> Clima de Encerramento
          </h3>
          <div className="flex-1 min-h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.feelingData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {stats.feelingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={FEELING_COLORS[entry.name] || COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px', fontSize: '10px' }}
                  itemStyle={{ color: '#fff', fontWeight: 'bold', textTransform: 'uppercase' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
             {stats.feelingData.map((f, i) => (
               <div key={i} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: FEELING_COLORS[f.name] }}></div>
                  <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">{f.name}</span>
               </div>
             ))}
          </div>
        </div>

        <div className="lg:col-span-12 bg-slate-900 border border-slate-800 rounded-[40px] p-8 shadow-2xl">
          <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-500 mb-8 flex items-center gap-3">
             <AlertIcon className="text-amber-500" /> Correlação: Estado Inicial vs. Sucesso do Plano
          </h3>
          <div className="h-[240px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.moodData} layout="vertical" margin={{ left: 60, right: 60, top: 20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} opacity={0.3} />
                <XAxis type="number" stroke="#475569" fontSize={10} axisLine={false} tickLine={false} domain={[0, 100]} hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  stroke="#94a3b8" 
                  fontSize={10} 
                  axisLine={false} 
                  tickLine={false} 
                  width={140} 
                  tick={{ fontWeight: '900' }} 
                />
                <Tooltip 
                  cursor={{fill: 'rgba(255,255,255,0.03)'}} 
                  labelStyle={{ color: '#fff', fontWeight: '900' }}
                  itemStyle={{ color: '#f8fafc', fontSize: '11px' }}
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }} 
                  formatter={(value: number, name: string, props: any) => {
                    const { success, count } = props.payload.raw;
                    return [`${value.toFixed(1)}% (${success} de ${count} sessões)`, 'Rigor Técnico'];
                  }}
                />
                <Bar 
                  dataKey="taxa" 
                  radius={[0, 10, 10, 0]} 
                  barSize={24}
                  background={{ fill: '#0f172a', radius: 10 }}
                >
                  <LabelList 
                    dataKey="taxa" 
                    position="right" 
                    formatter={(v: number) => `${v.toFixed(0)}%`} 
                    style={{ fill: '#ffffff', fontSize: '10px', fontWeight: '900', marginLeft: '10px' }} 
                  />
                  {stats.moodData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      <div className="bg-slate-950/50 border border-slate-800 p-8 rounded-[40px] text-center">
         <p className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em]">Métricas de Neuro-Estratégia DG-AI • v2.7</p>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon, color }: { label: string, value: string, icon: React.ReactNode, color: string }) => (
  <div className="bg-slate-900 border border-slate-800 p-8 rounded-[32px] shadow-xl relative overflow-hidden group transition-all hover:border-slate-700">
    <div className="absolute -right-4 -top-4 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
      {icon}
    </div>
    <div className="flex items-center gap-3 mb-4">
      {icon}
      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{label}</span>
    </div>
    <p className={`text-4xl font-black font-mono tracking-tighter ${color}`}>{value}</p>
  </div>
);

export default MindsetAnalytics;
