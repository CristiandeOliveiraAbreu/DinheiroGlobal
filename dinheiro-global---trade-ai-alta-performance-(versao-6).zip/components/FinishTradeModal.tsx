
import React, { useState, useMemo } from 'react';
import { Trade, Asset } from '../types';
import { XIcon, CheckIcon, CalculatorIcon, ActivityIcon } from './Icons';

interface FinishTradeModalProps {
  trade: Trade;
  assetConfig?: Asset;
  onClose: () => void;
  onConfirm: (finalTrade: Trade) => void;
}

const FinishTradeModal: React.FC<FinishTradeModalProps> = ({ trade, assetConfig, onClose, onConfirm }) => {
  const [exitPrice, setExitPrice] = useState(trade.stopPrice.toString());
  const [costs, setCosts] = useState('0');

  const calculation = useMemo(() => {
    const exit = parseFloat(exitPrice) || 0;
    const operCosts = parseFloat(costs) || 0;
    const entry = trade.entryPrice;
    const contracts = trade.contracts;
    const ptVal = assetConfig?.point_value || 1;

    let rawProfit = 0;
    if (trade.type === 'Compra') {
      rawProfit = (exit - entry) * contracts * ptVal;
    } else {
      rawProfit = (entry - exit) * contracts * ptVal;
    }

    const netProfit = rawProfit - operCosts;

    return {
      rawProfit,
      netProfit,
      isGain: netProfit >= 0
    };
  }, [exitPrice, costs, trade, assetConfig]);

  const handleFinish = () => {
    const finishedTrade: Trade = {
      ...trade,
      result: calculation.isGain ? 'Lucro' : 'Prejuízo',
      profit: calculation.netProfit,
      costs: parseFloat(costs) || 0,
      timestamp: Date.now(), 
      date: new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })
    };
    onConfirm(finishedTrade);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl" onClick={onClose}></div>
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-lg rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="px-10 py-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/10">
          <h2 className="text-xl font-black uppercase tracking-widest flex items-center gap-3">
            <CheckIcon className="text-emerald-500" /> Concluir Operação
          </h2>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors"><XIcon size={24}/></button>
        </div>

        <div className="p-10 space-y-8">
          <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800/50 flex justify-between items-center">
            <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Ativo em Saída</p>
              <p className="text-xl font-black text-white">{trade.asset}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Preço de Entrada</p>
              <p className="text-xl font-mono font-black text-slate-300">{trade.entryPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Preço de Execução (Saída)</label>
              <input 
                type="number" 
                step="any"
                autoFocus
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white font-mono font-black outline-none focus:ring-2 focus:ring-emerald-500/30 transition-all"
                value={exitPrice}
                onChange={e => setExitPrice(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-rose-400">Custos e Taxas ({trade.currency})</label>
              <input 
                type="number" 
                step="any"
                className="w-full bg-slate-950 border border-rose-900/20 rounded-2xl p-4 text-white font-mono font-black outline-none focus:ring-2 focus:ring-rose-500/30 transition-all"
                value={costs}
                onChange={e => setCosts(e.target.value)}
              />
            </div>
          </div>

          <div className={`p-8 rounded-[32px] border transition-all flex flex-col items-center justify-center text-center ${calculation.isGain ? 'bg-emerald-500/10 border-emerald-500/20 shadow-[0_0_40px_rgba(16,185,129,0.1)]' : 'bg-rose-500/10 border-rose-500/20 shadow-[0_0_40px_rgba(244,63,94,0.1)]'}`}>
             <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Resultado Líquido Projetado</p>
             <p className={`text-4xl font-mono font-black tracking-tighter ${calculation.isGain ? 'text-emerald-400' : 'text-rose-400'}`}>
               {trade.currency === 'USD' ? '$' : 'R$'} {calculation.netProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
             </p>
             <div className="mt-4 flex items-center gap-2 opacity-50">
               <CalculatorIcon size={12}/>
               <span className="text-[9px] font-black uppercase tracking-widest">Bruto: {calculation.rawProfit.toFixed(2)} | Taxas: {costs}</span>
             </div>
          </div>

          <button 
            onClick={handleFinish}
            className="w-full bg-emerald-600 hover:bg-emerald-500 py-6 rounded-[24px] text-xs font-black uppercase tracking-[0.3em] shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3"
          >
            <ActivityIcon size={18}/> Liquidar e Conciliar na Tesouraria
          </button>
        </div>
      </div>
    </div>
  );
};

export default FinishTradeModal;
