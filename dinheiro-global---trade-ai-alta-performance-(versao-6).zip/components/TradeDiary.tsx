
import React, { useState, useMemo, useEffect } from 'react';
import { DiaryEntry, PostSessionFeeling } from '../types';
import { 
  PlusIcon, XIcon, CheckIcon, JournalIcon, ActivityIcon, 
  TargetIcon, BrainIcon, HistoryIcon, TrashIcon, 
  EditIcon, LockIcon, ShieldIcon, AlertIcon
} from './Icons';
import MindsetAnalytics from './MindsetAnalytics';

interface TradeDiaryProps {
  entries: DiaryEntry[];
  onSave: (entry: DiaryEntry) => void;
  onDelete: (id: string) => void;
  addNotification?: (type: 'success' | 'error' | 'info', message: string) => void;
}

type DiaryTab = 'today' | 'extract' | 'analytics';

const TradeDiary: React.FC<TradeDiaryProps> = ({ entries = [], onSave, onDelete, addNotification }) => {
  const [activeTab, setActiveTab] = useState<DiaryTab>('today');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  const todayStr = useMemo(() => {
    const d = new Date();
    return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
  }, []);

  // Form States
  const [session, setSession] = useState<DiaryEntry['session']>('Manhã (5h até 12h)');
  const [mood, setMood] = useState<DiaryEntry['emotionalState']>('Calmo');
  const [postFeeling, setPostFeeling] = useState<PostSessionFeeling>('Indiferente');
  const [sleep, setSleep] = useState<DiaryEntry['sleepQuality']>('Boa');
  const [expectation, setExpectation] = useState<DiaryEntry['expectation']>('Realista');
  const [objective, setObjective] = useState('');
  const [reflection, setReflection] = useState('');
  const [objectiveReached, setObjectiveReached] = useState(false);
  const [emotionalAudit, setEmotionalAudit] = useState(false);
  const [strategicAudit, setStrategicAudit] = useState(false);
  const [financialAudit, setFinancialAudit] = useState(false);
  const [learning, setLearning] = useState('');

  // Lógica de Janelas Diárias (Limite 4/4)
  const totalToday = useMemo(() => {
    return entries.filter(e => e.date === todayStr).length;
  }, [entries, todayStr]);

  const sealedCount = useMemo(() => {
    return entries.filter(e => e.date === todayStr && e.isDaySealed).length;
  }, [entries, todayStr]);

  // Janelas operacionais ativas (ainda não seladas no histórico)
  const todayEntries = useMemo(() => {
    return entries.filter(e => e.date === todayStr && !e.isDaySealed);
  }, [entries, todayStr]);

  // Registros finalizados e selados para o Histórico
  const historyEntries = useMemo(() => {
    return entries.filter(e => e.isDaySealed).sort((a, b) => b.timestamp - a.timestamp);
  }, [entries]);

  const handleOpenModal = (entry?: DiaryEntry) => {
    if (entry) {
      setEditingId(entry.id);
      setSession(entry.session);
      setMood(entry.emotionalState);
      setPostFeeling(entry.postSessionFeeling || 'Indiferente');
      setSleep(entry.sleepQuality);
      setExpectation(entry.expectation);
      setObjective(entry.objective || '');
      setReflection(entry.reflection || '');
      setObjectiveReached(!!entry.objectiveReached);
      setEmotionalAudit(!!entry.emotionalAudit);
      setStrategicAudit(!!entry.strategicAudit);
      setFinancialAudit(!!entry.financialAudit);
      setLearning(entry.learning || '');
    } else {
      // Bloqueio se atingiu o limite de 4 Janelas
      if (totalToday >= 4) {
        addNotification?.('error', 'Limite diário de 4 janelas atingido. Proteja seu capital mental.');
        return;
      }
      setEditingId(null);
      setObjective('');
      setReflection('');
      setLearning('');
      setObjectiveReached(false);
      setEmotionalAudit(false);
      setStrategicAudit(false);
      setFinancialAudit(false);
      setPostFeeling('Indiferente');
      setMood('Calmo');
      setSleep('Boa');
      setExpectation('Realista');
    }
    setIsModalOpen(true);
  };

  const handleSaveEntry = async () => {
    if (!objective.trim()) {
      addNotification?.('error', 'O objetivo técnico é obrigatório.');
      return;
    }

    setLoading(true);
    try {
      // PROTOCOLO DE SELAGEM IMEDIATA:
      // Se editingId existe, estamos salvando a auditoria. Sela e envia ao histórico.
      const isFinishingAudit = !!editingId;

      const payload: DiaryEntry = {
        id: editingId || crypto.randomUUID(),
        date: todayStr,
        timestamp: editingId ? (entries.find(e => e.id === editingId)?.timestamp || Date.now()) : Date.now(),
        session,
        emotionalState: mood,
        postSessionFeeling: postFeeling,
        sleepQuality: sleep,
        expectation,
        objective: objective.trim(),
        evaluation: '', 
        reflection: reflection.trim(),
        objectiveReached,
        emotionalAudit,
        strategicAudit,
        financialAudit,
        learning: learning.trim(),
        isClosed: isFinishingAudit,
        isDaySealed: isFinishingAudit, 
        status: isFinishingAudit ? 'finalizada' : 'aberta'
      };

      await onSave(payload);
      
      if (isFinishingAudit) {
        addNotification?.('success', 'Sessão auditada e selada no histórico.');
      } else {
        addNotification?.('info', 'Check-in operacional registrado.');
      }
      
      setIsModalOpen(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-tight text-white">Performance Journal</h1>
          <p className="text-slate-400 mt-1 font-medium">Auditoria Comportamental e Controle de Rigor Técnico.</p>
        </div>
        <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800 shadow-2xl">
          <TabBtn active={activeTab === 'today'} onClick={() => setActiveTab('today')} icon={<ActivityIcon size={14}/>} label="Operacional" />
          <TabBtn active={activeTab === 'extract'} onClick={() => setActiveTab('extract')} icon={<HistoryIcon size={14}/>} label="Histórico" />
          <TabBtn active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} icon={<BrainIcon size={14}/>} label="Inteligência" />
        </div>
      </header>

      {activeTab === 'today' && (
        <div className="space-y-8">
          <div className="bg-slate-900 border border-slate-800 rounded-[40px] p-8 md:p-10 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none group-hover:opacity-[0.07] transition-opacity"><JournalIcon size={200}/></div>
            <div className="flex flex-col md:flex-row justify-between items-center gap-8 relative z-10">
              <div className="text-center md:text-left">
                <div className="flex items-center gap-2 mb-2 justify-center md:justify-start">
                   <div className={`w-2 h-2 rounded-full ${totalToday >= 4 ? 'bg-rose-500' : 'bg-emerald-500 animate-pulse'}`}></div>
                   <p className={`text-[10px] font-black uppercase tracking-[0.3em] ${totalToday >= 4 ? 'text-rose-500' : 'text-emerald-500'}`}>
                    {totalToday >= 4 ? 'Limite de Exposição Atingido' : 'Mercado Aberto • Ciclo Ativo'}
                   </p>
                </div>
                <h2 className="text-4xl font-black text-white uppercase tracking-tighter">{todayStr}</h2>
                <div className="flex items-center gap-4 mt-4 justify-center md:justify-start">
                  <div className="flex -space-x-1.5">
                    {[1, 2, 3, 4].map(slot => (
                      <div 
                        key={slot} 
                        className={`w-6 h-6 rounded-full border-2 border-slate-900 flex items-center justify-center text-[9px] font-bold transition-all ${totalToday >= slot ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-600'}`}
                      >
                        {slot}
                      </div>
                    ))}
                  </div>
                  <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">
                    {totalToday}/4 JANELAS REGISTRADAS
                  </span>
                </div>
              </div>
              
              <div className="flex gap-4 w-full md:w-auto">
                {totalToday >= 4 ? (
                  <div className="bg-rose-500/10 border border-rose-500/20 px-8 py-5 rounded-2xl flex items-center gap-3">
                    <LockIcon size={18} className="text-rose-500" />
                    <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest italic">Overtrading Bloqueado</span>
                  </div>
                ) : (
                  <button onClick={() => handleOpenModal()} className="w-full md:w-auto bg-emerald-600 hover:bg-emerald-500 text-white px-12 py-5 rounded-2xl font-black uppercase text-[11px] tracking-widest transition-all shadow-xl shadow-emerald-600/20 active:scale-95 flex items-center justify-center gap-3">
                    <PlusIcon size={18} /> Iniciar Janela
                  </button>
                )}
              </div>
            </div>
            
            {/* Barra de Progresso Diária */}
            <div className="mt-8 h-1 w-full bg-slate-950 rounded-full overflow-hidden no-print">
              <div 
                className={`h-full transition-all duration-1000 ${totalToday >= 4 ? 'bg-rose-500 shadow-[0_0_10px_#ef4444]' : 'bg-emerald-500 shadow-[0_0_10px_#10b981]'}`} 
                style={{ width: `${(totalToday / 4) * 100}%` }}
              ></div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {todayEntries.length === 0 ? (
              <div className="py-24 bg-slate-900/10 border-2 border-dashed border-slate-800 rounded-[40px] flex flex-col items-center justify-center text-slate-600">
                <TargetIcon size={48} className="mb-4 opacity-10" />
                <p className="text-[10px] font-black uppercase tracking-[0.3em]">
                  {totalToday >= 4 ? 'Slots diários concluídos. Revise seu histórico.' : 'Inicie uma nova janela operacional.'}
                </p>
              </div>
            ) : (
              todayEntries.map(entry => (
                <div key={entry.id} className="group relative bg-slate-900 border border-amber-500/30 bg-amber-500/5 transition-all rounded-[32px] p-8 shadow-xl flex flex-col md:flex-row justify-between items-center gap-8 animate-in slide-in-from-left-4">
                  <div className="flex items-center gap-6 flex-1">
                    <div className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-inner bg-amber-600/20 text-amber-500">
                      <ActivityIcon size={28} />
                    </div>
                    <div>
                      <h4 className="text-2xl font-black text-white uppercase tracking-tighter">{entry.session}</h4>
                      <div className="flex flex-wrap gap-2 mt-2">
                        <span className="px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest border bg-amber-500/10 text-amber-500 border-amber-500/20">
                          Aguardando Auditoria
                        </span>
                        <span className="bg-slate-950 text-slate-500 border border-slate-800 px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest">{entry.emotionalState}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex-[2] hidden md:block px-8 border-x border-slate-800/50">
                     <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Foco da Sessão</p>
                     <p className="text-sm text-slate-300 font-medium line-clamp-2 italic leading-relaxed">"{entry.objective}"</p>
                  </div>

                  <div className="flex gap-3">
                    <button onClick={() => handleOpenModal(entry)} className="px-10 py-4 rounded-xl text-[10px] font-black uppercase transition-all border bg-amber-600 border-amber-500 text-white shadow-lg shadow-amber-600/20 active:scale-95 flex items-center gap-2">
                      <EditIcon size={14} /> Finalizar & Selar
                    </button>
                    <button onClick={() => { if(confirm('Excluir sessão?')) onDelete(entry.id) }} className="p-4 bg-rose-950/20 text-rose-500 hover:bg-rose-600 hover:text-white rounded-xl transition-all border border-rose-500/10">
                      <TrashIcon size={18} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {activeTab === 'extract' && (
        <div className="bg-slate-900 border border-slate-800 rounded-[40px] overflow-hidden shadow-2xl">
          <div className="p-8 border-b border-slate-800 bg-slate-800/10 flex justify-between items-center">
             <div>
                <h3 className="text-xl font-black text-white uppercase tracking-tighter">Sessões Seladas</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Registros imutáveis de performance.</p>
             </div>
             <ShieldIcon size={32} className="text-slate-700" />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-950/40 border-b border-slate-800 text-[9px] font-black text-slate-600 uppercase tracking-widest">
                  <th className="px-10 py-6">Timestamp / Data</th>
                  <th className="px-10 py-6">Sessão</th>
                  <th className="px-10 py-6 text-center">Protocolo de Rigor</th>
                  <th className="px-10 py-6 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/30">
                {historyEntries.length === 0 ? (
                  <tr><td colSpan={4} className="px-10 py-20 text-center text-slate-600 font-black uppercase text-[10px] tracking-widest">Nenhuma sessão auditada ainda.</td></tr>
                ) : (
                  historyEntries.map(entry => (
                    <tr key={entry.id} className="hover:bg-slate-800/10 transition-colors group">
                      <td className="px-10 py-6">
                        <p className="text-xs font-mono font-bold text-slate-400">{entry.date}</p>
                        <p className="text-[8px] text-slate-600 uppercase mt-1">ID: {entry.id.slice(0,8)}</p>
                      </td>
                      <td className="px-10 py-6 font-black text-white text-xs uppercase tracking-tight">{entry.session}</td>
                      <td className="px-10 py-6">
                        <div className="flex justify-center gap-2">
                          <CheckDot active={entry.emotionalAudit} label="MENTAL" />
                          <CheckDot active={entry.strategicAudit} label="TÁTICO" />
                          <CheckDot active={entry.financialAudit} label="RISCO" />
                        </div>
                      </td>
                      <td className="px-10 py-6 text-right">
                         <button onClick={() => handleOpenModal(entry)} className="p-3 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition-all"><EditIcon size={14}/></button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'analytics' && <MindsetAnalytics entries={entries} />}

      {isModalOpen && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/98 backdrop-blur-xl animate-in fade-in duration-300" onClick={() => !loading && setIsModalOpen(false)}></div>
          <div className="relative bg-[#0f1421] border border-slate-800 w-full max-w-5xl rounded-[40px] shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-300 max-h-[92vh]">
             
             <div className="p-8 md:px-12 md:py-8 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
                <div>
                  <h2 className="text-2xl font-black uppercase tracking-widest text-white">
                    {editingId ? 'Auditando Performance' : 'Check-in Operacional'}
                  </h2>
                  <div className="flex items-center gap-2 mt-1">
                    <ShieldIcon size={12} className="text-emerald-500"/> 
                    <span className="text-[9px] text-slate-500 font-black uppercase tracking-[0.2em]">Protocolo DG-AI de Elite</span>
                  </div>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-4 bg-slate-800 hover:bg-slate-700 rounded-full text-slate-500 hover:text-white transition-all shadow-xl"><XIcon size={24}/></button>
             </div>

             <div className="flex-1 overflow-y-auto custom-scrollbar p-8 md:p-12 space-y-16">
                
                {/* PARTE 1: CONTEXTO */}
                <section className="space-y-10">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-indigo-600/20 rounded-2xl flex items-center justify-center text-indigo-400 border border-indigo-500/20"><TargetIcon size={24}/></div>
                    <div>
                      <h4 className="text-[11px] font-black uppercase tracking-[0.3em] text-white">Fase 01: Preparação Operacional</h4>
                      <p className="text-[9px] text-slate-500 font-bold uppercase mt-0.5">Definição de contexto e objetivos</p>
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-3 gap-8">
                    <Field label="Janela de Execução">
                      <select value={session} onChange={e => setSession(e.target.value as any)} className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-5 text-xs font-black text-white uppercase outline-none focus:border-indigo-500/50 transition-all appearance-none cursor-pointer">
                        <option>Madrugada (24h até 5h)</option><option>Manhã (5h até 12h)</option><option>Tarde (12h até 18h)</option><option>Noite (18h até 24h)</option>
                      </select>
                    </Field>
                    <Field label="Estado Mental Inicial">
                      <select value={mood} onChange={e => setMood(e.target.value as any)} className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-5 text-xs font-black text-white uppercase outline-none focus:border-indigo-500/50 appearance-none cursor-pointer">
                        <option>Calmo</option><option>Ansioso</option><option>Eufórico</option><option>Frustrado</option>
                      </select>
                    </Field>
                    <Field label="Recuperação (Sono)">
                      <select value={sleep} onChange={e => setSleep(e.target.value as any)} className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-5 text-xs font-black text-white uppercase outline-none focus:border-indigo-500/50 appearance-none cursor-pointer">
                        <option>Boa</option><option>Regular</option><option>Ruim</option>
                      </select>
                    </Field>
                  </div>

                  <Field label="Objetivo Técnico do Ciclo (Missão)">
                    <textarea 
                      value={objective} 
                      onChange={e => setObjective(e.target.value)} 
                      placeholder="Descreva sua missão técnica principal para esta janela... Ex: Aguardar toque no Fair Value Gap de H4." 
                      className="w-full bg-slate-950 border border-slate-800 rounded-[32px] p-8 text-sm text-white min-h-[120px] outline-none focus:ring-1 focus:ring-indigo-500/40 transition-all font-medium placeholder:text-slate-700" 
                    />
                  </Field>
                </section>

                {/* PARTE 2: AUDITORIA */}
                <section className={`pt-16 border-t border-slate-800/50 space-y-12 transition-all duration-700 ${editingId ? 'opacity-100' : 'opacity-30 pointer-events-none'}`}>
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div className="flex items-center gap-4">
                         <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500 border border-emerald-500/20"><ShieldIcon size={24}/></div>
                         <div>
                            <h4 className="text-[11px] font-black uppercase tracking-[0.3em] text-white">Fase 02: Auditoria & Selagem</h4>
                            <p className="text-[9px] text-slate-500 font-bold uppercase mt-0.5">Ao preencher esta fase, a sessão será movida para o histórico.</p>
                         </div>
                      </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <AuditToggle active={objectiveReached} onClick={() => setObjectiveReached(!objectiveReached)} label="Missão Cumprida" />
                      <AuditToggle active={emotionalAudit} onClick={() => setEmotionalAudit(!emotionalAudit)} label="Rigor Mental" />
                      <AuditToggle active={strategicAudit} onClick={() => setStrategicAudit(!strategicAudit)} label="Rigor Tático" />
                      <AuditToggle active={financialAudit} onClick={() => setFinancialAudit(!financialAudit)} label="Rigor de Risco" />
                  </div>

                  <div className="grid md:grid-cols-2 gap-8">
                      <Field label="Sentimento Pós-Execução">
                        <select value={postFeeling} onChange={e => setPostFeeling(e.target.value as any)} className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-5 text-xs font-black text-white uppercase outline-none focus:border-indigo-500/50 transition-all appearance-none cursor-pointer">
                          <option>Disciplinado</option><option>Indiferente</option><option>Eufórico</option><option>Frustrado</option><option>Esgotado</option>
                        </select>
                      </Field>
                      <Field label="Key Insight (Aprendizado Vital)">
                        <input value={learning} onChange={e => setLearning(e.target.value)} placeholder="O que o mercado te ensinou hoje?" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-5 text-sm text-white outline-none focus:border-emerald-500/50 font-medium" />
                      </Field>
                  </div>

                  <Field label="Autoanálise Crítica (Reflexão)">
                      <textarea value={reflection} onChange={e => setReflection(e.target.value)} placeholder="Descreva honestamente sua performance. O que foi feito corretamente e o que precisa ser corrigido?" className="w-full bg-slate-950 border border-slate-800 rounded-[32px] p-8 text-sm text-white min-h-[160px] outline-none focus:ring-1 focus:ring-emerald-500/40 transition-all font-medium placeholder:text-slate-700" />
                  </Field>

                  {!editingId && (
                    <div className="bg-amber-500/5 border border-amber-500/10 p-6 rounded-3xl flex items-center gap-4">
                      <AlertIcon size={24} className="text-amber-500 shrink-0"/>
                      <p className="text-[11px] text-amber-500 font-bold uppercase tracking-widest italic">Efetive o check-in inicial para liberar a auditoria e finalização da janela.</p>
                    </div>
                  )}
                </section>
             </div>

             <div className="p-8 md:px-12 md:py-10 bg-slate-950 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-8">
                <div className="hidden md:block">
                  <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em]">
                    Sincronização imediata via Terminal Global
                  </p>
                </div>
                <div className="flex gap-4 w-full md:w-auto">
                  <button onClick={() => setIsModalOpen(false)} className="flex-1 md:flex-none px-10 py-5 rounded-2xl text-[11px] font-black uppercase tracking-widest text-slate-500 hover:text-white transition-all bg-slate-900 border border-slate-800">Cancelar</button>
                  <button 
                    onClick={handleSaveEntry} 
                    disabled={loading || !objective.trim()}
                    className="flex-[2] md:flex-none bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-600 text-white px-16 py-5 rounded-2xl font-black uppercase text-[11px] tracking-[0.3em] transition-all shadow-xl shadow-emerald-600/20 active:scale-95 flex items-center justify-center min-w-[280px]"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      editingId ? 'Finalizar & Selar Sessão' : 'Efetivar Check-in'
                    )}
                  </button>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

const TabBtn = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
  <button onClick={onClick} className={`px-8 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-3 ${active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-500 hover:text-white hover:bg-slate-800'}`}>
    {icon} {label}
  </button>
);

const Field: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="space-y-4">
    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">{label}</label>
    {children}
  </div>
);

const AuditToggle = ({ active, label, onClick }: { active: boolean, label: string, onClick: () => void }) => (
  <button type="button" onClick={onClick} className={`flex items-center justify-between p-6 rounded-[28px] border transition-all ${active ? 'bg-emerald-500/10 border-emerald-500/40 text-white ring-1 ring-emerald-500/20' : 'bg-slate-950 border-slate-800 text-slate-600 hover:border-slate-700'}`}>
    <span className="text-[10px] font-black uppercase tracking-widest text-left leading-tight">{label}</span>
    <div className={`w-10 h-5 rounded-full relative transition-colors ${active ? 'bg-emerald-500' : 'bg-slate-800'}`}>
       <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${active ? 'left-6' : 'left-1'}`}></div>
    </div>
  </button>
);

const CheckDot = ({ active, label }: { active: boolean, label: string }) => (
  <div className={`px-3 py-1.5 rounded-lg flex items-center justify-center text-[8px] font-black border transition-all ${active ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400' : 'bg-slate-900 border-slate-800 text-slate-700'}`}>
    {label}
  </div>
);

export default TradeDiary;
