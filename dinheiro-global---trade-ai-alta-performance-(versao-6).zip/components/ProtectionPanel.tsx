
import React, { useMemo } from 'react';
import { Trade, Asset } from '../types';
import { ShieldIcon, TargetIcon, AlertIcon, LockIcon, ActivityIcon, CheckIcon } from './Icons';

interface ProtectionPanelProps {
  openTrades: Trade[];
  assets: Asset[];
  exchangeRate: number;
  totalEquityBRL: number;
  availableCapitalBRL: number;
}

const ProtectionPanel: React.FC<ProtectionPanelProps> = ({ 
  openTrades, 
  assets, 
  exchangeRate, 
  totalEquityBRL, 
  availableCapitalBRL 
}) => {
  const metrics = useMemo(() => {
    let totalProtectedBRL = 0;
    let totalPotentialBRL = 0;
    let totalResidualRiskBRL = 0;

    openTrades.forEach(trade => {
      const assetConfig = assets.find(a => a.name.toUpperCase() === trade.asset.toUpperCase());
      const ptVal = assetConfig?.point_value || 1;
      const rate = trade.currency === 'USD' ? exchangeRate : 1;

      // Lucro Potencial (Alvo)
      if (trade.takeProfit > 0) {
        const distTarget = Math.abs(trade.takeProfit - trade.entryPrice);
        totalPotentialBRL += (distTarget * trade.contracts * ptVal * rate);
      }

      // Lucro Protegido (Trailing Stop no Lucro)
      const isProtected = trade.type === 'Compra' 
        ? trade.stopPrice > trade.entryPrice 
        : trade.stopPrice < trade.entryPrice;

      if (isProtected) {
        const distProtected = Math.abs(trade.stopPrice - trade.entryPrice);
        totalProtectedBRL += (distProtected * trade.contracts * ptVal * rate);
      } else {
        // Risco Residual (Stop ainda no prejuízo ou no breakeven)
        const distRisk = Math.abs(trade.entryPrice - trade.stopPrice);
        totalResidualRiskBRL += (distRisk * trade.contracts * ptVal * rate);
      }
    });

    const capRiskPct = availableCapitalBRL > 0 ? (totalResidualRiskBRL / availableCapitalBRL) * 100 : 0;
    const equityRiskPct = totalEquityBRL > 0 ? (totalResidualRiskBRL / totalEquityBRL) * 100 : 0;
    const stopEfficiency = totalPotentialBRL > 0 ? (totalProtectedBRL / totalPotentialBRL) * 100 : 0;

    // Definição de Status
    let status: 'SAFE' | 'WARNING' | 'DANGER' = 'SAFE';
    if (equityRiskPct > 3 || capRiskPct > 5) status = 'DANGER';
    else if (equityRiskPct > 1 || capRiskPct > 2) status = 'WARNING';

    return {
      totalProtectedBRL,
      totalPotentialBRL,
      totalResidualRiskBRL,
      capRiskPct,
      equityRiskPct,
      stopEfficiency,
      status
    };
  }, [openTrades, assets, exchangeRate, totalEquityBRL, availableCapitalBRL]);

  const getStatusConfig = () => {
    switch (metrics.status) {
      case 'DANGER': return { label: 'Exposição Elevada', color: 'text-rose-500 bg-rose-500/10 border-rose-500/20', icon: <AlertIcon size={14}/> };
      case 'WARNING': return { label: 'Atenção Tática', color: 'text-amber-500 bg-amber-500/10 border-amber-500/20', icon: <ActivityIcon size={14}/> };
      default: return { label: 'Zona Segura', color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20', icon: <ShieldIcon size={14}/> };
    }
  };

  const statusConfig = getStatusConfig();

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-700">
      <div className="flex justify-between items-center px-2">
        <div className="flex items-center gap-3">
          <div className={`px-4 py-1.5 rounded-full border text-[10px] font-black uppercase tracking-widest flex items-center gap-2 ${statusConfig.color}`}>
            {statusConfig.icon} {statusConfig.label}
          </div>
          <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Protocolo DG-AI de Proteção v3.0</span>
        </div>
        <div className="hidden md:flex gap-4">
           <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter">Lucro Travado</span>
           </div>
           <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-rose-500"></div>
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter">Risco Residual</span>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Lucro Protegido */}
        <div className="bg-slate-900/60 border border-emerald-500/20 p-6 rounded-[32px] relative group overflow-hidden">
           <div className="absolute -right-2 -top-2 p-6 opacity-5 group-hover:opacity-10 transition-opacity text-emerald-500">
             <ShieldIcon size={64} className={metrics.totalProtectedBRL > 0 ? "animate-pulse" : ""} />
           </div>
           <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2 flex items-center gap-2">
             <LockIcon size={10} className="text-emerald-500" /> Lucro Protegido
           </p>
           <p className="text-xl font-mono font-black text-emerald-400">
             R$ {metrics.totalProtectedBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
           </p>
           <div className="mt-4 w-full h-1 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 transition-all duration-1000" style={{ width: `${Math.min(100, (metrics.totalProtectedBRL/metrics.totalPotentialBRL)*100 || 0)}%` }}></div>
           </div>
        </div>

        {/* Lucro Potencial */}
        <div className="bg-slate-900/60 border border-blue-500/10 p-6 rounded-[32px] relative group overflow-hidden">
           <div className="absolute -right-2 -top-2 p-6 opacity-5 text-blue-500"><TargetIcon size={64}/></div>
           <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Lucro Potencial Aberto</p>
           <p className="text-xl font-mono font-black text-blue-400">
             R$ {metrics.totalPotentialBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
           </p>
           <p className="text-[8px] font-bold text-slate-600 uppercase mt-2">Soma de todos os alvos</p>
        </div>

        {/* Risco Residual */}
        <div className="bg-slate-900/60 border border-rose-500/10 p-6 rounded-[32px] relative group overflow-hidden">
           <div className="absolute -right-2 -top-2 p-6 opacity-5 text-rose-500"><AlertIcon size={64}/></div>
           <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Risco Residual Total</p>
           <p className={`text-xl font-mono font-black ${metrics.totalResidualRiskBRL > (totalEquityBRL * 0.02) ? 'text-rose-500' : 'text-amber-500'}`}>
             R$ {metrics.totalResidualRiskBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
           </p>
           <p className="text-[8px] font-bold text-slate-600 uppercase mt-2">Exposição máxima atual</p>
        </div>

        {/* Capital em Risco */}
        <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-[32px]">
           <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Capital em Risco</p>
           <div className="flex items-end gap-2 mb-2">
             <span className={`text-2xl font-black tracking-tighter ${metrics.capRiskPct > 5 ? 'text-rose-500' : metrics.capRiskPct > 2 ? 'text-amber-500' : 'text-emerald-400'}`}>
               {metrics.capRiskPct.toFixed(2)}%
             </span>
             <span className="text-[9px] text-slate-600 font-bold uppercase mb-1">do caixa</span>
           </div>
           <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className={`h-full transition-all duration-1000 ${metrics.capRiskPct > 5 ? 'bg-rose-500' : metrics.capRiskPct > 2 ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ width: `${Math.min(100, metrics.capRiskPct)}%` }}></div>
           </div>
        </div>

        {/* Patrimônio em Risco - DESTAQUE PSICOLÓGICO */}
        <div className={`p-6 rounded-[32px] border transition-all shadow-xl relative overflow-hidden group ${metrics.equityRiskPct > 3 ? 'bg-rose-500/5 border-rose-500/40 shadow-rose-500/5' : 'bg-slate-900 border-indigo-500/30'}`}>
           <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform"><ShieldIcon size={32}/></div>
           <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Patrimônio em Risco</p>
           <div className="flex items-end gap-2 mb-2">
             <span className={`text-3xl font-black tracking-tighter ${metrics.equityRiskPct > 3 ? 'text-rose-500' : 'text-white'}`}>
               {metrics.equityRiskPct.toFixed(2)}%
             </span>
             <span className="text-[9px] text-slate-600 font-bold uppercase mb-1.5">Impacto Total</span>
           </div>
           <div className="flex items-center gap-2 mt-2">
              <div className={`w-1.5 h-1.5 rounded-full ${metrics.equityRiskPct > 3 ? 'bg-rose-500 animate-ping' : 'bg-indigo-500'}`}></div>
              <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Risco Patrimonial Global</p>
           </div>
        </div>

        {/* Eficiência do Trailing Stop */}
        <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-[32px]">
           <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Eficácia Trailing Stop</p>
           <div className="flex items-end gap-2 mb-2">
             <span className={`text-2xl font-black tracking-tighter ${metrics.stopEfficiency > 60 ? 'text-emerald-400' : metrics.stopEfficiency > 40 ? 'text-amber-500' : 'text-rose-500'}`}>
               {metrics.stopEfficiency.toFixed(1)}%
             </span>
             <span className="text-[9px] text-slate-600 font-bold uppercase mb-1">Proteção</span>
           </div>
           <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className={`h-full transition-all duration-1000 ${metrics.stopEfficiency > 60 ? 'bg-emerald-500' : metrics.stopEfficiency > 40 ? 'bg-amber-500' : 'bg-rose-500'}`} style={{ width: `${Math.min(100, metrics.stopEfficiency)}%` }}></div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ProtectionPanel;
