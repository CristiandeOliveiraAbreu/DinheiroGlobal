
import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Trade, Contribution, Asset, ExtraIncome, DiaryEntry } from '../types';
import { TargetIcon, BriefcaseIcon, ActivityIcon, Logo, MoneyIcon, BrainIcon, AlertIcon, ShieldIcon, LockIcon, CheckIcon } from './Icons';

interface DashboardProps {
  trades: Trade[];
  contributions: Contribution[];
  assets: Asset[];
  extraIncomes: ExtraIncome[];
  diaryEntries: DiaryEntry[];
  exchangeRate: number;
  equityBRL: number;
  isManualRate?: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ trades, contributions, assets, extraIncomes, diaryEntries, exchangeRate, equityBRL, isManualRate }) => {
  const rate = exchangeRate;

  // Filtrar apenas ativos com status ATIVO
  const activeAssetNames = useMemo(() => {
    return assets.filter(a => (a.status || 'ATIVO') === 'ATIVO').map(a => a.name.toUpperCase());
  }, [assets]);

  // Cálculos de Risco e Capital (Lógica consolidada)
  const riskMetrics = useMemo(() => {
    const openTrades = trades.filter(t => t.result === 'Pendente');
    let totalResidualRiskBRL = 0;
    let totalProtectedBRL = 0;
    let openInvestedBRL = 0;

    openTrades.forEach(trade => {
      const assetConfig = assets.find(a => a.name.toUpperCase() === trade.asset.toUpperCase());
      const ptVal = assetConfig?.point_value || 1;
      const rateTrade = trade.currency === 'USD' ? rate : 1;

      // Verificação de Proteção (Trailing Stop no Lucro)
      const isProtected = trade.type === 'Compra' 
        ? trade.stopPrice > trade.entryPrice 
        : trade.stopPrice < trade.entryPrice;

      if (isProtected) {
        // Lucro já garantido pelo stop
        const distProtected = Math.abs(trade.stopPrice - trade.entryPrice);
        totalProtectedBRL += (distProtected * trade.contracts * ptVal * rateTrade);
      } else {
        // Risco residual (stop ainda no prejuízo ou breakeven)
        const distRisk = Math.abs(trade.entryPrice - trade.stopPrice);
        totalResidualRiskBRL += (distRisk * trade.contracts * ptVal * rateTrade);
      }

      // Valor Investido em Ativos Abertos
      if (trade.type === 'Compra') {
        const cost = trade.contracts * trade.entryPrice;
        openInvestedBRL += (rateTrade * cost);
      }
    });

    // Saldo de caixa (Aportes - Saques + Proventos)
    const cashMovementsBRL = contributions.reduce((sum, c) => {
      const val = c.currency === 'USD' ? Number(c.amount) * rate : Number(c.amount);
      const costVal = (c.costs || 0) * (c.currency === 'USD' ? rate : 1);
      if (c.type === 'Retirada' || c.type === 'Custo') return sum - (val + costVal);
      return sum + val;
    }, 0);

    const realizedProfitBRL = trades
      .filter(t => t.result !== 'Pendente')
      .reduce((sum, t) => sum + (t.currency === 'USD' ? Number(t.profit) * rate : Number(t.profit)), 0);

    const availableCapitalBRL = (cashMovementsBRL + realizedProfitBRL) - openInvestedBRL;
    const capRiskPct = availableCapitalBRL > 0 ? (totalResidualRiskBRL / availableCapitalBRL) * 100 : 0;
    const equityRiskPct = equityBRL > 0 ? (totalResidualRiskBRL / equityBRL) * 100 : 0;

    let status: 'SAFE' | 'WARNING' | 'DANGER' = 'SAFE';
    if (equityRiskPct > 3 || capRiskPct > 5) status = 'DANGER';
    else if (equityRiskPct > 1 || capRiskPct > 2) status = 'WARNING';

    return { 
      totalResidualRiskBRL, 
      totalProtectedBRL,
      availableCapitalBRL, 
      capRiskPct, 
      equityRiskPct,
      status 
    };
  }, [trades, contributions, assets, rate, equityBRL]);

  // Cálculos Financeiros Filtrados
  const totalIncomesBRL = useMemo(() => {
    return extraIncomes
      .filter(i => activeAssetNames.includes(i.assetName.toUpperCase()))
      .reduce((sum, i) => {
        const val = i.currency === 'USD' ? Number(i.amount) * rate : Number(i.amount);
        return sum + val;
      }, 0);
  }, [extraIncomes, rate, activeAssetNames]);

  const finishedTrades = trades.filter(t => 
    t.result !== 'Pendente' && 
    !t.archived && 
    activeAssetNames.includes(t.asset.toUpperCase())
  );
  
  // Métricas Comportamentais do Diário
  const mindsetMetrics = useMemo(() => {
    if (diaryEntries.length === 0) return { score: 0, consistency: 0, compliance: 0 };
    const score = (diaryEntries.filter(e => e.emotionalAudit).length / diaryEntries.length) * 100;
    const consistency = (diaryEntries.filter(e => e.strategicAudit).length / diaryEntries.length) * 100;
    const compliance = (diaryEntries.filter(e => e.objectiveReached).length / diaryEntries.length) * 100;
    return { score, consistency, compliance };
  }, [diaryEntries]);

  // Dados do Gráfico
  const chartData = useMemo(() => {
    const events = [
      ...contributions.filter(c => !c.assetName || activeAssetNames.includes(c.assetName.toUpperCase())).map(c => ({ 
        timestamp: c.timestamp, 
        date: c.date, 
        amountBRL: (c.currency === 'USD') ? Number(c.amount) * rate : Number(c.amount), 
        costsBRL: (c.costs || 0) * (c.currency === 'USD' ? rate : 1),
        type: c.type, 
        category: 'aporte' 
      })),
      ...finishedTrades.map(t => ({ 
        timestamp: t.timestamp, 
        date: t.date, 
        profitBRL: (t.currency === 'USD') ? Number(t.profit) * rate : Number(t.profit), 
        category: 'operacao' 
      })),
      ...extraIncomes.filter(i => activeAssetNames.includes(i.assetName.toUpperCase())).map(i => ({ 
        timestamp: i.timestamp, 
        date: i.date, 
        amountBRL: (i.currency === 'USD') ? Number(i.amount) * rate : Number(i.amount), 
        category: 'rendimento' 
      }))
    ].sort((a, b) => a.timestamp - b.timestamp);
    
    let runningEquityBRL = 0;
    return events.map(event => {
      if (event.category === 'aporte') { 
        if (event.type === 'Retirada' || event.type === 'Custo') {
          runningEquityBRL -= (event.amountBRL + event.costsBRL);
        } else {
          runningEquityBRL += event.amountBRL;
        }
      } else if (event.category === 'rendimento') {
        runningEquityBRL += (event as any).amountBRL;
      } else { 
        runningEquityBRL += (event as any).profitBRL; 
      }
      return { name: event.date, equity: runningEquityBRL };
    });
  }, [contributions, finishedTrades, extraIncomes, rate, activeAssetNames]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-tight text-white">Consolidado Financeiro & Comportamental</h1>
          <p className="text-slate-400 mt-1 font-medium">Autoanálise 360: Resultados, Patrimônio e Inteligência Emocional.</p>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-3xl flex items-center gap-6 shadow-xl">
           <div className={`px-4 py-1.5 rounded-full border text-[9px] font-black uppercase tracking-widest flex items-center gap-2 ${riskMetrics.status === 'DANGER' ? 'bg-rose-500/10 border-rose-500/30 text-rose-500' : riskMetrics.status === 'WARNING' ? 'bg-amber-500/10 border-amber-500/30 text-amber-500' : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500'}`}>
              <ShieldIcon size={12} /> {riskMetrics.status === 'DANGER' ? 'Exposição Elevada' : riskMetrics.status === 'WARNING' ? 'Atenção Tática' : 'Zona Segura'}
           </div>
           <div className="text-right">
              <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Dólar IA</p>
              <p className="text-sm font-mono font-black text-emerald-400">R$ {rate.toFixed(4)}</p>
           </div>
        </div>
      </header>

      {/* Grid de Métricas Principais - Adaptado para Lucro Protegido */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-6">
        <StatCard label="Patrimônio Total" value={equityBRL} color="text-white" icon={<BriefcaseIcon size={16}/>} />
        
        <StatCard 
          label="Capital em Risco" 
          value={riskMetrics.capRiskPct} 
          unit="%" 
          color={riskMetrics.capRiskPct > 5 ? 'text-rose-500' : riskMetrics.capRiskPct > 2 ? 'text-amber-500' : 'text-emerald-400'} 
          icon={<AlertIcon size={16}/>} 
          highlight={riskMetrics.capRiskPct > 2}
        />

        <StatCard 
          label="Risco Residual" 
          value={riskMetrics.totalResidualRiskBRL} 
          color={riskMetrics.totalResidualRiskBRL > (equityBRL * 0.02) ? 'text-rose-400' : 'text-slate-300'} 
          icon={<LockIcon size={16}/>} 
        />

        {/* NOVO INDICADOR: LUCRO PROTEGIDO */}
        <StatCard 
          label="Lucro Protegido" 
          value={riskMetrics.totalProtectedBRL} 
          color="text-emerald-400" 
          icon={<ShieldIcon size={16} className={riskMetrics.totalProtectedBRL > 0 ? "animate-pulse" : ""} />} 
          highlight={riskMetrics.totalProtectedBRL > 0}
        />

        <StatCard label="Score Mental" value={mindsetMetrics.score} unit="%" color="text-indigo-400" icon={<BrainIcon size={16}/>} />
        <StatCard label="Aderência ao Plano" value={mindsetMetrics.compliance} unit="%" color="text-blue-400" icon={<TargetIcon size={16}/>} />
        <StatCard label="Dividendos" value={totalIncomesBRL} color="text-amber-400" icon={<MoneyIcon size={16}/>} gold />
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        {/* Gráfico Evolutivo */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-[48px] p-8 shadow-2xl relative overflow-hidden h-[500px]">
          <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none"><Logo size={200}/></div>
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-lg font-bold uppercase tracking-widest flex items-center gap-3 text-white"><ActivityIcon className="text-emerald-500"/> Performance do Capital</h2>
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-black bg-emerald-500/10 text-emerald-500 px-4 py-1.5 rounded-full border border-emerald-500/20 uppercase tracking-widest">Biblioteca Ativa</span>
            </div>
          </div>
          <div className="h-[380px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs><linearGradient id="colorEquity" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#10b981" stopOpacity={0.15}/><stop offset="95%" stopColor="#10b981" stopOpacity={0}/></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} opacity={0.3} />
                <XAxis dataKey="name" stroke="#475569" fontSize={10} axisLine={false} tickLine={false} />
                <YAxis stroke="#475569" fontSize={10} axisLine={false} tickLine={false} tickFormatter={(v) => `R$ ${v.toLocaleString('pt-BR', { notation: 'compact' })}`} />
                <Tooltip 
                  labelStyle={{ color: '#ffffff', fontWeight: '800', textTransform: 'uppercase', fontSize: '10px', marginBottom: '8px' }}
                  itemStyle={{ color: '#ffffff', fontWeight: 'bold' }}
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '16px', boxShadow: '0 20px 40px rgba(0,0,0,0.5)' }} 
                  formatter={(v: any) => [`R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 'Saldo']} 
                />
                <Area type="monotone" dataKey="equity" stroke="#10b981" strokeWidth={4} fill="url(#colorEquity)" animationDuration={2000} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sidebar Comportamental */}
        <div className="lg:col-span-4 space-y-8">
           <div className="bg-slate-900 border border-slate-800 rounded-[48px] p-8 shadow-2xl flex flex-col h-[235px]">
              <h2 className="text-sm font-bold uppercase tracking-widest mb-6 flex items-center gap-3 text-white"><BrainIcon className="text-indigo-400"/> Saúde do Mindset</h2>
              <div className="space-y-4">
                 <MindsetBar label="Controle Emocional" percent={mindsetMetrics.score} color="bg-indigo-500" />
                 <MindsetBar label="Disciplina Tática" percent={mindsetMetrics.consistency} color="bg-emerald-500" />
                 <MindsetBar label="Gestão de Expectativa" percent={mindsetMetrics.compliance} color="bg-amber-500" />
              </div>
           </div>

           <div className="bg-slate-900 border border-slate-800 rounded-[48px] p-8 shadow-2xl flex flex-col h-[235px] relative group overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-all"><ActivityIcon size={80}/></div>
              <h2 className="text-sm font-bold uppercase tracking-widest mb-4 text-white">Status de Exposição</h2>
              <p className="text-[12px] text-slate-400 leading-relaxed font-medium">
                {riskMetrics.capRiskPct > 5 
                  ? "Sua exposição de capital está CRÍTICA (>5%). Reduza o tamanho dos contratos ou proteja suas posições imediatamente." 
                  : riskMetrics.capRiskPct > 2 
                    ? "Alerta: Exposição moderada detectada. Evite abrir novos trades até reduzir o risco residual."
                    : "Risco Sob Controle: Seu capital em risco está abaixo dos limites de segurança institucionais (2%)."}
              </p>
              <div className="mt-auto flex items-center gap-3">
                 <div className={`w-3 h-3 rounded-full animate-pulse ${riskMetrics.status === 'SAFE' ? 'bg-emerald-500' : riskMetrics.status === 'WARNING' ? 'bg-amber-500' : 'bg-rose-500'}`}></div>
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Capital Livre: R$ {riskMetrics.availableCapitalBRL.toLocaleString('pt-BR', { notation: 'compact' })}</span>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

const MindsetBar = ({ label, percent, color }: { label: string, percent: number, color: string }) => (
  <div>
    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest mb-1.5">
       <span className="text-slate-500">{label}</span>
       <span className="text-white">{percent.toFixed(0)}%</span>
    </div>
    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
       <div className={`h-full ${color} transition-all duration-1000`} style={{ width: `${percent}%` }}></div>
    </div>
  </div>
);

const StatCard = ({ label, value, unit, color, icon, highlight, gold }: { label: string, value: number, unit?: string, color: string, icon: React.ReactNode, highlight?: boolean, gold?: boolean }) => (
  <div className={`bg-slate-900 border ${highlight ? 'border-emerald-500/30 shadow-[0_0_40px_rgba(16,185,129,0.05)]' : gold ? 'border-amber-500/30 shadow-[0_0_40px_rgba(245,158,11,0.1)]' : 'border-slate-800'} p-6 rounded-[32px] shadow-xl relative group overflow-hidden`}>
    <div className={`absolute -right-4 -top-4 p-8 opacity-5 group-hover:opacity-10 transition-opacity ${color}`}>{icon}</div>
    <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3 truncate">{label}</p>
    <p className={`text-xl xl:text-2xl font-black font-mono tracking-tighter tabular-nums ${color}`}>
      {unit === '%' ? value.toFixed(2) + '%' : 'R$ ' + value.toLocaleString('pt-BR', { minimumFractionDigits: 2, notation: value > 1000000 ? 'compact' : 'standard' })}
    </p>
  </div>
);

export default Dashboard;
