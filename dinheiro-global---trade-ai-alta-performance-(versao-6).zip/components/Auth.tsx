
import React, { useState } from 'react';
import { supabase } from '../services/supabase';
import { Logo, ShieldIcon, ActivityIcon, LockIcon, AlertIcon, CheckIcon } from './Icons';

interface AuthProps {
  onSession: (session: any) => void;
}

const Auth: React.FC<AuthProps> = ({ onSession }) => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      if (isSignUp) {
        // Fluxo de Cadastro
        const { data, error: signUpError } = await supabase.auth.signUp({ 
          email: email.trim(), 
          password: password.trim(),
          options: {
            emailRedirectTo: window.location.origin
          }
        });
        
        if (signUpError) throw signUpError;
        
        if (data?.user?.identities?.length === 0) {
          throw new Error('OPERADOR JÁ CADASTRADO: Utilize o login ou solicite recuperação de senha.');
        }

        setSuccessMsg('PROTOCOLO INICIADO: Registro efetuado. Verifique seu e-mail para validar o acesso ao terminal.');
        setIsSignUp(false);
      } else {
        // Fluxo de Login
        const { data, error: signInError } = await supabase.auth.signInWithPassword({ 
          email: email.trim(), 
          password: password.trim() 
        });
        
        if (signInError) {
          if (signInError.message.includes('Email not confirmed')) {
            throw new Error('PENDÊNCIA DE E-MAIL: Acesse seu e-mail e clique no link de validação do DG-AI.');
          }
          if (signInError.message.includes('Invalid login credentials')) {
            throw new Error('ACESSO NEGADO: Verifique seu e-mail ou se já possui um cadastro ativo neste terminal.');
          }
          throw signInError;
        }
        
        if (data.session) onSession(data.session);
      }
    } catch (err: any) {
      console.error('[Auth Error]', err);
      setError(err.message || 'FALHA DE PROTOCOLO: Ocorreu um erro crítico na rede de autenticação.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background FX */}
      <div className="absolute inset-0 neural-bg opacity-10"></div>
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-emerald-500/5 via-transparent to-indigo-500/5 pointer-events-none"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/10 blur-[120px] rounded-full pointer-events-none animate-pulse"></div>

      <div className="relative z-10 w-full max-w-[420px] animate-in fade-in zoom-in-95 duration-700">
        {/* Branding Area */}
        <div className="flex flex-col items-center mb-10">
          <div className="relative mb-6 group">
            <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-full scale-150 group-hover:bg-emerald-500/40 transition-all duration-700"></div>
            <Logo size={90} className="relative z-10" />
          </div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tighter text-center leading-none">
            Dinheiro Global
            <span className="text-emerald-500 block text-2xl mt-1">Terminal de Performance</span>
          </h1>
          <div className="flex items-center gap-2 mt-4 opacity-50">
            <div className="w-8 h-[1px] bg-slate-500"></div>
            <p className="text-slate-500 text-[9px] font-black uppercase tracking-[0.4em]">Inteligência Artificial de Mercado</p>
            <div className="w-8 h-[1px] bg-slate-500"></div>
          </div>
        </div>

        {/* Auth Card */}
        <div className="bg-slate-900/60 backdrop-blur-3xl border border-slate-800 p-8 md:p-10 rounded-[40px] shadow-2xl relative overflow-hidden">
          <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent ${isSignUp ? 'via-indigo-500/40' : 'via-emerald-500/40'} to-transparent`}></div>
          
          <form onSubmit={handleAuth} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Identificação do Operador</label>
              <input 
                type="email" 
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white outline-none focus:ring-2 focus:ring-emerald-500/30 transition-all text-sm font-medium placeholder:text-slate-700" 
                placeholder="Ex: operador@mercado.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center px-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Senha de Criptografia</label>
              </div>
              <input 
                type="password" 
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white outline-none focus:ring-2 focus:ring-emerald-500/30 transition-all text-sm font-medium placeholder:text-slate-700" 
                placeholder="Mínimo 6 caracteres"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
              />
            </div>

            {error && (
              <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-2xl flex items-start gap-3 animate-in shake duration-300">
                <AlertIcon className="text-rose-500 shrink-0 mt-0.5" size={16} />
                <p className="text-[11px] text-rose-400 font-bold leading-tight uppercase tracking-tight">{error}</p>
              </div>
            )}

            {successMsg && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-2xl flex items-start gap-3 animate-in slide-in-from-top-2">
                <CheckIcon className="text-emerald-500 shrink-0 mt-0.5" size={16} />
                <p className="text-[11px] text-emerald-400 font-bold leading-tight uppercase tracking-tight">{successMsg}</p>
              </div>
            )}

            <button 
              type="submit" 
              disabled={loading}
              className={`group w-full ${isSignUp ? 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/10' : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/10'} text-white py-5 rounded-[20px] font-black uppercase text-xs tracking-[0.2em] shadow-xl transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3 relative overflow-hidden`}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-[shimmer_2s_infinite]"></div>
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  <span className="relative z-10">{isSignUp ? 'Registrar Novo Operador' : 'Autenticar no Terminal'}</span>
                  <ActivityIcon size={18} className="relative z-10" />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-slate-800/50 text-center">
            <button 
              onClick={() => { setIsSignUp(!isSignUp); setError(null); setSuccessMsg(null); }}
              className="text-[10px] font-black text-slate-500 hover:text-emerald-400 uppercase tracking-[0.2em] transition-colors"
            >
              {isSignUp ? 'Já possui registro? LOGIN' : 'Novo por aqui? REGISTRE-SE AGORA'}
            </button>
          </div>
        </div>

        {/* Compliance Footer */}
        <div className="mt-10 flex items-center justify-center gap-6 opacity-30">
          <div className="flex items-center gap-2">
            <ShieldIcon size={12} className="text-slate-400" />
            <span className="text-[8px] font-black uppercase tracking-[0.2em] text-white">SSL Encrypted</span>
          </div>
          <div className="w-1 h-1 bg-slate-700 rounded-full"></div>
          <div className="flex items-center gap-2">
            <LockIcon size={12} className="text-slate-400" />
            <span className="text-[8px] font-black uppercase tracking-[0.2em] text-white">Supabase Node Guard</span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes shimmer { 100% { transform: translateX(100%); } }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-4px); }
          75% { transform: translateX(4px); }
        }
      `}</style>
    </div>
  );
};

export default Auth;
