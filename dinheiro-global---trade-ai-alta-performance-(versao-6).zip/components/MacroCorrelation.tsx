
import React from 'react';
// Fixed: Removed non-existent icon imports TrendingUpIcon and TrendingDownIcon
import { 
  GridIcon, ActivityIcon, ShieldIcon, TargetIcon, 
  AlertIcon, InfoIcon 
} from './Icons';

interface CorrelationCardProps {
  pair: string;
  classification: 'Muito Forte' | 'Forte' | 'Neutra' | 'Fraca' | 'Muito Fraca';
  sense: 'Positiva' | 'Negativa' | 'Nula';
  description: string;
}

const CorrelationCard: React.FC<CorrelationCardProps> = ({ pair, classification, sense, description }) => {
  const isPositive = sense === 'Positiva';
  const isNegative = sense === 'Negativa';
  
  const borderColor = isPositive ? 'border-emerald-500/20' : isNegative ? 'border-rose-500/20' : 'border-slate-700';
  const bgColor = isPositive ? 'bg-emerald-500/5' : isNegative ? 'bg-rose-500/5' : 'bg-slate-800/20';
  const textColor = isPositive ? 'text-emerald-400' : isNegative ? 'text-rose-400' : 'text-slate-400';
  const arrow = isPositive ? '↑ ↑' : isNegative ? '↑ ↓' : '~';

  return (
    <div className={`group relative p-8 rounded-[32px] border ${borderColor} ${bgColor} transition-all hover:scale-[1.02] hover:shadow-2xl flex flex-col justify-between h-full`}>
      <div className="space-y-4">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-black text-white uppercase tracking-tighter leading-tight max-w-[180px]">
            {pair}
          </h3>
          <div className={`text-2xl font-black ${textColor} font-mono tracking-widest`}>
            {arrow}
          </div>
        </div>
        
        <div className="space-y-1">
          <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Força Histórica</p>
          <p className={`text-xs font-black uppercase tracking-tight ${textColor}`}>
            {classification}
          </p>
        </div>

        <div className="space-y-1">
          <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Direção Típica</p>
          <p className="text-[11px] font-bold text-slate-300 uppercase">
            Sentido {sense} {isPositive ? '(Andam Juntos)' : isNegative ? '(Opostos)' : ''}
          </p>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-slate-800/50">
        <p className="text-[12px] text-slate-400 leading-relaxed font-medium italic">
          "{description}"
        </p>
      </div>
    </div>
  );
};

const MacroCorrelation: React.FC = () => {
  const correlations: CorrelationCardProps[] = [
    {
      pair: "S&P 500 x Nasdaq",
      classification: "Muito Forte",
      sense: "Positiva",
      description: "Ambos representam o apetite por risco global. Quando o mercado americano sobe, as empresas de tecnologia tendem a liderar o movimento."
    },
    {
      pair: "S&P 500 x DXY",
      classification: "Forte",
      sense: "Negativa",
      description: "O dólar global costuma atuar como porto seguro. Quando as bolsas caem, investidores buscam proteção no caixa em moeda americana."
    },
    {
      pair: "Ibovespa x USD/BRL",
      classification: "Forte",
      sense: "Negativa",
      description: "No cenário brasileiro, o risco costuma ser precificado em ambas as pontas: real desvalorizado e bolsa em queda simultânea."
    },
    {
      pair: "Ibovespa x DI Futuro",
      classification: "Muito Forte",
      sense: "Negativa",
      description: "Juros altos encarecem o crédito e aumentam a atratividade da Renda Fixa, retirando capital de risco do mercado acionário."
    },
    {
      pair: "USD/BRL x DI Futuro",
      classification: "Forte",
      sense: "Positiva",
      description: "Aumento do risco país (fiscal/inflacionário) costuma elevar as taxas de juros futuras e pressionar o câmbio para cima."
    },
    {
      pair: "DXY x EUR/USD",
      classification: "Muito Forte",
      sense: "Negativa",
      description: "O Euro possui o maior peso na cesta do DXY. Movimentos de força do dólar global resultam diretamente na queda do Euro."
    },
    {
      pair: "Petróleo x USD/BRL",
      classification: "Fraca",
      sense: "Negativa",
      description: "O petróleo é cotado em dólar. Altas na commodity costumam favorecer moedas de países exportadores (como o Brasil)."
    },
    {
      pair: "Ouro x DXY",
      classification: "Forte",
      sense: "Negativa",
      description: "O ouro é a reserva de valor milenar e rivaliza com o dólar. Se o dólar perde valor real, o ouro tende a se valorizar."
    },
    {
      pair: "Minério x Ibovespa",
      classification: "Forte",
      sense: "Positiva",
      description: "Empresas ligadas ao minério possuem peso relevante no índice. Ciclos de alta em commodities impulsionam o Ibovespa."
    },
    {
      pair: "Nasdaq x US 10Y (Juros EUA)",
      classification: "Forte",
      sense: "Negativa",
      description: "Empresas de tecnologia (growth) são sensíveis às taxas de juros, pois seus fluxos de caixa futuros são descontados a taxas maiores."
    }
  ];

  return (
    <div className="space-y-12 animate-in fade-in duration-700 pb-20 max-w-7xl mx-auto">
      <header className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-left space-y-2">
          <h1 className="text-3xl font-black flex items-center gap-4 uppercase tracking-tighter text-white">
            <GridIcon className="text-indigo-400" size={32} />
            Mapeamento Macro Educativo
          </h1>
          <p className="text-slate-500 text-[11px] font-black uppercase tracking-[0.4em]">
            Guia Visual de Dinâmica de Ativos • Histórico Global
          </p>
        </div>
        <div className="bg-indigo-500/10 border border-indigo-500/20 px-6 py-3 rounded-full flex items-center gap-3">
          <InfoIcon size={16} className="text-indigo-400" />
          <span className="text-[10px] font-black text-indigo-300 uppercase tracking-widest">Modelo Estático de Consulta</span>
        </div>
      </header>

      <div className="bg-slate-900 border border-slate-800 p-8 rounded-[48px] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-[0.02] pointer-events-none">
          <GridIcon size={300} />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 relative z-10">
          {correlations.map((corr, idx) => (
            <CorrelationCard key={idx} {...corr} />
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-slate-950/40 border border-slate-800 p-8 rounded-[40px] space-y-6">
           <h3 className="text-[11px] font-black text-white uppercase tracking-widest flex items-center gap-2">
             <ShieldIcon size={14} className="text-indigo-400" /> Legenda de Navegação
           </h3>
           <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                 <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]"></div>
                 <span className="text-[10px] font-black text-slate-400 uppercase">Positiva (Subida Mútua)</span>
              </div>
              <div className="flex items-center gap-3">
                 <div className="w-3 h-3 rounded-full bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.3)]"></div>
                 <span className="text-[10px] font-black text-slate-400 uppercase">Negativa (Gangorra)</span>
              </div>
              <div className="flex items-center gap-3">
                 <div className="w-3 h-3 rounded-full bg-slate-600"></div>
                 <span className="text-[10px] font-black text-slate-400 uppercase">Neutra / Descorrelacionada</span>
              </div>
              <div className="flex items-center gap-3 font-mono text-[10px] font-bold text-slate-500">
                 ↑ ↑ / ↑ ↓ Sentido do Fluxo
              </div>
           </div>
        </div>

        <div className="bg-rose-500/5 border border-rose-500/10 p-8 rounded-[40px] flex flex-col justify-center relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-rose-500"><AlertIcon size={80}/></div>
            <div className="flex items-center gap-4 mb-4">
              <ShieldIcon size={24} className="text-rose-500" />
              <h3 className="text-sm font-black text-white uppercase tracking-widest">Termos de Uso Educativo</h3>
            </div>
            <p className="text-[13px] text-slate-400 leading-relaxed font-medium italic">
              "Este painel é apenas educativo e representa correlações históricas típicas de mercado. 
              As relações podem se romper em momentos de crise severa ou mudanças de regime monetário. 
              Não constitui recomendação de investimento e não deve ser utilizado como sinal de compra ou venda."
            </p>
        </div>
      </div>
      
      <div className="text-center pt-8">
        <p className="text-[9px] font-black text-slate-700 uppercase tracking-[0.5em]">Terminal de Inteligência Macro • Base de Dados v1.0 • Estática</p>
      </div>
    </div>
  );
};

export default MacroCorrelation;
