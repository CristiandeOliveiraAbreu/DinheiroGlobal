
import React from 'react';
import { Trade } from '../types';
import { TrashIcon, HistoryIcon } from './Icons';

interface ArchivedHistoryProps {
  trades: Trade[];
  onRestore: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (trade: Trade) => void;
}

const ArchivedHistory: React.FC<ArchivedHistoryProps> = ({ trades, onRestore, onDelete, onEdit }) => {
  const archivedTrades = trades.filter(t => t.archived);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <header>
        <h1 className="text-3xl font-bold uppercase tracking-tight">Arquivos do Sistema</h1>
        <p className="text-slate-400 mt-1">Operações ocultas para fins de análise histórica.</p>
      </header>

      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-800/40 border-b border-slate-800">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Ativo</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Resultado</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {archivedTrades.length === 0 ? (
                <tr><td colSpan={3} className="px-6 py-12 text-center text-slate-600 font-bold uppercase text-[10px] tracking-widest">Arquivo vazio.</td></tr>
              ) : (
                archivedTrades.map((trade) => (
                  <tr key={trade.id} className="group hover:bg-slate-800/20 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-slate-100">{trade.asset}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">{trade.date}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`font-mono font-bold ${trade.profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {trade.currency === 'USD' ? '$' : 'R$'} {trade.profit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right flex justify-end gap-3 items-center">
                      <button onClick={() => onEdit(trade)} className="text-slate-500 hover:text-white text-[9px] font-black uppercase tracking-widest px-3 py-1 bg-slate-800 rounded-lg">Editar</button>
                      <button onClick={() => onRestore(trade.id)} className="text-emerald-500/50 hover:text-emerald-400 transition-colors" title="Desarquivar">
                        <HistoryIcon size={18} />
                      </button>
                      <button onClick={() => { if(confirm("Apagar permanentemente?")) onDelete(trade.id); }} className="text-rose-500/50 hover:text-rose-400 transition-colors" title="Excluir">
                        <TrashIcon size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ArchivedHistory;
