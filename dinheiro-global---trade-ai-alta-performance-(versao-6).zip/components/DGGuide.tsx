
import React, { useState, useEffect, useMemo } from 'react';
import { View, GuideSettings, Asset, Broker, Trade, DiaryEntry, SavedAnalysis } from '../types';
import { TargetIcon, BrainIcon, BankIcon, BriefcaseIcon, ShieldIcon, CheckIcon, XIcon, ActivityIcon, GridIcon, HistoryIcon, InfoIcon } from './Icons';

interface DGGuideProps {
  currentView: View;
  setView: (view: View) => void;
  settings: GuideSettings;
  updateSettings: (s: GuideSettings) => void;
  assets: Asset[];
  brokers: Broker[];
  trades: Trade[];
  diaryEntries: DiaryEntry[];
  analyses: SavedAnalysis[];
  equity: number;
  onboardingStep: number;
  setOnboardingStep: (step: number) => void;
}

const DGGuide: React.FC<DGGuideProps> = ({ 
  currentView, setView, settings, updateSettings, 
  assets, brokers, trades, diaryEntries, analyses, equity,
  onboardingStep, setOnboardingStep
}) => {
  const [showMissions, setShowMissions] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isTipMinimized, setIsTipMinimized] = useState(false);

  // Contextual tips logic
  const contextualTip = useMemo(() => {
    if (assets.length === 0) {
      return { 
        title: 'Dica Operacional', 
        desc: 'Sua biblioteca está vazia. Cadastre ativos para habilitar o monitoramento de ordens.', 
        view: View.Assets 
      };
    }
    if (brokers.length === 0) {
      return { 
        title: 'Dica Financeira', 
        desc: 'Nenhuma corretora vinculada. Configure sua tesouraria para gerir seu caixa.', 
        view: View.CashManager 
      };
    }
    if (analyses.length === 0) {
      return { 
        title: 'Dica Técnica', 
        desc: 'Utilize a IA para mapear zonas de oferta e demanda antes de executar ordens.', 
        view: View.AI 
      };
    }
    if (diaryEntries.length === 0) {
      return { 
        title: 'Dica de Mindset', 
        desc: 'Inicie seu diário de trade para auditar sua disciplina e controle emocional.', 
        view: View.TradeDiary 
      };
    }
    return null;
  }, [assets.length, brokers.length, analyses.length, diaryEntries.length]);

  // Reset tip minimization if the tip content changes (different view requirement)
  useEffect(() => {
    if (contextualTip) {
      setIsTipMinimized(false);
    }
  }, [contextualTip?.view]);

  // Onboarding steps definition
  const onboardingSteps = useMemo(() => [
    {
      title: "Boas-vindas ao Ecossistema DG-AI",
      briefing: "Inicie agora a jornada institucional para gestão e proteção do seu capital em 6 passos estratégicos.",
      actionText: "Vamos começar configurando sua visão de mercado.",
      view: View.Dashboard,
      buttonLabel: "Iniciar Jornada",
      isIntro: true
    },
    {
      title: "1. Inteligência Macro",
      briefing: "O contexto dita a direção. Antes de qualquer ordem, um operador de elite entende as correlações globais.",
      actionText: "Explore como os ativos se movem em conjunto. Entenda a 'gangorra' do mercado antes de avançar.",
      view: View.MacroCorrelation,
      buttonLabel: "Ir para Mapeamento Macro"
    },
    {
      title: "2. Filtro Fundamentalista",
      briefing: "Não opere no escuro. Use nossa IA para identificar quais ações da B3 possuem margem de segurança real.",
      actionText: "Gere um relatório fundamentalista e observe o 'Preço Teto'. Escolha ativos com margem positiva.",
      view: View.FundamentalAnalysis,
      buttonLabel: "Analisar Valuation B3"
    },
    {
      title: "3. Timing Técnico IA",
      briefing: "Onde as instituições estão montando posição? Use a visão computacional para ler o rastro do dinheiro.",
      actionText: "Importe um gráfico e deixe a IA mapear as zonas de oferta e demanda para você.",
      view: View.AI,
      buttonLabel: "Validar Timing Técnico"
    },
    {
      title: "4. Biblioteca de Ativos",
      briefing: "Organização é poder. Cadastre seus ativos escolhidos para habilitar o monitoramento de custódia.",
      actionText: "Adicione os tickers que você decidiu monitorar após as análises anteriores.",
      view: View.Assets,
      buttonLabel: "Configurar Biblioteca"
    },
    {
      title: "5. Tesouraria e Aportes",
      briefing: "Controle sua liquidez. Sem caixa e gestão de corretoras, não há proteção de patrimônio.",
      actionText: "Cadastre sua corretora e realize um aporte fictício ou real para ver o Dashboard ganhar vida.",
      view: View.CashManager,
      buttonLabel: "Gerenciar Tesouraria"
    },
    {
      title: "Jornada Concluída",
      briefing: "Você agora possui a estrutura de um fluxo institucional no seu terminal.",
      actionText: "Seu Dashboard agora refletirá sua inteligência e disciplina. Boas operações!",
      view: View.Dashboard,
      buttonLabel: "Acessar Terminal Completo",
      isOutro: true
    }
  ], []);

  const currentStepData = onboardingSteps[onboardingStep];

  const handleNextStep = () => {
    if (onboardingStep < onboardingSteps.length - 1) {
      const nextStep = onboardingStep + 1;
      setOnboardingStep(nextStep);
      setView(onboardingSteps[nextStep].view);
      setIsMinimized(false);
    } else {
      updateSettings({ ...settings, onboardingCompleted: true });
    }
  };

  const handleBackStep = () => {
    if (onboardingStep > 0) {
      const prevStep = onboardingStep - 1;
      setOnboardingStep(prevStep);
      setView(onboardingSteps[prevStep].view);
      setIsMinimized(false);
    }
  };

  const startAction = () => {
    setIsMinimized(true);
  };

  const skipOnboarding = () => {
    updateSettings({ ...settings, onboardingCompleted: true });
  };

  const missions = useMemo(() => [
    { id: 'm1', label: 'Estudo Macro', check: assets.length > 0 || settings.onboardingCompleted, icon: <GridIcon size={12}/> },
    { id: 'm2', label: 'Análise B3', check: analyses.length > 0 || settings.onboardingCompleted, icon: <ShieldIcon size={12}/> },
    { id: 'm3', label: 'Ativo Cadastrado', check: assets.length > 0, icon: <BriefcaseIcon size={12}/> },
    { id: 'm4', label: 'Aporte Realizado', check: brokers.length > 0 && equity > 0, icon: <BankIcon size={12}/> },
    { id: 'm5', label: 'Audit. Comportamental', check: diaryEntries.length > 0, icon: <BrainIcon size={12}/> }
  ], [brokers, assets, diaryEntries, analyses, settings.onboardingCompleted, equity]);

  if (!settings.enabled) return null;

  return (
    <>
      {/* ONBOARDING BRIEFING MODE */}
      {!settings.onboardingCompleted && !isMinimized && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-500"></div>
          <div className="relative bg-slate-900 border border-indigo-500/30 w-full max-w-lg rounded-[48px] shadow-2xl p-12 animate-in zoom-in-95 duration-300">
             <div className="absolute top-0 right-0 p-10">
               <button onClick={skipOnboarding} className="text-[10px] font-black text-slate-500 uppercase tracking-widest hover:text-white transition-colors">Encerrar Guia</button>
             </div>
             
             <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-indigo-600/20 rounded-xl flex items-center justify-center text-indigo-400">
                   <TargetIcon size={20} />
                </div>
                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">DG-Navegação Guiada • Passo {onboardingStep + 1}/7</p>
             </div>

             <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-6 leading-tight">
               {currentStepData.title}
             </h2>
             <p className="text-slate-400 text-base font-medium leading-relaxed mb-12">
               {currentStepData.briefing}
             </p>

             <div className="flex flex-col gap-4">
               <button 
                 onClick={startAction}
                 className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-6 rounded-2xl font-black uppercase text-xs tracking-[0.2em] transition-all shadow-xl shadow-indigo-600/20 active:scale-95 flex items-center justify-center gap-3"
               >
                 {currentStepData.buttonLabel} <ActivityIcon size={18} />
               </button>
               
               <div className="flex justify-between items-center pt-6">
                  <button 
                    onClick={handleBackStep}
                    disabled={onboardingStep === 0}
                    className="text-[10px] font-black text-slate-500 uppercase tracking-widest hover:text-white disabled:opacity-0 transition-all"
                  >
                    Etapa Anterior
                  </button>
                  <div className="flex gap-2">
                    {onboardingSteps.map((_, i) => (
                      <div key={i} className={`h-1.5 rounded-full transition-all ${i === onboardingStep ? 'w-8 bg-indigo-500' : 'w-2 bg-slate-800'}`}></div>
                    ))}
                  </div>
               </div>
             </div>
          </div>
        </div>
      )}

      {/* ONBOARDING ACTION MODE */}
      {!settings.onboardingCompleted && isMinimized && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 md:left-80 md:translate-x-0 z-[1000] w-full max-w-sm px-4 md:px-0">
           <div className="bg-slate-900/95 backdrop-blur-xl border-2 border-indigo-500/40 rounded-[32px] p-8 shadow-[0_20px_50px_rgba(79,70,229,0.3)] animate-in slide-in-from-bottom-10 duration-500">
              <div className="flex justify-between items-start mb-4">
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Missão Ativa</span>
                 </div>
                 <button onClick={() => setIsMinimized(false)} className="text-slate-500 hover:text-white" title="Ver Explicação">
                    <HistoryIcon size={16} />
                 </button>
              </div>
              
              <h3 className="text-white font-black uppercase text-sm mb-3 tracking-tight">Etapa: {currentStepData.title.split('.').pop()?.trim()}</h3>
              <p className="text-slate-300 text-xs font-bold leading-relaxed mb-8 italic">
                "{currentStepData.actionText}"
              </p>

              <div className="flex gap-3">
                 <button 
                   onClick={handleBackStep}
                   className="flex-1 py-4 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all"
                 >
                   Voltar
                 </button>
                 <button 
                   onClick={handleNextStep}
                   className="flex-[2] py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[9px] font-black uppercase tracking-widest transition-all shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2"
                 >
                   {onboardingStep === onboardingSteps.length - 1 ? 'Finalizar Guia' : 'Próximo Passo'} <CheckIcon size={14}/>
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* POST-ONBOARDING MISSIONS AND TIPS */}
      {settings.onboardingCompleted && (
        <div className="fixed bottom-8 right-8 z-[500] flex flex-col items-end gap-3 pointer-events-none">
          {contextualTip && currentView !== contextualTip.view && (
            <>
              {/* MINIMIZED TIP INDICATOR */}
              {isTipMinimized && (
                <button 
                  onClick={() => setIsTipMinimized(false)}
                  className="w-10 h-10 bg-indigo-600 border border-white/20 rounded-full flex items-center justify-center text-white shadow-2xl pointer-events-auto hover:scale-110 active:scale-90 transition-all animate-pulse"
                  title="Dica disponível"
                >
                  <InfoIcon size={18} />
                </button>
              )}

              {/* EXPANDED TIP BOX */}
              {!isTipMinimized && (
                <div className="bg-indigo-600 text-white p-5 rounded-[24px] shadow-2xl border border-white/20 max-w-xs animate-in slide-in-from-right-10 pointer-events-auto">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[9px] font-black uppercase tracking-widest opacity-70">{contextualTip.title}</span>
                    <button onClick={() => setIsTipMinimized(true)} className="p-1 -mr-1 hover:bg-white/10 rounded-full transition-colors">
                      <XIcon size={12} />
                    </button>
                  </div>
                  <p className="text-xs font-bold leading-tight mb-4">{contextualTip.desc}</p>
                  <button onClick={() => setView(contextualTip.view)} className="text-[9px] font-black uppercase tracking-widest bg-white/10 hover:bg-white/20 py-2 px-4 rounded-lg transition-all w-full">Acessar agora</button>
                </div>
              )}
            </>
          )}

          {/* MISSIONS BUTTON */}
          <button onClick={() => setShowMissions(!showMissions)} className="w-14 h-14 bg-slate-900 border border-slate-800 rounded-full flex items-center justify-center text-emerald-500 shadow-2xl pointer-events-auto hover:scale-110 active:scale-90 transition-all relative">
            <TargetIcon size={24} />
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-emerald-600 text-white rounded-full flex items-center justify-center text-[9px] font-black">{missions.filter(m => m.check).length}</div>
          </button>

          {showMissions && (
            <div className="bg-slate-900 border border-slate-800 w-80 rounded-[32px] shadow-2xl p-8 mb-4 animate-in slide-in-from-bottom-5 pointer-events-auto">
               <div className="flex justify-between items-center mb-6">
                 <h3 className="text-xs font-black text-white uppercase tracking-widest">Missões Operacionais</h3>
                 <button onClick={() => setShowMissions(false)} className="text-slate-500 hover:text-white"><XIcon size={14}/></button>
               </div>
               <div className="space-y-4">
                  {missions.map(mission => (
                    <div key={mission.id} className="flex items-center gap-4">
                       <div className={`w-8 h-8 rounded-xl flex items-center justify-center border transition-all ${mission.check ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-slate-950 border-slate-800 text-slate-600'}`}>
                          {mission.check ? <CheckIcon size={14}/> : mission.icon}
                       </div>
                       <div className="flex-1">
                          <p className={`text-[10px] font-black uppercase tracking-tight ${mission.check ? 'text-slate-300' : 'text-slate-500'}`}>{mission.label}</p>
                          <div className="w-full h-0.5 bg-slate-800 rounded-full mt-1 overflow-hidden">
                             <div className={`h-full transition-all duration-1000 ${mission.check ? 'w-full bg-emerald-500' : 'w-0'}`}></div>
                          </div>
                       </div>
                    </div>
                  ))}
               </div>
               <div className="mt-8 pt-6 border-t border-slate-800/50 text-center">
                  <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest italic">“Inteligência aplicada à gestão do seu capital.”</p>
               </div>
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default DGGuide;
