
import React, { useState, useEffect } from 'react';
import { ExtraIncome, CurrencyType, IncomeType, Broker } from '../types';
import { XIcon, AccountIcon, CheckIcon, BankIcon } from './Icons';

interface IncomeModalProps {
  onClose: () => void;
  onSave: (income: ExtraIncome) => void;
  targetAsset: string;
  brokers: Broker[];
  editingIncome?: ExtraIncome;
}

const IncomeModal: React.FC<IncomeModalProps> = ({ onClose, onSave, targetAsset, brokers, editingIncome }) => {
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<IncomeType>('Dividendo');
  const [currency, setCurrency] = useState<CurrencyType>('BRL');
  const [brokerId, setBrokerId] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (editingIncome) {
      setAmount(editingIncome.amount.toString());
      setType(editingIncome.type);
      setCurrency(editingIncome.currency);
      setBrokerId(editingIncome.brokerId || '');
    }
  }, [editingIncome]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0 || !brokerId || loading || success) return;

    setLoading(true);
    try {
      const incomePayload: ExtraIncome = {
        id: editingIncome?.id || Math.random().toString(36).substr(2, 9),
        assetName: targetAsset.toUpperCase(),
        type,
        amount: parseFloat(amount),
        currency,
        brokerId,
        date: editingIncome?.date || new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }),
        timestamp: editingIncome?.timestamp || Date.now()
      };
      
      await new Promise(resolve => setTimeout(resolve, 600));
      
      onSave(incomePayload);
      setSuccess(true);
      
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err) {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl" onClick={onClose}></div>
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-md rounded-[32px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="px-8 py-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
          <div className="flex items-center gap-3">
            <AccountIcon className="text-emerald-400" />
            <h2 className="text-xl font-bold uppercase tracking-tight">{editingIncome ? 'Ajustar Performance' : `Proventos: ${targetAsset}`}</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-700 rounded-full transition-colors text-slate-500 hover:text-white">
            <XIcon size={20}/>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Instituição de Recebimento</label>
              <select 
                value={brokerId} 
                onChange={e => setBrokerId(e.target.value)} 
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs font-black text-white uppercase outline-none focus:ring-2 focus:ring-emerald-500/30 transition-all"
                required
              >
                <option value="">SELECIONAR CORRETORA...</option>
                {brokers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Tipo de Crédito</label>
              <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-2xl border border-slate-800">
                <button type="button" onClick={() => setType('Dividendo')} className={`py-3 rounded-xl text-[9px] font-black transition-all ${type === 'Dividendo' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500'}`}>DIVIDENDOS</button>
                <button type="button" onClick={() => setType('Juros')} className={`py-3 rounded-xl text-[9px] font-black transition-all ${type === 'Juros' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500'}`}>JUROS (JCP)</button>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Valor do Crédito</label>
                <div className="flex gap-2">
                   <button type="button" onClick={() => setCurrency('BRL')} className={`text-[9px] font-black px-2 rounded-md ${currency === 'BRL' ? 'bg-slate-800 text-white' : 'text-slate-600'}`}>BRL</button>
                   <button type="button" onClick={() => setCurrency('USD')} className={`text-[9px] font-black px-2 rounded-md ${currency === 'USD' ? 'bg-slate-800 text-white' : 'text-slate-600'}`}>USD</button>
                </div>
              </div>
              <input 
                type="number" 
                step="any" 
                autoFocus
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-2xl font-mono font-black text-white outline-none focus:ring-2 focus:ring-emerald-500/30 transition-all" 
                placeholder="0.00" 
                value={amount} 
                onChange={e => setAmount(e.target.value)} 
                required 
              />
            </div>
          </div>
          
          <button 
            type="submit" 
            disabled={loading || success} 
            className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl transition-all flex items-center justify-center gap-3 ${success ? 'bg-emerald-500 text-white' : 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95'}`}
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : success ? (
              <><CheckIcon size={18} /> Registro Atualizado!</>
            ) : (
              editingIncome ? 'Salvar Alterações' : 'Efetivar Lançamento'
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default IncomeModal;
