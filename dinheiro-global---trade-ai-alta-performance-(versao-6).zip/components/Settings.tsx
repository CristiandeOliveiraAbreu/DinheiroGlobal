
import React, { useState, useEffect } from 'react';
import { ArchiveIcon, TrashIcon, WalletIcon, ActivityIcon, CheckIcon, AlertIcon, PlusIcon, XIcon, TargetIcon } from './Icons';
import SecurityModal from './SecurityModal';
import { GuideSettings } from '../types';

interface SettingsProps {
  onArchiveRange: () => void;
  onReset: () => void;
  tradeCount: number;
  currentFetchedRate: number;
  manualRate: number | null;
  onUpdateManualRate: (rate: number | null) => void;
  onSeedDemo?: () => void;
  guideSettings: GuideSettings;
  onUpdateGuideSettings: (s: GuideSettings) => void;
}

const Settings: React.FC<SettingsProps> = ({ 
  onArchiveRange, 
  onReset, 
  tradeCount, 
  currentFetchedRate, 
  manualRate, 
  onUpdateManualRate,
  onSeedDemo,
  guideSettings,
  onUpdateGuideSettings
}) => {
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [tempManualRate, setTempManualRate] = useState(manualRate?.toString() || '');

  useEffect(() => {
    setTempManualRate(manualRate?.toString() || '');
  }, [manualRate]);

  const handleSaveRate = () => {
    const rate = parseFloat(tempManualRate);
    if (isNaN(rate) || rate <= 0) {
      alert("Insira um valor numérico válido para a cotação.");
      return;
    }
    onUpdateManualRate(rate);
  };

  const handleClearRate = () => {
    onUpdateManualRate(null);
    setTempManualRate('');
  };

  const toggleGuide = () => {
    onUpdateGuideSettings({ ...guideSettings, enabled: !guideSettings.enabled });
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-5xl mx-auto">
      <header>
        <h1 className="text-3xl font-black uppercase tracking-tight">Ajustes Operacionais</h1>
        <p className="text-slate-400 mt-1 font-medium">Controle de ambiente, câmbio institucional e manutenção de dados.</p>
      </header>

      <div className="grid md:grid-cols-2 gap-8">
        {/* DG-Navegação Guiada */}
        <div className="bg-slate-900 border border-slate-800 rounded-[40px] p-10 flex flex-col shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-all"><TargetIcon size={100} /></div>
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-500">
              <TargetIcon size={28} />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white">DG-Navegação Guiada</h2>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Modo Assistido • Onboarding</p>
            </div>
          </div>
          <p className="text-slate-400 text-sm font-medium mb-8 leading-relaxed">
            Ative o sistema de navegação guiada para receber orientações contextuais e missões progressivas seguindo o fluxo institucional de decisão.
          </p>
          <div className="mt-auto">
            <button 
              onClick={toggleGuide}
              className={`w-full py-5 rounded-[24px] font-black uppercase text-[10px] tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl active:scale-95 ${guideSettings.enabled ? 'bg-indigo-600/10 border border-indigo-500/30 text-indigo-400' : 'bg-slate-800 text-slate-500 border border-slate-700'}`}
            >
              {guideSettings.enabled ? (
                <><CheckIcon size={18} /> Navegação Ativa</>
              ) : (
                <><XIcon size={18} /> Navegação Desativada</>
              )}
            </button>
            {guideSettings.onboardingCompleted && (
               <button 
                onClick={() => onUpdateGuideSettings({ ...guideSettings, onboardingCompleted: false, enabled: true })}
                className="w-full text-[9px] font-black text-slate-600 hover:text-slate-400 uppercase tracking-widest mt-4 py-2"
               >
                 Reiniciar Sequência de Onboarding
               </button>
            )}
          </div>
        </div>

        {/* Configuração de Câmbio */}
        <div className="bg-slate-900 border border-slate-800 rounded-[40px] p-10 flex flex-col shadow-2xl">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-500">
              <WalletIcon size={28} />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white">Câmbio USD/BRL</h2>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Cotação Global</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-slate-950 p-6 rounded-[32px] border border-slate-800/50 space-y-6">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Cotação IA Live</span>
                <span className="text-emerald-400 font-mono font-black">R$ {currentFetchedRate.toFixed(4)}</span>
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block ml-1">Fixar Câmbio Manual</label>
                <div className="flex gap-3">
                  <input 
                    type="number" 
                    step="0.01" 
                    value={tempManualRate} 
                    onChange={(e) => setTempManualRate(e.target.value)} 
                    placeholder="Ex: 5.62" 
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl p-4 text-white font-mono font-black outline-none focus:ring-2 focus:ring-amber-500/30 transition-all" 
                  />
                  <button onClick={handleSaveRate} className="px-8 bg-amber-600 hover:bg-amber-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-xl active:scale-95">Salvar</button>
                </div>
              </div>
              {manualRate && (
                <button onClick={handleClearRate} className="w-full flex items-center justify-center gap-2 bg-slate-800/50 hover:bg-rose-500/10 hover:text-rose-400 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-400 border border-slate-800">
                  <XIcon size={14} /> Remover Ajuste Manual
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Ambiente de Teste */}
        <div className="bg-slate-900 border border-slate-800 rounded-[40px] p-10 flex flex-col shadow-2xl">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-500">
              <ActivityIcon size={28} />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white">Modo Sandbox</h2>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Dados de Teste</p>
            </div>
          </div>
          <p className="text-slate-400 text-sm font-medium mb-8 leading-relaxed">
            Popule instantaneamente o seu terminal com ativos, corretoras e aportes fictícios para testar a inteligência do Dashboard.
          </p>
          <button 
            onClick={() => onSeedDemo?.()}
            className="w-full bg-indigo-600 hover:bg-indigo-500 py-5 rounded-[24px] font-black uppercase text-[10px] tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl shadow-indigo-600/20 active:scale-95"
          >
            <PlusIcon size={18} /> Injetar Demonstração
          </button>
        </div>

        {/* Reset Total */}
        <div className="bg-rose-950/10 border border-rose-900/30 rounded-[40px] p-10 flex flex-col shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5"><TrashIcon size={100} /></div>
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 bg-rose-500/10 rounded-2xl flex items-center justify-center text-rose-500">
              <TrashIcon size={28} />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white">Zona de Risco</h2>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Reset de Fábrica</p>
            </div>
          </div>
          <p className="text-rose-200/50 text-sm font-medium mb-8 leading-relaxed">
            Apaga permanentemente todos os ativos, ordens, corretoras e análises. Esta ação não pode ser desfeita.
          </p>
          <button onClick={() => setShowSecurityModal(true)} className="w-full bg-rose-600 hover:bg-rose-500 py-5 rounded-[24px] font-black uppercase text-[10px] tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl shadow-rose-600/20 active:scale-95">
            <TrashIcon size={18} /> Limpar Base de Dados
          </button>
        </div>
      </div>

      {showSecurityModal && (
        <SecurityModal 
          onClose={() => setShowSecurityModal(false)}
          onConfirm={() => { setShowSecurityModal(false); onReset(); }}
          title="Autorizar Reset Total"
          description="Você está prestes a deletar todos os dados do sistema. Digite as credenciais de administrador para confirmar."
        />
      )}
    </div>
  );
};

export default Settings;
