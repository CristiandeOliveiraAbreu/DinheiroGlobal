
import React, { useState, useEffect, useRef } from 'react';
import { B3WeeklyReport, ReportStatus, B3StockData } from '../types';
import { generateB3ReportAsync } from '../services/b3Report';
import { 
  XIcon, RadarIcon, CheckIcon, AlertIcon, TargetIcon, 
  FileDownIcon, HistoryIcon, ActivityIcon,
  BriefcaseIcon, ShieldIcon, TrashIcon, MoneyIcon, ArchiveIcon, EditIcon, CalculatorIcon
} from './Icons';

interface B3ReportModalProps {
  onClose: () => void;
  addNotification?: (type: 'success' | 'error' | 'info', message: string) => void;
}

const STORAGE_REPORTS = 'dg_b3_reports_fast_v2';
const STORAGE_B3_CREDITS = 'dg_b3_report_daily_credits';
const DAILY_LIMIT = 3;

const B3ReportModal: React.FC<B3ReportModalProps> = ({ onClose, addNotification }) => {
  const [history, setHistory] = useState<B3WeeklyReport[]>(() => {
    const saved = localStorage.getItem(STORAGE_REPORTS);
    return saved ? JSON.parse(saved) : [];
  });

  const [activeReport, setActiveReport] = useState<B3WeeklyReport | null>(history.length > 0 ? history[0] : null);
  const [status, setStatus] = useState<ReportStatus>('aguardando');
  const [statusMessage, setStatusMessage] = useState('Pronto para iniciar auditoria.');
  const [countdown, setCountdown] = useState(30);
  const [view, setView] = useState<'current' | 'history'>('current');
  const [editingStockId, setEditingStockId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<string>('');
  const [isRecalculating, setIsRecalculating] = useState(false);
  const [pendingRecalc, setPendingRecalc] = useState<string[]>([]);
  const [credits, setCredits] = useState(DAILY_LIMIT);
  
  const timerRef = useRef<any>(null);

  // Gestão de Créditos Diários
  useEffect(() => {
    const today = new Date().toLocaleDateString('pt-BR');
    const stored = localStorage.getItem(STORAGE_B3_CREDITS);
    
    if (stored) {
      const { date, remaining } = JSON.parse(stored);
      if (date === today) {
        setCredits(remaining);
      } else {
        const newData = { date: today, remaining: DAILY_LIMIT };
        localStorage.setItem(STORAGE_B3_CREDITS, JSON.stringify(newData));
        setCredits(DAILY_LIMIT);
      }
    } else {
      const newData = { date: today, remaining: DAILY_LIMIT };
      localStorage.setItem(STORAGE_B3_CREDITS, JSON.stringify(newData));
      setCredits(DAILY_LIMIT);
    }
  }, []);

  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const handleGenerate = async () => {
    if (status === 'processando') return;
    if (credits <= 0) {
      if (addNotification) addNotification('error', "Limite de créditos diários atingido.");
      return;
    }

    setCountdown(45);
    setStatus('processando');
    setStatusMessage('Iniciando motores de busca fundamentalista...');
    
    timerRef.current = setInterval(() => {
      setCountdown(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    try {
      const newReport = await generateB3ReportAsync((p, s, msg) => {
        if (msg) setStatusMessage(msg);
        if (s === 'concluído') {
          clearInterval(timerRef.current);
          setStatus('concluído');
        }
      });
      
      const updatedHistory = [newReport, ...history].slice(0, 15);
      setHistory(updatedHistory);
      localStorage.setItem(STORAGE_REPORTS, JSON.stringify(updatedHistory));
      setActiveReport(newReport);
      setView('current');
      setPendingRecalc([]);

      // Atualiza e salva créditos
      const today = new Date().toLocaleDateString('pt-BR');
      const newRemaining = Math.max(0, credits - 1);
      setCredits(newRemaining);
      localStorage.setItem(STORAGE_B3_CREDITS, JSON.stringify({ date: today, remaining: newRemaining }));
      
      if (addNotification) addNotification('success', "Novo Relatório de Auditoria Gerado!");
    } catch (err: any) {
      clearInterval(timerRef.current);
      setStatus('erro');
      setStatusMessage(err.message || 'Falha na comunicação com o servidor de dados.');
    }
  };

  const handlePrint = (report: B3WeeklyReport | null) => {
    if (!report) return;
    const originalTitle = document.title;
    const cleanDate = report.data_relatorio.replace(/\//g, '-');
    document.title = `Relatorio_DG_AI_${cleanDate}`;
    setActiveReport(report);
    setTimeout(() => {
      window.print();
      document.title = originalTitle;
    }, 100);
  };

  const deleteFromHistory = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = history.filter(h => h.id !== id);
    setHistory(updated);
    localStorage.setItem(STORAGE_REPORTS, JSON.stringify(updated));
    if (activeReport?.id === id) setActiveReport(updated[0] || null);
  };

  const setManualPricePending = (stockId: string, newPriceRaw: string) => {
    if (!activeReport) return;
    const newPrice = parseFloat(newPriceRaw);
    if (isNaN(newPrice) || newPrice <= 0) {
      setEditingStockId(null);
      return;
    }

    const updatedStocks = activeReport.top_40.map(stock => {
      if (stock.ativo === stockId) {
        return { 
          ...stock, 
          preco_manual: newPrice,
          ajustado_em: new Date().toLocaleString('pt-BR')
        };
      }
      return stock;
    });

    setActiveReport({ ...activeReport, top_40: updatedStocks });
    if (!pendingRecalc.includes(stockId)) {
      setPendingRecalc(prev => [...prev, stockId]);
    }
    setEditingStockId(null);
  };

  const handleRecalculateMargins = async () => {
    if (!activeReport || pendingRecalc.length === 0) return;
    setIsRecalculating(true);
    await new Promise(r => setTimeout(r, 800));
    const updatedStocks = activeReport.top_40.map(stock => {
      if (stock.preco_manual && pendingRecalc.includes(stock.ativo)) {
        const newPrice = stock.preco_manual;
        const oldPrice = stock.preco_validado;
        const ratio = newPrice / oldPrice;
        const newMargin = ((stock.preco_teto_final / newPrice) - 1) * 100;
        const newDY = stock.dividend_yield / ratio;
        const newPL = stock.pl * ratio;
        const newPVP = stock.pvp * ratio;
        let newClass: B3StockData['classificacao'] = 'Cara';
        if (newMargin > 20) newClass = 'Excelente';
        else if (newMargin > 5) newClass = 'Boa';
        else if (newMargin > -5) newClass = 'Neutra';
        return {
          ...stock,
          preco_validado: newPrice,
          margem_seguranca: newMargin,
          dividend_yield: newDY,
          pl: newPL,
          pvp: newPVP,
          classificacao: newClass
        };
      }
      return stock;
    });
    updatedStocks.sort((a, b) => {
      const rank: Record<string, number> = { 'Excelente': 3, 'Boa': 2, 'Neutra': 1, 'Cara': 0 };
      if (rank[b.classificacao] !== rank[a.classificacao]) return rank[b.classificacao] - rank[a.classificacao];
      return b.margem_seguranca - a.margem_seguranca;
    });
    const mostDiscounted = [...updatedStocks].sort((a, b) => b.margem_seguranca - a.margem_seguranca)[0];
    const mostExpensive = [...updatedStocks].sort((a, b) => a.margem_seguranca - b.margem_seguranca)[0];
    const avgMargin = updatedStocks.reduce((sum, s) => sum + s.margem_seguranca, 0) / updatedStocks.length;
    const updatedReport: B3WeeklyReport = {
      ...activeReport,
      top_40: updatedStocks,
      resumo: {
        ...activeReport.resumo,
        acao_mais_descontada: mostDiscounted.ativo,
        acao_mais_cara: mostExpensive.ativo,
        margem_media: `${avgMargin.toFixed(2)}%`
      }
    };
    setActiveReport(updatedReport);
    setHistory(history.map(h => h.id === updatedReport.id ? updatedReport : h));
    localStorage.setItem(STORAGE_REPORTS, JSON.stringify(history.map(h => h.id === updatedReport.id ? updatedReport : h)));
    setPendingRecalc([]);
    setIsRecalculating(false);
    if (addNotification) addNotification('success', " Valuation e margens recalculados com sucesso.");
  };

  return (
    <div className="fixed inset-0 z-[400] flex items-center justify-center p-4 print:p-0 print:bg-white print:static overflow-hidden">
      <style>{`
        @media print {
          @page { margin: 15mm; size: portrait; }
          body { background: white !important; color: #0f172a !important; font-family: 'Inter', sans-serif !important; }
          .no-print { display: none !important; }
          .print-area { position: absolute !important; left: 0 !important; top: 0 !important; width: 100% !important; height: auto !important; background: white !important; padding: 0 !important; box-shadow: none !important; border: none !important; border-radius: 0 !important; overflow: visible !important; }
          .custom-scrollbar { overflow: visible !important; max-height: none !important; }
          .print-header { border-bottom: 3px solid #0f172a !important; margin-bottom: 30px !important; padding-bottom: 20px !important; }
          .print-card { background: #f8fafc !important; border: 1px solid #e2e8f0 !important; page-break-inside: avoid; }
          table { width: 100% !important; border-collapse: collapse !important; page-break-inside: auto; }
          tr { page-break-inside: avoid; page-break-after: auto; }
          thead { display: table-header-group; }
          th { background: #f1f5f9 !important; border-bottom: 2px solid #cbd5e1 !important; color: #0f172a !important; padding: 12px !important; font-size: 10px !important; }
          td { border-bottom: 1px solid #e2e8f0 !important; padding: 12px !important; font-size: 11px !important; color: #334155 !important; }
        }
      `}</style>

      <div className="absolute inset-0 bg-slate-950/98 backdrop-blur-3xl animate-in fade-in duration-300 no-print" onClick={onClose}></div>
      
      <div className="print-area relative bg-slate-900 border border-slate-800 w-full max-w-[95vw] h-[92vh] rounded-[48px] shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-500 print:h-auto print:max-w-none print:shadow-none print:border-none print:rounded-none">
        
        <div className="print-header p-8 border-b border-slate-800 bg-slate-800/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 print:p-6 print:bg-white print:border-slate-900">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 to-emerald-600 rounded-[24px] flex items-center justify-center text-white shadow-lg no-print">
               <ShieldIcon size={32}/>
            </div>
            <div>
              <h2 className="text-3xl font-black uppercase tracking-tighter text-white print:text-slate-900">Relatório B3 Fundamentalista</h2>
              <div className="flex flex-col md:flex-row md:items-center gap-4 mt-2 no-print">
                <div className="flex items-center gap-2">
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] print:text-slate-500">Auditoria DG-AI • Inteligência de Mercado</p>
                  {activeReport && <span className="bg-slate-800 text-slate-400 text-[9px] font-black px-2 py-0.5 rounded-full border border-slate-700">{activeReport.data_relatorio}</span>}
                </div>
                {/* INDICADOR DE CRÉDITOS - ESTILO REQUISITADO */}
                <div className="bg-slate-950 border border-slate-800 px-5 py-2.5 rounded-full flex items-center gap-4 min-w-[210px] shadow-inner">
                  <div className={`w-2 h-2 rounded-full animate-pulse ${credits > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Créditos Operacionais</span>
                      <span className={`text-[10px] font-mono font-black ${credits > 0 ? 'text-white' : 'text-rose-500'}`}>{credits}/{DAILY_LIMIT}</span>
                    </div>
                    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-1000 ${credits > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} 
                        style={{ width: `${(credits / DAILY_LIMIT) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3 no-print">
             {pendingRecalc.length > 0 && view === 'current' && (
               <button 
                onClick={handleRecalculateMargins} 
                disabled={isRecalculating}
                className={`px-8 py-4 bg-amber-600 hover:bg-amber-500 text-white rounded-2xl transition-all flex items-center gap-3 shadow-lg shadow-amber-600/20 active:scale-95 animate-pulse ${isRecalculating ? 'opacity-50 cursor-not-allowed' : ''}`}
               >
                 {isRecalculating ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <CalculatorIcon size={20}/>}
                 <span className="text-[10px] font-black uppercase tracking-widest">Recalcular Margens ({pendingRecalc.length})</span>
               </button>
             )}
             {activeReport && view === 'current' && (
               <button onClick={() => handlePrint(activeReport)} className="px-6 py-4 bg-emerald-600 hover:bg-emerald-500 rounded-2xl text-white transition-all flex items-center gap-3 shadow-lg shadow-emerald-600/20 active:scale-95">
                 <ArchiveIcon size={20}/><span className="text-[10px] font-black uppercase tracking-widest">Arquivar PDF</span>
               </button>
             )}
             <button onClick={() => setView(view === 'current' ? 'history' : 'current')} className={`p-4 rounded-2xl transition-all flex items-center gap-2 ${view === 'history' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-300'}`}>
                <HistoryIcon size={20}/><span className="text-[10px] font-black uppercase tracking-widest px-2">{view === 'history' ? 'Voltar' : 'Histórico'}</span>
             </button>
             <button onClick={onClose} className="p-4 bg-slate-800 hover:bg-slate-700 rounded-full text-slate-400 shadow-xl"><XIcon size={24}/></button>
          </div>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col">
          {status === 'processando' ? (
            <div className="flex-1 flex flex-col items-center justify-center p-20 text-center animate-in fade-in">
              <div className="relative mb-10">
                <div className="w-24 h-24 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <RadarIcon size={32} className="text-emerald-500 animate-pulse" />
                </div>
              </div>
              <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-2">{statusMessage}</h3>
              <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em]">Varredura em progresso • Estimativa: {countdown}s</p>
              <div className="w-full max-w-md h-1.5 bg-slate-950 rounded-full mt-8 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-emerald-500 to-blue-500 transition-all duration-1000" style={{ width: `${Math.min(95, ((45 - countdown) / 45) * 100)}%` }}></div>
              </div>
            </div>
          ) : status === 'erro' ? (
            <div className="flex-1 flex flex-col items-center justify-center p-20 text-center animate-in zoom-in-95">
              <div className="w-20 h-20 bg-rose-500/10 rounded-[32px] flex items-center justify-center text-rose-500 mb-8 border border-rose-500/20">
                <AlertIcon size={40} />
              </div>
              <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-4">Falha na Geração</h3>
              <p className="text-slate-400 text-sm max-w-md mb-10 leading-relaxed font-medium">"{statusMessage}"</p>
              <button 
                onClick={handleGenerate} 
                disabled={credits <= 0}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white px-12 py-5 rounded-[28px] font-black uppercase text-[12px] tracking-widest transition-all shadow-xl active:scale-95"
              >
                Tentar Auditoria Novamente
              </button>
            </div>
          ) : view === 'history' ? (
            <div className="flex-1 flex flex-col p-10 space-y-6 overflow-y-auto custom-scrollbar no-print">
               <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Arquivo de Auditorias</h3>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Seu histórico local de inteligência fundamentalista.</p>
                  </div>
                  <button 
                    onClick={handleGenerate} 
                    disabled={credits <= 0}
                    className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white px-8 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all"
                  >
                    {credits > 0 ? 'Nova Análise' : 'Sem Créditos Hoje'}
                  </button>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {history.length === 0 ? (
                   <div className="col-span-full py-24 bg-slate-900/40 border-2 border-dashed border-slate-800 rounded-[40px] flex flex-col items-center justify-center text-slate-600">
                      <ArchiveIcon size={48} className="mb-4 opacity-10" />
                      <p className="text-[10px] font-black uppercase tracking-widest">Nenhum relatório arquivado</p>
                   </div>
                 ) : (
                   history.map(rep => (
                     <div key={rep.id} className="group bg-slate-800/40 hover:bg-slate-800 border border-slate-800 p-6 rounded-[32px] flex justify-between items-center transition-all cursor-pointer" onClick={() => { setActiveReport(rep); setView('current'); }}>
                        <div className="flex items-center gap-5">
                           <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-emerald-400 font-mono font-black text-lg border border-slate-700">{rep.score_dgai}</div>
                           <div><p className="text-base font-black text-white">{rep.data_relatorio}</p><p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Score DG-AI • Top 40</p></div>
                        </div>
                        <button onClick={(e) => deleteFromHistory(rep.id, e)} className="p-3 bg-slate-900 hover:bg-rose-900/20 text-slate-600 hover:text-rose-500 rounded-xl transition-all"><TrashIcon size={16}/></button>
                     </div>
                   ))
                 )}
               </div>
            </div>
          ) : activeReport ? (
            <div className="flex-1 flex flex-col overflow-hidden print:overflow-visible">
               <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-8 bg-slate-950/40 border-b border-slate-800 print:grid-cols-5 print:p-6 print:bg-white">
                  <div className="print-card bg-gradient-to-br from-indigo-900/20 to-emerald-900/20 border border-emerald-500/20 p-5 rounded-[24px] flex items-center gap-4">
                     <div className="w-12 h-12 bg-emerald-600/20 rounded-2xl flex items-center justify-center text-emerald-400 font-mono font-black text-xl">{activeReport.score_dgai}</div>
                     <div className="min-w-0">
                       <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest mb-1">Score DG-AI</p>
                       <p className="text-xs font-bold text-white uppercase print:text-slate-900 truncate">{activeReport.score_dgai > 50 ? 'Oportuno' : 'Aguardar'}</p>
                     </div>
                  </div>
                  <SummaryCard label="Oportunidade" value={activeReport.resumo.acao_mais_descontada} />
                  <SummaryCard label="Maior Ágio" value={activeReport.resumo.acao_mais_cara} />
                  <SummaryCard label="Margem Média" value={activeReport.resumo.margem_media} />
                  <SummaryCard label="Setor Foco" value={activeReport.resumo.setor_mais_descontado} />
               </div>

               <div className="flex-1 overflow-auto custom-scrollbar p-0 print:overflow-visible">
                 <div className="p-8 print:p-0">
                    {pendingRecalc.length > 0 && (
                      <div className="mb-6 p-4 bg-amber-600/10 border border-amber-600/30 rounded-2xl flex items-center justify-between animate-in slide-in-from-top-4 no-print">
                         <div className="flex items-center gap-3">
                           <AlertIcon className="text-amber-500" />
                           <p className="text-xs font-black uppercase text-amber-500 tracking-widest">
                             Existem {pendingRecalc.length} ativo(s) com preços ajustados aguardando recalculo de margens e valuation.
                           </p>
                         </div>
                         <button onClick={handleRecalculateMargins} className="bg-amber-600 hover:bg-amber-500 text-white px-6 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all">Recalcular Agora</button>
                      </div>
                    )}

                    <div className="print-card bg-slate-800/5 p-6 rounded-3xl border border-slate-800 mb-8 print:bg-slate-50 print:border-slate-200">
                       <p className="text-[13px] text-slate-400 font-medium leading-relaxed italic print:text-slate-800">
                          <span className="text-emerald-400 font-black uppercase text-[10px] mr-2 block mb-1">Parecer DG-AI Informativo:</span>
                          "{activeReport.resumo.texto_informativo}"
                       </p>
                    </div>
                    
                    <table className="w-full text-left border-collapse">
                      <thead className="sticky top-0 z-10 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 print:static print:bg-white print:border-b-2 print:border-slate-900">
                        <tr className="text-[8px] font-black text-slate-500 uppercase tracking-widest print:text-slate-900">
                          <th className="px-6 py-5">Ativo</th>
                          <th className="px-6 py-5">Cotação Atual</th>
                          <th className="px-6 py-5">Preço Teto</th>
                          <th className="px-6 py-5">Margem %</th>
                          <th className="px-6 py-5">DY %</th>
                          <th className="px-6 py-5">P/L</th>
                          <th className="px-6 py-5">P/VP</th>
                          <th className="px-6 py-5 text-right">Classificação</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/50 print:divide-slate-200">
                        {activeReport.top_40.map((stock) => {
                          const isDirty = pendingRecalc.includes(stock.ativo);
                          const displayPrice = stock.preco_manual || stock.preco_validado;
                          
                          return (
                            <tr key={stock.ativo} className="hover:bg-slate-800/10 transition-colors print:hover:bg-transparent">
                              <td className="px-6 py-5">
                                 <div className="flex items-center gap-2">
                                    <span className="font-black text-white text-base tracking-tighter print:text-slate-900">{stock.ativo}</span>
                                    {stock.preco_manual && (
                                      <span className={`px-1.5 py-0.5 rounded-md text-[8px] font-black uppercase no-print ${isDirty ? 'bg-amber-600 text-white animate-pulse' : 'bg-amber-500/20 text-amber-500'}`}>
                                        {isDirty ? 'Pendente' : 'Ajustado'}
                                      </span>
                                    )}
                                 </div>
                                 <div className="text-[7px] text-slate-500 font-bold uppercase mt-0.5">{stock.setor}</div>
                              </td>
                              <td className="px-6 py-5">
                                 {editingStockId === stock.ativo ? (
                                   <div className="flex items-center gap-2 animate-in fade-in zoom-in-95 duration-200">
                                     <input 
                                      autoFocus 
                                      type="number" 
                                      step="0.01" 
                                      className="bg-slate-950 border border-emerald-500 rounded-lg px-3 py-2 text-xs w-24 text-white font-mono" 
                                      value={tempPrice} 
                                      onChange={e => setTempPrice(e.target.value)} 
                                      onBlur={() => setManualPricePending(stock.ativo, tempPrice)} 
                                      onKeyDown={e => e.key === 'Enter' && setManualPricePending(stock.ativo, tempPrice)} 
                                     />
                                   </div>
                                 ) : (
                                   <div className="group/price flex items-center gap-3">
                                     <span className={`text-sm font-mono font-black ${stock.preco_manual ? 'text-amber-400' : 'text-slate-300'} print:text-slate-900`}>R$ {displayPrice.toFixed(2)}</span>
                                     <button 
                                      onClick={() => { setEditingStockId(stock.ativo); setTempPrice(displayPrice.toFixed(2)); }} 
                                      className="opacity-0 group-hover/price:opacity-100 p-1.5 hover:bg-slate-800 rounded-md text-slate-500 hover:text-white transition-all no-print"
                                     >
                                       <EditIcon size={12}/>
                                     </button>
                                   </div>
                                 )}
                              </td>
                              <td className={`px-6 py-5 font-mono font-black ${isDirty ? 'text-slate-600 italic' : 'text-emerald-400'} print:text-slate-900`}>
                                {isDirty ? 'Aguardando...' : `R$ ${stock.preco_teto_final.toFixed(2)}`}
                              </td>
                              <td className={`px-6 py-5 font-mono font-black ${isDirty ? 'text-slate-600' : (stock.margem_seguranca > 20 ? 'text-emerald-400' : stock.margem_seguranca > 0 ? 'text-amber-400' : 'text-rose-400')} print:text-slate-900`}>
                                {isDirty ? '---' : `${stock.margem_seguranca.toFixed(1)}%`}
                              </td>
                              <td className="px-6 py-5 font-mono text-xs text-slate-400">
                                {isDirty ? '---' : `${stock.dividend_yield.toFixed(2)}%`}
                              </td>
                              <td className="px-6 py-5 font-mono text-xs text-slate-400">
                                {isDirty ? '---' : stock.pl.toFixed(1)}
                              </td>
                              <td className="px-6 py-5 font-mono text-xs text-slate-400">
                                {isDirty ? '---' : stock.pvp.toFixed(2)}
                              </td>
                              <td className="px-6 py-5 text-right">
                                 <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest border border-slate-700 text-slate-300 print:border-slate-300 print:text-slate-900 ${isDirty ? 'opacity-30' : ''}`}>
                                   {isDirty ? 'Recalcular' : stock.classificacao}
                                 </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                 </div>
               </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-20 text-center">
               <ShieldIcon size={64} className="text-slate-700 mb-6" />
               <h3 className="text-2xl font-black uppercase text-white tracking-tighter mb-4">Relatório Estratégico B3</h3>
               <p className="text-sm text-slate-400 max-w-sm mb-10 leading-relaxed">Extraia o valor intrínseco e múltiplos fundamentalistas em tempo real usando nossa IA Auditada.</p>
               <button 
                onClick={handleGenerate} 
                disabled={credits <= 0}
                className={`bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white px-12 py-5 rounded-[28px] font-black uppercase text-[12px] tracking-widest transition-all shadow-xl shadow-emerald-600/20 active:scale-95`}
               >
                 {credits > 0 ? 'Gerar Nova Auditoria' : 'Limite Diário Atingido'}
               </button>
               {credits <= 0 && <p className="text-rose-500 text-[10px] font-black uppercase tracking-widest mt-6">Aguarde o reset diário para novas varreduras.</p>}
            </div>
          )}
        </div>

        <div className="p-6 bg-slate-950/80 border-t border-slate-800 flex justify-center no-print">
           <p className="text-[10px] font-bold text-slate-600 uppercase tracking-[0.2em]">Dinheiro Global • Auditoria Fundamentalista • v4.5</p>
        </div>
      </div>
    </div>
  );
};

const SummaryCard = ({ label, value }: { label: string, value: string }) => (
  <div className="print-card bg-slate-900 border border-slate-800 p-5 rounded-[24px] print:bg-slate-50 print:border-slate-200">
     <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1 truncate">{label}</p>
     <p className="text-lg font-black text-white tracking-tight print:text-slate-900 print:text-sm truncate">{value}</p>
  </div>
);

export default B3ReportModal;
