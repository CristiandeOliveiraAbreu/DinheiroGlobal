
import React, { useMemo } from 'react';
import { Trade, ExtraIncome, Asset, Broker } from '../types';
import { AccountIcon, PlusIcon, ActivityIcon, BriefcaseIcon, TargetIcon, WalletIcon, CalculatorIcon, CheckIcon, EditIcon, TrashIcon } from './Icons';

interface AssetAccountsProps {
  trades: Trade[];
  extraIncomes: ExtraIncome[];
  assets: Asset[];
  brokers: Broker[];
  exchangeRate: number;
  onEditTrade: (trade: Trade) => void;
  onDeleteTrade: (id: string) => void;
  onEditIncome: (income: ExtraIncome) => void;
  onDeleteIncome: (id: string) => void;
  onAddIncome: (assetName: string) => void;
}

const AssetAccounts: React.FC<AssetAccountsProps> = ({ 
  trades, extraIncomes, assets, brokers, exchangeRate, 
  onEditTrade, onDeleteTrade, onEditIncome, onDeleteIncome, onAddIncome 
}) => {
  const operatedAssets = useMemo(() => {
    return Array.from(new Set([
      ...trades.map(t => t.asset.toUpperCase()),
      ...extraIncomes.map(i => i.assetName.toUpperCase())
    ])).sort();
  }, [trades, extraIncomes]);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-black tracking-tight uppercase">Inventário por Ativo</h1>
          <p className="text-slate-400 mt-1 font-medium">Contabilidade institucional: Preço Médio e PM ajustado com rendimentos.</p>
        </div>
      </header>

      <div className="space-y-12">
        {operatedAssets.length === 0 ? (
          <div className="py-32 bg-slate-900/20 border-2 border-dashed border-slate-800 rounded-[48px] flex flex-col items-center justify-center text-slate-600">
             <div className="relative mb-6">
                <div className="absolute inset-0 bg-slate-500/10 blur-2xl rounded-full"></div>
                <AccountIcon size={64} className="relative opacity-20" />
             </div>
             <p className="font-black uppercase tracking-[0.4em] text-[11px] text-slate-500">Sem movimentações em carteira</p>
             <p className="text-[9px] text-slate-700 mt-2 uppercase font-bold tracking-widest">Abra ordens ou importe ativos para gerar o extrato</p>
          </div>
        ) : (
          operatedAssets.map(assetName => {
            const assetConfig = assets.find(a => a.name.toUpperCase() === assetName);
            const isStock = assetConfig?.category === 'Ações/FII';
            const assetTrades = trades.filter(t => t.asset.toUpperCase() === assetName);
            const assetIncomes = extraIncomes.filter(i => i.assetName.toUpperCase() === assetName);

            const buyTrades = assetTrades.filter(t => t.type === 'Compra');
            const totalBuyQuantity = buyTrades.reduce((sum, t) => sum + Number(t.contracts), 0);
            const totalBuyCostBRL = buyTrades.reduce((sum, t) => {
              const cost = Number(t.contracts) * Number(t.entryPrice);
              return sum + (t.currency === 'USD' ? cost * exchangeRate : cost);
            }, 0);

            const totalIncomesBRL = assetIncomes.reduce((sum, i) => {
              const amount = Number(i.amount);
              return sum + (i.currency === 'USD' ? amount * exchangeRate : amount);
            }, 0);

            const avgPriceGross = totalBuyQuantity > 0 ? totalBuyCostBRL / totalBuyQuantity : 0;
            const avgPriceAdjusted = totalBuyQuantity > 0 ? (totalBuyCostBRL - totalIncomesBRL) / totalBuyQuantity : 0;

            const pendingTrades = assetTrades.filter(t => t.result === 'Pendente');
            const totalGuaranteeBRL = pendingTrades.reduce((sum, t) => sum + (t.currency === 'USD' ? Number(t.guarantee) * exchangeRate : Number(t.guarantee)), 0);
            
            const realizedTradeProfitBRL = assetTrades
              .filter(t => t.result !== 'Pendente')
              .reduce((sum, t) => sum + (t.currency === 'USD' ? Number(t.profit) * exchangeRate : Number(t.profit)), 0);
            
            const totalPerformanceBRL = realizedTradeProfitBRL + totalIncomesBRL;

            return (
              <div key={assetName} className="bg-slate-900 border border-slate-800 rounded-[48px] overflow-hidden shadow-2xl relative group transition-all hover:border-slate-700">
                <div className="absolute top-0 right-0 p-12 opacity-[0.03] group-hover:opacity-10 transition-opacity pointer-events-none">
                  {isStock ? <BriefcaseIcon size={120}/> : <ActivityIcon size={120}/>}
                </div>

                <div className="p-10 bg-slate-800/20 border-b border-slate-800 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-10">
                  <div className="flex items-center gap-6">
                    <div className={`w-16 h-16 rounded-[24px] flex items-center justify-center shadow-inner ${isStock ? 'bg-emerald-600/20 text-emerald-500' : 'bg-indigo-600/20 text-indigo-400'}`}>
                      {isStock ? <BriefcaseIcon size={32} /> : <ActivityIcon size={32} />}
                    </div>
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="text-4xl font-black text-white tracking-tighter uppercase">{assetName}</h3>
                        <span className={`px-4 py-1 rounded-full text-[9px] font-black uppercase tracking-[0.15em] border ${isStock ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'}`}>
                          {isStock ? 'Long Term • Custódia' : 'Speculation • Tático'}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em]">{assetConfig?.category || 'Ativo não catalogado'}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-4 w-full lg:w-auto">
                    <div className="flex-1 lg:flex-none bg-slate-950/80 border border-slate-800 px-8 py-5 rounded-[32px] min-w-[220px]">
                       <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Performance Histórica Total</p>
                       <p className={`text-2xl font-mono font-black ${totalPerformanceBRL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        R$ {totalPerformanceBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                       </p>
                    </div>
                    {isStock && (
                      <button 
                        onClick={() => onAddIncome(assetName)}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-5 rounded-[32px] text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-xl shadow-emerald-600/20 active:scale-95"
                      >
                        <PlusIcon size={18}/> Lançar Rendimento
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0 border-b border-slate-800">
                  {isStock ? (
                    <>
                      <MetricBox label="Custódia Total" value={totalBuyQuantity.toLocaleString()} subValue="Quantidade em Carteira" icon={<TargetIcon size={12}/>}/>
                      <MetricBox label="Preço Médio Unitário" value={`R$ ${avgPriceGross.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} subValue="Custo Bruto por Ativo" icon={<CalculatorIcon size={12}/>} />
                      <MetricBox label="PM Unitário Ajustado" value={`R$ ${avgPriceAdjusted.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} subValue="Deduzindo Proventos" highlight icon={<CheckIcon size={12}/>} />
                      <MetricBox label="Rendimento Acumulado" value={`R$ ${totalIncomesBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} subValue={`${assetIncomes.length} Lançamentos Recebidos`} color="text-amber-400" icon={<WalletIcon size={12}/>} />
                    </>
                  ) : (
                    <>
                      <MetricBox label="Operações Abertas" value={pendingTrades.length.toString()} subValue="Trades em Monitoramento" icon={<ActivityIcon size={12}/>}/>
                      <MetricBox label="Capital em Risco" value={`R$ ${totalGuaranteeBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} subValue="Garantia Alocada no Tático" color="text-rose-400" icon={<TargetIcon size={12}/>} />
                      <MetricBox label="Trades Realizados" value={assetTrades.filter(t => t.result !== 'Pendente').length.toString()} subValue="Volume de Saída (Histórico)" icon={<CheckIcon size={12}/>} />
                      <MetricBox label="Saldo Realizado" value={`R$ ${realizedTradeProfitBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} subValue="Apenas Ordens Finalizadas" color={realizedTradeProfitBRL >= 0 ? 'text-blue-400' : 'text-rose-400'} icon={<CalculatorIcon size={12}/>} />
                    </>
                  )}
                </div>

                <div className="overflow-x-auto bg-slate-950/20">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-slate-950/40 text-[9px] font-black text-slate-600 uppercase tracking-[0.2em] border-b border-slate-800">
                        <th className="px-10 py-5">Data/Cronologia</th>
                        <th className="px-10 py-5">Instituição / Broker</th>
                        <th className="px-10 py-5">Natureza do Evento</th>
                        <th className="px-10 py-5">Status Operacional</th>
                        <th className="px-10 py-5 text-right">Financeiro</th>
                        <th className="px-10 py-5 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/30">
                      {[
                        ...assetTrades.map(t => ({ ...t, eventType: 'TRADE' })),
                        ...assetIncomes.map(i => ({ ...i, eventType: 'INCOME' }))
                      ]
                      .sort((a: any, b: any) => b.timestamp - a.timestamp)
                      .map((item: any, idx) => {
                        const isTrade = item.eventType === 'TRADE';
                        const val = isTrade ? (item.result === 'Pendente' ? 0 : item.profit) : item.amount;
                        const currency = item.currency || 'BRL';
                        const isPending = isTrade && item.result === 'Pendente';
                        const broker = brokers.find(b => b.id === item.brokerId);
                        
                        return (
                          <tr key={idx} className="hover:bg-slate-800/10 transition-colors group">
                            <td className="px-10 py-5 text-xs font-bold text-slate-500 font-mono">{item.date}</td>
                            <td className="px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{broker?.name || 'Terminal Global'}</td>
                            <td className="px-10 py-5">
                              <div className="flex items-center gap-3">
                                {isTrade ? (
                                  <div className={`p-1.5 rounded-lg ${item.type === 'Compra' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                                    {item.type === 'Compra' ? <TargetIcon size={14}/> : <ActivityIcon size={14}/>}
                                  </div>
                                ) : (
                                  <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
                                    <WalletIcon size={14} />
                                  </div>
                                )}
                                <p className="text-xs font-black text-slate-200 uppercase tracking-tighter">
                                  {isTrade ? `${item.type === 'Compra' ? 'Aporte de Compra' : 'Saída de Venda'} • ${item.contracts.toLocaleString()} UNID` : `${item.type === 'Dividendo' ? 'Rendimento Dividendo' : 'Juros sobre Capital'}`}
                                </p>
                              </div>
                            </td>
                            <td className="px-10 py-5">
                              <span className={`inline-block whitespace-nowrap text-[8px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest border ${isPending ? 'bg-amber-500/5 text-amber-500 border-amber-500/20' : (item.result === 'Lucro' || !isTrade ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/20' : 'bg-rose-500/5 text-rose-400 border-rose-500/20')}`}>
                                {isPending ? 'Monitoramento Ativo' : (isTrade ? item.result : 'Creditado em Conta')}
                              </span>
                            </td>
                            <td className={`px-10 py-5 text-right font-mono font-black text-sm ${isPending ? 'text-slate-600' : (val >= 0 ? 'text-white' : 'text-rose-400')}`}>
                              {isPending ? '---' : `${currency === 'USD' ? '$' : 'R$'} ${val.toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
                            </td>
                            <td className="px-10 py-5 text-right">
                               <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <button 
                                    onClick={(e) => { e.stopPropagation(); isTrade ? onEditTrade(item) : onEditIncome(item); }} 
                                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg transition-all"
                                  >
                                    <EditIcon size={12}/>
                                  </button>
                                  <button 
                                    onClick={(e) => { 
                                      e.stopPropagation(); 
                                      if(window.confirm('Excluir este registro? Esta ação é irreversível.')) {
                                        isTrade ? onDeleteTrade(item.id) : onDeleteIncome(item.id); 
                                      }
                                    }} 
                                    className="p-2 bg-rose-900/10 text-rose-500 hover:bg-rose-600 hover:text-white rounded-lg transition-all"
                                  >
                                    <TrashIcon size={12}/>
                                  </button>
                               </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

interface MetricBoxProps { label: string; value: string; subValue: string; color?: string; highlight?: boolean; icon?: React.ReactNode; }
const MetricBox: React.FC<MetricBoxProps> = ({ label, value, subValue, color = "text-white", highlight, icon }) => (
  <div className={`p-8 border-r border-slate-800 transition-colors relative overflow-hidden group ${highlight ? 'bg-emerald-500/5' : 'bg-slate-900/20 hover:bg-slate-800/30'}`}>
    <div className="flex justify-between items-start mb-3">
      <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">{label}</p>
      <div className={`opacity-20 group-hover:opacity-40 transition-opacity ${color}`}>{icon}</div>
    </div>
    <p className={`text-2xl font-mono font-black tracking-tighter ${color}`}>{value}</p>
    <p className="text-[9px] text-slate-600 font-bold uppercase mt-2 tracking-widest">{subValue}</p>
  </div>
);

export default AssetAccounts;
