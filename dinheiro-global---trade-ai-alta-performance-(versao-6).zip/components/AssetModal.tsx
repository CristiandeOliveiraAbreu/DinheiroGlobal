
import React, { useState, useEffect } from 'react';
import { Asset, CurrencyType, CalculationMethod, AssetCategory } from '../types';
import { XIcon, BriefcaseIcon, CheckIcon, TargetIcon, ActivityIcon, AlertIcon } from './Icons';

interface AssetModalProps {
  onClose: () => void;
  onSave: (asset: Asset) => void;
  editingAsset?: Asset;
}

const AssetModal: React.FC<AssetModalProps> = ({ onClose, onSave, editingAsset }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<AssetCategory>('Ações/FII');
  const [currency, setCurrency] = useState<CurrencyType>('BRL');
  // Use 'Pontos' instead of 'Points' to match CalculationMethod type
  const [calculationMethod, setCalculationMethod] = useState<CalculationMethod>('Pontos');
  const [pointValue, setPointValue] = useState('1.00');
  const [minLots, setMinLots] = useState('1.00');
  
  const [receivesDividends, setReceivesDividends] = useState(false);
  const [receivesInterest, setReceivesInterest] = useState(false);
  const [receivesBonus, setReceivesBonus] = useState(false);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (editingAsset) {
      setName(editingAsset.name);
      setCategory(editingAsset.category || 'Ações/FII');
      setCurrency(editingAsset.currency || 'BRL');
      // Use 'Pontos' instead of 'Points'
      setCalculationMethod(editingAsset.calculation_method || 'Pontos');
      setPointValue(editingAsset.point_value.toString());
      setMinLots(editingAsset.min_lots.toString());
      setReceivesDividends(!!editingAsset.receives_dividends);
      setReceivesInterest(!!editingAsset.receives_interest);
      setReceivesBonus(!!editingAsset.receives_bonus);
    }
  }, [editingAsset]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || loading) return;

    setLoading(true);
    try {
      const assetData: Asset = {
        id: editingAsset?.id,
        name: name.trim().toUpperCase(),
        category,
        currency,
        // Use 'Pontos' instead of 'Points'
        calculation_method: category === 'Ações/FII' ? 'Pontos' : calculationMethod,
        point_value: category === 'Ações/FII' ? 1 : parseFloat(pointValue) || 1,
        min_lots: parseFloat(minLots) || 1,
        receives_dividends: category === 'Ações/FII' ? receivesDividends : false,
        receives_interest: category === 'Ações/FII' ? receivesInterest : false,
        receives_bonus: category === 'Ações/FII' ? receivesBonus : false
      };

      await onSave(assetData);
      onClose(); 
    } catch (err) {
      console.error("[DG-AI] Erro no modal de ativo:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl" onClick={onClose}></div>
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95 fade-in duration-300 flex flex-col max-h-[90vh]">
        <div className="px-10 py-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
          <div className="flex items-center gap-3">
            <BriefcaseIcon className="text-emerald-400" size={24} />
            <div>
              <h2 className="text-xl font-black uppercase tracking-widest">{editingAsset ? 'Editar Ativo' : 'Novo Ativo'}</h2>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mt-0.5">Parâmetros de Valorização</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-500 hover:text-white"><XIcon size={24} /></button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-10 space-y-8 overflow-y-auto custom-scrollbar">
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Categoria do Ativo</label>
              <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-2xl border border-slate-800 h-[52px]">
                <button type="button" onClick={() => setCategory('Ações/FII')} className={`rounded-xl text-[10px] font-black transition-all ${category === 'Ações/FII' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>AÇÕES / FII</button>
                <button type="button" onClick={() => setCategory('CI')} className={`rounded-xl text-[10px] font-black transition-all ${category === 'CI' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>CI (COM./IND.)</button>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Ticker do Ativo</label>
                  <input 
                    autoFocus
                    type="text" 
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white outline-none focus:ring-2 focus:ring-emerald-500/30 transition-all font-black uppercase tracking-widest text-lg" 
                    placeholder="EX: BTC, PETR4, WDO" 
                    value={name} 
                    onChange={e => setName(e.target.value)} 
                    required 
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Moeda</label>
                  <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-2xl border border-slate-800 h-[52px]">
                    <button type="button" onClick={() => setCurrency('BRL')} className={`rounded-xl text-[10px] font-black transition-all ${currency === 'BRL' ? 'bg-slate-800 text-white' : 'text-slate-500'}`}>BRL (R$)</button>
                    <button type="button" onClick={() => setCurrency('USD')} className={`rounded-xl text-[10px] font-black transition-all ${currency === 'USD' ? 'bg-slate-800 text-white' : 'text-slate-500'}`}>USD ($)</button>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                {category === 'CI' && (
                  <div className="space-y-2 animate-in slide-in-from-top-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Valor do Ponto</label>
                    <input type="number" step="any" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white font-mono font-bold outline-none focus:ring-2 focus:ring-indigo-500/30" value={pointValue} onChange={e => setPointValue(e.target.value)} required />
                  </div>
                )}
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Lote Mínimo</label>
                  <input type="number" step="any" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white font-mono font-bold outline-none focus:ring-2 focus:ring-emerald-500/30" value={minLots} onChange={e => setMinLots(e.target.value)} required />
                </div>
              </div>
            </div>
          </div>

          {category === 'Ações/FII' && (
            <div className="bg-slate-950/50 border border-slate-800 p-8 rounded-[32px] space-y-6 animate-in fade-in zoom-in-95">
              <h3 className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.2em] flex items-center gap-2">Direitos e Rendimentos</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <ToggleOption label="Dividendos" active={receivesDividends} onClick={() => setReceivesDividends(!receivesDividends)} />
                <button 
                  type="button" 
                  onClick={() => setReceivesInterest(!receivesInterest)}
                  className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${receivesInterest ? 'bg-blue-500/10 border-blue-500/50 text-white' : 'bg-slate-900 border-slate-800 text-slate-500'}`}
                >
                  <span className="text-[10px] font-black uppercase tracking-widest">Juros (JCP)</span>
                  <div className={`w-8 h-4 rounded-full relative transition-colors ${receivesInterest ? 'bg-blue-500' : 'bg-slate-700'}`}>
                    <div className={`absolute top-1 w-2 h-2 rounded-full bg-white transition-all ${receivesInterest ? 'left-5' : 'left-1'}`}></div>
                  </div>
                </button>
                <ToggleOption label="Bonificação" active={receivesBonus} onClick={() => setReceivesBonus(!receivesBonus)} />
              </div>
            </div>
          )}

          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-emerald-600 hover:bg-emerald-500 py-6 rounded-2xl font-black uppercase tracking-[0.3em] text-white shadow-2xl shadow-emerald-600/20 active:scale-[0.98] transition-all flex items-center justify-center gap-3"
          >
            {loading ? <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Confirmar e Gravar'}
          </button>
        </form>
      </div>
    </div>
  );
};

const ToggleOption = ({ label, active, onClick }: { label: string, active: boolean, onClick: () => void }) => (
  <button 
    type="button" 
    onClick={onClick}
    className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${active ? 'bg-emerald-500/10 border-emerald-500/50 text-white' : 'bg-slate-900 border-slate-800 text-slate-500'}`}
  >
    <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>
    <div className={`w-8 h-4 rounded-full relative transition-colors ${active ? 'bg-emerald-500' : 'bg-slate-700'}`}>
      <div className={`absolute top-1 w-2 h-2 rounded-full bg-white transition-all ${active ? 'left-5' : 'left-1'}`}></div>
    </div>
  </button>
);

export default AssetModal;
