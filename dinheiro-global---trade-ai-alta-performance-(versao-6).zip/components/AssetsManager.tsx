
import React, { useState, useMemo } from 'react';
import { Asset, SavedAnalysis, Trade, Contribution, ExtraIncome } from '../types';
import { BriefcaseIcon, PowerIcon, PlusIcon, ActivityIcon, EditIcon, BrainIcon, XIcon, TargetIcon, AlertIcon, HistoryIcon, CheckIcon, ShieldIcon, RadarIcon } from './Icons';
import B3ReportModal from './B3ReportModal';

interface AssetsManagerProps {
  assets: Asset[];
  savedAnalyses: SavedAnalysis[];
  trades: Trade[];
  contributions: Contribution[];
  extraIncomes: ExtraIncome[];
  isSyncing?: boolean;
  onEdit: (asset: Asset) => void;
  onUpdateStatus: (id: string, status: 'ATIVO' | 'INATIVO') => void;
  onAddNew: () => void;
  onToggleArchiveAnalysis: (id: string) => void;
  onDeleteAnalysis: (id: string) => void;
  addNotification?: (type: 'success' | 'error' | 'info', message: string) => void;
}

const AssetsManager: React.FC<AssetsManagerProps> = ({ 
  assets, 
  savedAnalyses, 
  trades,
  contributions,
  extraIncomes,
  isSyncing, 
  onEdit, 
  onUpdateStatus, 
  onAddNew,
  addNotification
}) => {
  const [activeTab, setActiveTab] = useState<'ATIVOS' | 'INATIVOS'>('ATIVOS');
  const [viewingStudiesForAsset, setViewingStudiesForAsset] = useState<string | null>(null);
  
  // Filtro de ativos por status
  const filteredAssets = useMemo(() => {
    return assets.filter(a => {
      const status = a.status || 'ATIVO';
      return activeTab === 'ATIVOS' ? status === 'ATIVO' : status === 'INATIVO';
    });
  }, [assets, activeTab]);

  const [showB3Report, setShowB3Report] = useState(false);
  const [confirmingInactivateId, setConfirmingInactivateId] = useState<string | null>(null);
  const [blockedActionAsset, setBlockedActionAsset] = useState<{name: string, count: number} | null>(null);

  // Vínculo robusto entre Análise IA e Ativo da Biblioteca
  const getStudiesForAsset = (assetName: string) => {
    if (!assetName) return [];
    return savedAnalyses
      .filter(a => a.assetName?.trim().toUpperCase() === assetName.trim().toUpperCase())
      .sort((a, b) => b.timestamp - a.timestamp);
  };

  const checkLedgerDependencies = (assetName: string) => {
    const name = assetName.trim().toUpperCase();
    const tradeCount = trades.filter(t => t.asset.trim().toUpperCase() === name).length;
    const contributionCount = contributions.filter(c => c.assetName?.trim().toUpperCase() === name).length;
    const incomeCount = extraIncomes.filter(i => i.assetName.trim().toUpperCase() === name).length;
    
    return {
      total: tradeCount + contributionCount + incomeCount
    };
  };

  const handleInactivateClick = (e: React.MouseEvent, asset: Asset) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!asset || !asset.id) return;

    const deps = checkLedgerDependencies(asset.name);
    if (deps.total > 0) {
      setBlockedActionAsset({ name: asset.name, count: deps.total });
      return;
    }

    if (confirmingInactivateId === asset.id) {
      onUpdateStatus(asset.id!, 'INATIVO');
      setConfirmingInactivateId(null);
      addNotification?.('info', `Ativo ${asset.name} arquivado.`);
    } else {
      setConfirmingInactivateId(asset.id);
      setTimeout(() => setConfirmingInactivateId(prev => prev === asset.id ? null : prev), 6000);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight uppercase text-white">Biblioteca de Ativos</h1>
          <p className="text-slate-400 mt-1 font-medium">Gestão técnica de custódia e inteligência.</p>
          
          <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800 mt-6 w-fit shadow-xl">
            <button onClick={() => setActiveTab('ATIVOS')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'ATIVOS' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}><BriefcaseIcon size={14}/> Ativos ON</button>
            <button onClick={() => setActiveTab('INATIVOS')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'INATIVOS' ? 'bg-rose-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}><PowerIcon size={14}/> Arquivados</button>
          </div>
        </div>
        
        {activeTab === 'ATIVOS' && (
          <div className="flex gap-4">
            <button onClick={() => setShowB3Report(true)} className="bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-500 hover:to-blue-500 px-8 py-5 rounded-[24px] font-black text-xs uppercase text-white shadow-xl transition-all active:scale-95 border border-white/10 flex items-center gap-3"><ActivityIcon size={18} /> Relatório Estratégico B3</button>
            <button onClick={onAddNew} className="bg-slate-800 hover:bg-slate-700 px-8 py-5 rounded-[24px] font-black text-xs uppercase text-white transition-all active:scale-95 border border-slate-700 flex items-center gap-3"><PlusIcon size={18} /> Cadastrar Ativo</button>
          </div>
        )}
      </header>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAssets.length === 0 ? (
          <div className="col-span-full py-32 bg-slate-900/20 border-2 border-dashed border-slate-800 rounded-[48px] flex flex-col items-center justify-center text-slate-600">
             <BriefcaseIcon size={64} className="mb-6 opacity-10" />
             <p className="font-black uppercase tracking-[0.3em] text-[10px]">Nenhum ativo nesta categoria</p>
          </div>
        ) : (
          filteredAssets.map((asset) => {
            const assetStudies = getStudiesForAsset(asset.name);
            const hasStudies = assetStudies.length > 0;
            const isInactive = asset.status === 'INATIVO';
            const isConfirming = confirmingInactivateId === asset.id;
            
            return (
              <div key={asset.id} className="bg-slate-900 border border-slate-800 rounded-[32px] p-8 shadow-xl hover:border-indigo-500/30 transition-all group relative flex flex-col">
                 <div className="flex justify-between items-start mb-10 relative z-20">
                    <div className={`w-14 h-14 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center shadow-inner ${asset.category === 'Ações/FII' ? 'text-emerald-400' : 'text-indigo-400'}`}>
                      <ActivityIcon size={28} />
                    </div>
                    
                    <div className="flex gap-2 items-center">
                       {!isInactive && (
                         <>
                          {/* BOTÃO DE INTELIGÊNCIA IA - POSICIONADO À ESQUERDA DO EDITAR */}
                          <button 
                            onClick={() => setViewingStudiesForAsset(asset.name)}
                            className={`relative p-3 rounded-xl transition-all flex items-center justify-center border ${
                              hasStudies 
                                ? 'bg-indigo-600/20 border-indigo-500/30 text-indigo-400 hover:bg-indigo-600 hover:text-white shadow-[0_0_15px_rgba(99,102,241,0.2)]' 
                                : 'bg-slate-800/40 border-slate-800 text-slate-600 hover:border-slate-700 hover:text-slate-400 opacity-40 hover:opacity-100'
                            }`}
                            title={hasStudies ? "Acessar Dossiê de Inteligência IA" : "Sem estudos para este ativo"}
                          >
                            <BrainIcon size={18} />
                            {hasStudies && (
                              <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-indigo-500 text-white text-[9px] font-black rounded-full flex items-center justify-center border-2 border-slate-900 animate-pulse">
                                {assetStudies.length}
                              </span>
                            )}
                          </button>
                          
                          <button onClick={() => onEdit(asset)} className="p-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-400 hover:text-white transition-all border border-slate-800" title="Editar Parâmetros"><EditIcon size={16} /></button>
                          
                          <button 
                            onClick={(e) => handleInactivateClick(e, asset)} 
                            className={`relative flex items-center justify-center transition-all ${isConfirming ? 'bg-rose-600 text-white px-6 py-3 rounded-2xl shadow-lg' : 'bg-rose-900/10 text-rose-500 hover:bg-rose-600 hover:text-white p-3 rounded-xl border border-rose-500/10'}`}
                          >
                            {isConfirming ? (
                              <div className="flex items-center gap-3 animate-in fade-in slide-in-from-right-2">
                                <span className="text-[10px] font-black uppercase tracking-widest whitespace-nowrap">Confirmar Arquivo?</span>
                                <CheckIcon size={16}/>
                              </div>
                            ) : (
                              <PowerIcon size={16}/>
                            )}
                          </button>
                         </>
                       )}
                       {isInactive && (
                         <button onClick={() => onUpdateStatus(asset.id!, 'ATIVO')} className="bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all shadow-lg">Reativar</button>
                       )}
                    </div>
                 </div>

                 <div className="mb-8">
                   <h3 className="text-3xl font-black text-white uppercase tracking-tighter">{asset.name}</h3>
                   <div className="flex gap-2 mt-2">
                     <span className="text-[9px] font-black px-2.5 py-1 rounded bg-slate-950 text-slate-500 uppercase tracking-widest border border-slate-800">{asset.currency}</span>
                     <span className={`text-[9px] font-black px-2.5 py-1 rounded uppercase tracking-widest border ${asset.category === 'Ações/FII' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'}`}>{asset.category}</span>
                   </div>
                 </div>
                 
                 <div className="space-y-4 border-t border-slate-800/50 pt-6 mt-auto">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2"><TargetIcon size={10}/> Valor do Ponto</span>
                      <span className="text-sm font-mono font-black text-white">{asset.category === 'CI' ? `${asset.currency === 'USD' ? '$' : 'R$'} ${Number(asset.point_value).toFixed(2)}` : '1:1'}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2"><BriefcaseIcon size={10}/> Lote Mínimo</span>
                      <span className="text-sm font-mono font-black text-white">{Number(asset.min_lots).toLocaleString()}</span>
                    </div>
                 </div>
              </div>
            );
          })
        )}
      </div>

      {/* MODAL DE DOSSIÊ DE INTELIGÊNCIA: HISTÓRICO DE ESTUDOS IA */}
      {viewingStudiesForAsset && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/98 backdrop-blur-xl animate-in fade-in duration-300" onClick={() => setViewingStudiesForAsset(null)}></div>
          <div className="relative bg-[#0b101b] border border-slate-800 w-full max-w-2xl rounded-[48px] shadow-2xl flex flex-col overflow-hidden max-h-[88vh] animate-in zoom-in-95">
             
             <div className="p-10 border-b border-slate-800 bg-slate-800/20 flex justify-between items-center">
                <div className="flex items-center gap-5">
                   <div className="w-14 h-14 bg-indigo-600/20 rounded-2xl flex items-center justify-center text-indigo-400 border border-indigo-500/30">
                      <BrainIcon size={32} />
                   </div>
                   <div>
                      <h2 className="text-2xl font-black uppercase text-white tracking-tighter">Dossiê IA: {viewingStudiesForAsset}</h2>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Histórico de Mapeamento Institucional</p>
                   </div>
                </div>
                <button onClick={() => setViewingStudiesForAsset(null)} className="p-4 bg-slate-800 hover:bg-slate-700 rounded-full text-slate-400 transition-all"><XIcon size={24}/></button>
             </div>
             
             <div className="flex-1 overflow-y-auto custom-scrollbar p-10 space-y-10 bg-[#070b14]">
                {getStudiesForAsset(viewingStudiesForAsset).length === 0 ? (
                  <div className="py-24 flex flex-col items-center justify-center text-slate-600 text-center space-y-4">
                    <RadarIcon size={64} className="opacity-10" />
                    <p className="text-[11px] font-black uppercase tracking-[0.3em]">Nenhum estudo arquivado para {viewingStudiesForAsset}</p>
                    <p className="text-[10px] text-slate-700 font-medium max-w-xs leading-relaxed uppercase">Realize uma varredura visual na aba 'Análise IA' para salvar os primeiros dados técnicos deste ativo.</p>
                  </div>
                ) : (
                  getStudiesForAsset(viewingStudiesForAsset).map((study) => (
                    <div key={study.id} className="bg-slate-900 border border-slate-800 rounded-[40px] p-8 hover:border-indigo-500/40 transition-all group overflow-hidden shadow-xl">
                       <div className="flex justify-between items-start mb-6">
                          <div className="flex items-center gap-4">
                             <div className="flex flex-col">
                               <span className="text-[10px] font-mono font-bold text-slate-500 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800 mb-2">{study.date}</span>
                               <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border ${
                                 study.result.direction === 'COMPRA' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                                 study.result.direction === 'VENDA' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 
                                 'bg-slate-800 text-slate-400 border-slate-700'
                               }`}>
                                  Viés Sugerido: {study.result.direction}
                               </div>
                             </div>
                          </div>
                          <div className="text-right">
                             <p className="text-[9px] font-black text-slate-600 uppercase mb-1">Confiança da IA</p>
                             <div className="flex items-center gap-3">
                                <span className={`text-2xl font-mono font-black ${study.result.confidence > 75 ? 'text-indigo-400' : 'text-amber-400'}`}>{study.result.confidence}%</span>
                                <div className="w-16 h-1 bg-slate-800 rounded-full overflow-hidden">
                                   <div className={`h-full ${study.result.confidence > 75 ? 'bg-indigo-500' : 'bg-amber-500'}`} style={{ width: `${study.result.confidence}%` }}></div>
                                </div>
                             </div>
                          </div>
                       </div>
                       
                       <div className="space-y-8">
                          {study.image && (
                            <div className="relative rounded-3xl overflow-hidden border border-slate-800 aspect-video bg-slate-950 group/img">
                               <img src={study.image} alt="Technical Map" className="w-full h-full object-cover opacity-70 group-hover/img:opacity-100 transition-opacity duration-700" />
                               <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                               <div className="absolute bottom-6 left-6 right-6">
                                  <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest mb-1">Ponto de Interesse (Institucional)</p>
                                  <p className="text-2xl font-mono font-black text-white">{study.result.entryRegion}</p>
                               </div>
                            </div>
                          )}

                          <div className="grid md:grid-cols-2 gap-8 pt-4">
                             <div className="space-y-3">
                                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                                  <ActivityIcon size={12} /> Racional do Sistema
                                </p>
                                <p className="text-sm text-slate-300 font-medium leading-relaxed italic border-l-2 border-indigo-500/30 pl-5">
                                  "{study.result.reasoning}"
                                </p>
                             </div>
                             <div className="space-y-5">
                                <div className="grid grid-cols-2 gap-4">
                                   <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800/80">
                                      <p className="text-[9px] font-black text-rose-500/70 uppercase mb-1">Invalidação</p>
                                      <p className="text-sm font-mono font-black text-rose-400">{study.result.stopLoss.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                                   </div>
                                   <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800/80">
                                      <p className="text-[9px] font-black text-emerald-500/70 uppercase mb-1">Alvo Estimado</p>
                                      <p className="text-sm font-mono font-black text-emerald-400">{study.result.takeProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                                   </div>
                                </div>
                                <div className={`p-4 rounded-2xl border text-center ${study.result.riskScore < 5 ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-500' : 'bg-rose-500/5 border-rose-500/20 text-rose-500'}`}>
                                   <p className="text-[9px] font-black uppercase mb-0.5 tracking-widest">Score de Risco Estrutural</p>
                                   <p className="text-xl font-black">{study.result.riskScore}/10</p>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                  ))
                )}
             </div>
             
             <div className="p-8 bg-slate-950 border-t border-slate-800 flex justify-center no-print">
                <p className="text-[10px] font-black text-slate-700 uppercase tracking-[0.4em]">Dinheiro Global Intelligence Archive • v6.2</p>
             </div>
          </div>
        </div>
      )}

      {showB3Report && <B3ReportModal onClose={() => setShowB3Report(false)} addNotification={addNotification} />}
      
      {blockedActionAsset && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-xl" onClick={() => setBlockedActionAsset(null)}></div>
          <div className="relative bg-slate-900 border border-rose-500/30 w-full max-w-md rounded-[40px] shadow-2xl p-10 text-center animate-in zoom-in-95">
             <div className="w-20 h-20 bg-rose-500/10 rounded-[32px] flex items-center justify-center text-rose-500 mx-auto mb-8 border border-rose-500/20"><ShieldIcon size={40} /></div>
             <h2 className="text-2xl font-black text-white uppercase tracking-tighter mb-4">Ação Bloqueada</h2>
             <p className="text-[13px] text-slate-400 font-medium leading-relaxed mb-8">O ativo {blockedActionAsset.name} possui lançamentos ativos na Tesouraria e não pode ser arquivado no momento.</p>
             <button onClick={() => setBlockedActionAsset(null)} className="w-full bg-slate-800 hover:bg-slate-700 text-white py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all">Entendido</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AssetsManager;
