
import React, { useState, useMemo, useEffect } from 'react';
import { Broker, Contribution, Trade, CurrencyType, BrokerType, ExtraIncome, Asset } from '../types';
import { BankIcon, MoneyIcon, PlusIcon, TrashIcon, ActivityIcon, XIcon, CheckIcon, WalletIcon, TargetIcon, BriefcaseIcon, EditIcon, AlertIcon, ShieldIcon } from './Icons';
import SecurityModal from './SecurityModal';

interface CashManagerProps {
  brokers: Broker[];
  contributions: Contribution[];
  trades: Trade[];
  extraIncomes: ExtraIncome[];
  assets?: Asset[]; 
  exchangeRate: number;
  onAddBroker: (broker: Partial<Broker>) => void;
  onDeleteBroker: (id: string) => void;
  onAddContribution: (contribution: Contribution) => void;
  onDeleteContribution: (id: string) => void;
}

const CashManager: React.FC<CashManagerProps> = ({ 
  brokers, 
  contributions, 
  trades, 
  extraIncomes,
  assets = [],
  exchangeRate, 
  onAddBroker, 
  onDeleteBroker, 
  onAddContribution, 
  onDeleteContribution 
}) => {
  const [activeTab, setActiveTab] = useState<'BROKERS' | 'LEDGER'>('BROKERS');
  const [showBrokerModal, setShowBrokerModal] = useState(false);
  const [showContributionModal, setShowContributionModal] = useState(false);
  const [editingContributionId, setEditingContributionId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Estados de Segurança para Exclusão Sincronizada
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<{id: string, type: 'BROKER' | 'CONTRIBUTION', name?: string} | null>(null);

  // Form States
  const [bName, setBName] = useState('');
  const [bType, setBType] = useState<BrokerType>('Corretora');
  
  const [cAmount, setCAmount] = useState('');
  const [cCosts, setCCosts] = useState('');
  const [cBroker, setCBroker] = useState('');
  const [cAsset, setCAsset] = useState('');
  const [cCurrency, setCCurrency] = useState<CurrencyType>('BRL');
  const [cType, setCType] = useState<'Additional' | 'Withdraw' | 'Income' | 'Cost'>('Additional');

  const unifiedLedger = useMemo(() => {
    const movements: any[] = [
      ...contributions.map(c => ({
        id: c.id,
        date: c.date,
        timestamp: c.timestamp,
        brokerId: c.brokerId,
        type: c.type === 'Retirada' ? 'RETIRADA' : (c.type === 'Rendimento' ? `RENDIMENTO (${c.assetName || 'Ativo'})` : (c.type === 'Custo' ? 'CUSTO / TAXA' : 'APORTE')),
        amount: Number(c.amount) || 0,
        costs: Number(c.costs) || 0,
        currency: c.currency,
        isTrade: false,
        isPositive: c.type !== 'Retirada' && c.type !== 'Custo',
        rawType: c.type
      })),
      ...trades.filter(t => t.result !== 'Pendente').map(t => ({
        id: t.id,
        date: t.date,
        timestamp: t.timestamp,
        brokerId: t.brokerId,
        type: `TRADE: ${t.asset}`,
        amount: Math.abs(Number(t.profit) || 0),
        currency: t.currency,
        isTrade: true,
        isPositive: (Number(t.profit) || 0) >= 0
      }))
    ];
    return movements.sort((a, b) => b.timestamp - a.timestamp);
  }, [contributions, trades]);

  const getBrokerMetrics = (brokerId: string) => {
    const brokerContributions = contributions.filter(c => c.brokerId === brokerId);
    const brokerFinishedTrades = trades.filter(t => t.brokerId === brokerId && t.result !== 'Pendente');
    const brokerActiveTrades = trades.filter(t => t.brokerId === brokerId && t.result === 'Pendente');
    
    const cashMovementsBRL = brokerContributions.reduce((sum, c) => {
      const amount = Number(c.amount) || 0;
      const costs = Number(c.costs) || 0;
      const val = c.currency === 'USD' ? amount * exchangeRate : amount;
      const costVal = costs * (c.currency === 'USD' ? exchangeRate : 1);
      
      if (c.type === 'Retirada' || c.type === 'Custo') {
        return sum - (val + costVal);
      }
      return sum + val;
    }, 0);

    const totalIncomesBRL = brokerContributions
      .filter(c => c.type === 'Rendimento')
      .reduce((sum, c) => {
        const amount = Number(c.amount) || 0;
        const val = c.currency === 'USD' ? amount * exchangeRate : amount;
        return sum + val;
      }, 0);

    const totalWithdrawalsBRL = brokerContributions
      .filter(c => c.type === 'Retirada' || c.type === 'Custo')
      .reduce((sum, c) => {
        const amount = Number(c.amount) || 0;
        const costs = Number(c.costs) || 0;
        const val = c.currency === 'USD' ? amount * exchangeRate : amount;
        const costVal = costs * (c.currency === 'USD' ? exchangeRate : 1);
        return sum + (val + costVal);
      }, 0);

    const realizedTradeProfitBRL = brokerFinishedTrades.reduce((sum, t) => {
      const profit = Number(t.profit) || 0;
      const val = t.currency === 'USD' ? profit * exchangeRate : profit;
      return sum + val;
    }, 0);

    const investedBRL = brokerActiveTrades
      .filter(t => t.type === 'Compra')
      .reduce((sum, t) => {
        const cost = (Number(t.contracts) || 0) * (Number(t.entryPrice) || 0);
        return sum + (t.currency === 'USD' ? cost * exchangeRate : cost);
      }, 0);

    const totalBalance = cashMovementsBRL + realizedTradeProfitBRL;
    const availableBRL = totalBalance - investedBRL;

    const activeTickers = Array.from(new Set(brokerActiveTrades.map(t => t.asset.toUpperCase())));
    
    const assetBreakdown = activeTickers.map(ticker => {
      const tickerTrades = brokerActiveTrades.filter(t => t.asset.toUpperCase() === ticker);
      const incomeAcumBRL = brokerContributions
        .filter(c => c.type === 'Rendimento' && c.assetName?.toUpperCase() === ticker)
        .reduce((sum, c) => {
          const amount = Number(c.amount) || 0;
          const val = c.currency === 'USD' ? amount * exchangeRate : amount;
          return sum + val;
        }, 0);

      const costBasisBRL = tickerTrades
        .filter(t => t.type === 'Compra')
        .reduce((sum, t) => {
          const cost = (Number(t.contracts) || 0) * (Number(t.entryPrice) || 0);
          return sum + (t.currency === 'USD' ? cost * exchangeRate : cost);
        }, 0);

      return { ticker, costBasisBRL, incomeAcumBRL };
    }).filter(a => a.costBasisBRL > 0);

    return { totalBalance, availableBRL, investedBRL, totalIncomesBRL, totalWithdrawalsBRL, assetBreakdown };
  };

  const parseNumberBR = (val: string): number => {
    if (!val) return 0;
    const cleaned = val.toString().replace(/\./g, '').replace(',', '.');
    const result = parseFloat(cleaned);
    return isNaN(result) ? 0 : result;
  };

  const handleEditContribution = (e: React.MouseEvent, item: any) => {
    e.stopPropagation();
    if (item.isTrade) return;
    
    const original = contributions.find(c => c.id === item.id);
    if (!original) return;

    setEditingContributionId(original.id);
    setCAmount(original.amount.toString().replace('.', ','));
    setCCosts(original.costs?.toString().replace('.', ',') || '');
    setCBroker(original.brokerId);
    setCCurrency(original.currency);
    setCAsset(original.assetName || '');
    setCType(original.type === 'Retirada' ? 'Withdraw' : (original.type === 'Rendimento' ? 'Income' : (original.type === 'Custo' ? 'Cost' : 'Additional')));
    setShowContributionModal(true);
  };

  const handleOpenNewContribution = (preselectedBrokerId?: string) => {
    setEditingContributionId(null);
    setCAmount('');
    setCCosts('');
    setCAsset('');
    setCBroker(preselectedBrokerId || '');
    setCType('Additional');
    setCCurrency('BRL');
    setShowContributionModal(true);
  };

  const handleProcessContribution = async () => {
    const amountVal = parseNumberBR(cAmount);
    if (amountVal === 0 || !cBroker || isSubmitting) return;

    setIsSubmitting(true);
    try {
      const mappedType: 'Inicial' | 'Adicional' | 'Retirada' | 'Rendimento' | 'Custo' = 
        cType === 'Withdraw' ? 'Retirada' : (cType === 'Income' ? 'Rendimento' : (cType === 'Cost' ? 'Custo' : 'Adicional'));
      
      const payload: Contribution = {
        id: editingContributionId || "",
        amount: amountVal,
        costs: (cType === 'Withdraw' || cType === 'Cost') ? parseNumberBR(cCosts) : undefined,
        currency: cCurrency,
        type: mappedType,
        brokerId: cBroker,
        assetName: cType === 'Income' ? cAsset.trim().toUpperCase() : undefined,
        date: new Date().toLocaleDateString('pt-BR', {day: '2-digit', month: 'short'}),
        timestamp: Date.now()
      };

      await onAddContribution(payload);
      setShowContributionModal(false);
    } catch (err) {
      console.error("[DG-AI] Falha ao processar lançamento:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleProcessBroker = async () => {
    if (!bName.trim() || isSubmitting) return;

    setIsSubmitting(true);
    try {
      await onAddBroker({
        name: bName.trim().toUpperCase(),
        type: bType
      });
      setBName('');
      setBType('Corretora');
      setShowBrokerModal(false);
    } catch (err) {
      console.error("[DG-AI] Falha ao cadastrar instituição:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const triggerDeleteBroker = (id: string, name: string) => {
    setPendingDelete({ id, type: 'BROKER', name });
    setShowSecurityModal(true);
  };

  const triggerDeleteContribution = (id: string, typeDesc: string) => {
    setPendingDelete({ id, type: 'CONTRIBUTION', name: typeDesc });
    setShowSecurityModal(true);
  };

  const handleAuthorizedDelete = () => {
    if (!pendingDelete) return;
    if (pendingDelete.type === 'BROKER') onDeleteBroker(pendingDelete.id);
    else onDeleteContribution(pendingDelete.id);
    setPendingDelete(null);
    setShowSecurityModal(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight uppercase">Tesouraria Central</h1>
          <p className="text-slate-400 mt-1 font-medium">Gestão de liquidez por instituição e fluxo de caixa consolidado.</p>
        </div>
        
        <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800 shadow-xl">
          <button onClick={() => setActiveTab('BROKERS')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'BROKERS' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}><BankIcon size={14}/> Custódia</button>
          <button onClick={() => setActiveTab('LEDGER')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'LEDGER' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}><MoneyIcon size={14}/> Extrato Unificado</button>
        </div>
      </header>

      {activeTab === 'BROKERS' ? (
        <div className="grid grid-cols-1 gap-8">
          {brokers.length === 0 ? (
            <div className="py-24 bg-slate-900/10 border-2 border-dashed border-slate-800 rounded-[48px] flex flex-col items-center justify-center text-slate-600">
              <BankIcon size={48} className="mb-4 opacity-10" />
              <p className="text-[10px] font-black uppercase tracking-widest">Nenhuma instituição vinculada</p>
            </div>
          ) : (
            brokers.map(broker => {
              const metrics = getBrokerMetrics(broker.id);
              return (
                <div key={broker.id} className="bg-slate-900 border border-slate-800 rounded-[48px] p-10 shadow-2xl relative group overflow-hidden flex flex-col min-h-[400px]">
                  <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:opacity-10 transition-opacity"><BankIcon size={120}/></div>
                  
                  <div className="flex justify-between items-start mb-10">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500">
                        <BriefcaseIcon size={24} />
                      </div>
                      <div>
                        <h3 className="text-2xl font-black text-white uppercase tracking-tighter">{broker.name}</h3>
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{broker.type}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 z-10">
                      <button 
                        onClick={() => handleOpenNewContribution(broker.id)}
                        className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600 hover:text-white rounded-xl text-[9px] font-black uppercase tracking-widest transition-all shadow-lg active:scale-95"
                        title="Lançamento Rápido"
                      >
                        <PlusIcon size={14}/> Efetuar Lançamento
                      </button>
                      <button 
                        onClick={(e) => { 
                          e.stopPropagation(); 
                          triggerDeleteBroker(broker.id, broker.name);
                        }} 
                        className="p-2.5 bg-slate-800/50 hover:bg-rose-900/20 rounded-xl text-slate-700 hover:text-rose-500 transition-all border border-slate-700"
                        title="Excluir Instituição"
                      >
                        <TrashIcon size={16}/>
                      </button>
                    </div>
                  </div>

                  <div className="space-y-8">
                    <div className="bg-slate-950/50 p-6 rounded-[32px] border border-slate-800/50">
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Saldo Total em Custódia</p>
                      <p className="text-4xl font-mono font-black text-white tracking-tighter">R$ {metrics.totalBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="p-6 bg-emerald-500/5 border border-emerald-500/10 rounded-[28px]">
                        <p className="text-[9px] font-black text-emerald-500/70 uppercase tracking-widest mb-1">Disponível</p>
                        <p className="text-xl font-mono font-black text-emerald-400">R$ {metrics.availableBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                      </div>
                      <div className="p-6 bg-indigo-500/5 border border-indigo-500/10 rounded-[28px]">
                        <p className="text-[9px] font-black text-indigo-500/70 uppercase tracking-widest mb-1">Investido</p>
                        <p className="text-xl font-mono font-black text-indigo-400">R$ {metrics.investedBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                      </div>
                      <div className="p-6 bg-amber-500/5 border border-amber-500/10 rounded-[28px]">
                        <p className="text-[9px] font-black text-amber-500/70 uppercase tracking-widest mb-1">Rendimentos</p>
                        <p className="text-xl font-mono font-black text-amber-400">R$ {metrics.totalIncomesBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                      </div>
                      <div className="p-6 bg-rose-500/5 border border-rose-500/10 rounded-[28px]">
                        <p className="text-[9px] font-black text-rose-500/70 uppercase tracking-widest mb-1">Custos & Saques</p>
                        <p className="text-xl font-mono font-black text-rose-400">R$ {metrics.totalWithdrawalsBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                      </div>
                    </div>

                    {metrics.assetBreakdown.length > 0 && (
                      <div className="space-y-4 pt-4 border-t border-slate-800/50">
                        <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4">Detalhamento de Posições</h4>
                        <div className="space-y-3">
                          {metrics.assetBreakdown.map((item, idx) => (
                            <div key={idx} className="flex justify-between items-center p-5 bg-slate-950/80 rounded-3xl border border-slate-800 hover:border-slate-700 transition-colors">
                                <div className="flex items-center gap-4">
                                  <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-emerald-400">
                                    <TargetIcon size={14}/>
                                  </div>
                                  <h3 className="text-sm font-black text-white tracking-tighter">{item.ticker}</h3>
                                </div>
                                <div className="flex gap-8">
                                  <div className="text-right">
                                    <p className="text-[8px] font-black text-slate-600 uppercase tracking-tighter">Custo</p>
                                    <p className="text-xs font-mono font-black text-slate-300">R$ {item.costBasisBRL.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                                  </div>
                                  <div className="text-right">
                                    <p className="text-[8px] font-black text-emerald-600/60 uppercase tracking-tighter">Proventos</p>
                                    <p className="text-xs font-mono font-black text-emerald-400">R$ {item.incomeAcumBRL.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                                  </div>
                                </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
          
          <button onClick={() => setShowBrokerModal(true)} className="min-h-[200px] border-2 border-dashed border-slate-800 rounded-[48px] p-8 flex flex-col items-center justify-center text-slate-600 hover:border-emerald-500/50 hover:text-emerald-500 transition-all group">
            <PlusIcon size={48} className="mb-4 group-hover:scale-110 transition-transform" />
            <span className="text-sm font-black uppercase tracking-widest">Nova Instituição</span>
          </button>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-[40px] overflow-hidden shadow-2xl">
          <div className="p-8 border-b border-slate-800 flex justify-between items-center bg-slate-800/10">
             <h2 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Fluxo de Caixa & Performance</h2>
             <button onClick={() => handleOpenNewContribution()} className="bg-emerald-600 hover:bg-emerald-500 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-lg shadow-emerald-600/20 active:scale-95"><PlusIcon size={14}/> Lançar Caixa</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-900 border-b border-slate-800 text-[9px] font-black text-slate-600 uppercase tracking-widest">
                  <th className="px-10 py-5">Data</th>
                  <th className="px-10 py-5">Instituição</th>
                  <th className="px-10 py-5">Natureza do Evento</th>
                  <th className="px-10 py-5 text-right">Valor Líquido</th>
                  <th className="px-10 py-5 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {unifiedLedger.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-10 py-20 text-center text-slate-600 font-black uppercase text-[10px] tracking-widest">Nenhum lançamento no extrato</td>
                  </tr>
                ) : (
                  unifiedLedger.map(item => {
                    const broker = brokers.find(b => b.id === item.brokerId);
                    const totalAmount = (item.rawType === 'Retirada' || item.rawType === 'Custo') ? (item.amount + (item.costs || 0)) : item.amount;
                    
                    return (
                      <tr key={item.id} className="hover:bg-slate-800/10 transition-colors group">
                        <td className="px-10 py-5 text-xs font-mono font-bold text-slate-500">{item.date}</td>
                        <td className="px-10 py-5 text-xs font-black text-white uppercase">{broker?.name || '---'}</td>
                        <td className="px-10 py-5">
                          <div className="flex items-center gap-2">
                            {item.isTrade ? <ActivityIcon size={12} className="text-indigo-400"/> : (item.type.includes('RENDIMENTO') ? <TargetIcon size={12} className="text-emerald-400"/> : <WalletIcon size={12} className={`text-${(item.rawType === 'Retirada' || item.rawType === 'Custo') ? 'rose' : 'blue'}-400`}/>)}
                            <span className="text-[10px] font-black uppercase tracking-widest text-slate-300">
                              {item.type} {item.costs > 0 && <span className="text-rose-500 font-bold">(+ taxa)</span>}
                            </span>
                          </div>
                        </td>
                        <td className={`px-10 py-5 text-right font-mono font-black text-sm ${item.isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {item.isPositive ? '+' : '-'} {item.currency === 'USD' ? '$' : 'R$'} {totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="px-10 py-5 text-right">
                          <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            {!item.isTrade ? (
                              <>
                                <button onClick={(e) => handleEditContribution(e, item)} className="p-2 bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600 hover:text-white rounded-lg transition-all" title="Editar Lançamento"><EditIcon size={14}/></button>
                                <button 
                                  onClick={(e) => { 
                                    e.stopPropagation(); 
                                    triggerDeleteContribution(item.id, item.type);
                                  }} 
                                  className="p-2 bg-rose-600/20 text-rose-500 hover:bg-rose-600 hover:text-white rounded-lg transition-all" 
                                  title="Excluir Lançamento"
                                >
                                  <TrashIcon size={14}/>
                                </button>
                              </>
                            ) : (
                              <span className="text-[8px] font-black text-slate-600 uppercase tracking-tighter flex items-center gap-1"><AlertIcon size={10}/> Gerir em Monitoramento</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showBrokerModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={() => !isSubmitting && setShowBrokerModal(false)}></div>
          <div className="relative bg-slate-900 border border-slate-800 w-full max-w-md rounded-[32px] shadow-2xl p-8">
            <h2 className="text-xl font-black uppercase mb-6">Nova Instituição</h2>
            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="NOME DA CORRETORA/BANCO" 
                value={bName} 
                onChange={e => setBName(e.target.value)} 
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-white uppercase font-black outline-none focus:ring-1 focus:ring-emerald-500" 
                disabled={isSubmitting}
              />
              <select 
                value={bType} 
                onChange={e => setBType(e.target.value as BrokerType)} 
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-white uppercase font-black outline-none"
                disabled={isSubmitting}
              >
                <option value="Corretora">CORRETORA</option>
                <option value="Exchange">EXCHANGE</option>
                <option value="Banco">BANCO</option>
              </select>
              <button 
                onClick={handleProcessBroker} 
                disabled={isSubmitting || !bName.trim()}
                className="w-full bg-emerald-600 py-4 rounded-xl font-black uppercase tracking-widest transition-all hover:bg-emerald-500 shadow-xl shadow-emerald-600/20 active:scale-95 flex items-center justify-center gap-3 disabled:opacity-50"
              >
                {isSubmitting ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Cadastrar'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showContributionModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={() => !isSubmitting && setShowContributionModal(false)}></div>
          <div className="relative bg-slate-900 border border-slate-800 w-full max-w-md rounded-[32px] shadow-2xl p-8 animate-in zoom-in-95 duration-300">
            <h2 className="text-xl font-black uppercase mb-6 text-white">{editingContributionId ? 'Alterar Lançamento' : 'Novo Lançamento'}</h2>
            <div className="space-y-4">
               <select value={cType} onChange={e => setCType(e.target.value as any)} className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-white uppercase font-black outline-none focus:ring-1 focus:ring-emerald-500/50">
                <option value="Additional">APORTE / DEPÓSITO</option>
                <option value="Withdraw">RETIRADA / SAQUE</option>
                <option value="Income">RENDIMENTO EXTERNO</option>
                <option value="Cost">CUSTO / TAXA OPERACIONAL</option>
              </select>
              <select 
                value={cBroker} 
                onChange={e => setCBroker(e.target.value)} 
                className={`w-full bg-slate-950 border ${!cBroker ? 'border-rose-500/50' : 'border-slate-800'} rounded-xl p-4 text-white uppercase font-black outline-none focus:ring-1 focus:ring-emerald-500/50`}
              >
                <option value="">SELECIONAR INSTITUIÇÃO</option>
                {brokers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
              {cType === 'Income' && (
                <input type="text" placeholder="TICKER DO ATIVO (EX: PETR4)" value={cAsset} onChange={e => setCAsset(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-white uppercase font-black outline-none" />
              )}
              <div className="flex gap-2">
                <div className="flex-1 space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase ml-1">Valor Principal</label>
                  <input type="text" placeholder="VALOR (Ex: 1.500,50)" value={cAmount} onChange={e => setCAmount(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-white font-black outline-none focus:border-emerald-500" />
                </div>
                <div className="w-24 space-y-1">
                  <label className="text-[9px] font-black text-slate-500 uppercase ml-1">Moeda</label>
                  <select value={cCurrency} onChange={e => setCCurrency(e.target.value as CurrencyType)} className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-white font-black outline-none">
                    <option value="BRL">BRL</option>
                    <option value="USD">USD</option>
                  </select>
                </div>
              </div>

              {(cType === 'Withdraw' || cType === 'Cost') && (
                <div className="space-y-1 animate-in slide-in-from-top-2 duration-300">
                  <label className="text-[9px] font-black text-rose-500 uppercase ml-1">{cType === 'Cost' ? 'Valor da Taxa / Custo' : 'Custos e Taxas da Operação'}</label>
                  <input 
                    type="text" 
                    placeholder="Ex: 15,00" 
                    value={cCosts} 
                    onChange={e => setCCosts(e.target.value)} 
                    className="w-full bg-slate-950 border border-rose-900/40 rounded-xl p-4 text-rose-400 font-mono font-black outline-none focus:ring-1 focus:ring-rose-500/50" 
                  />
                </div>
              )}

              <button 
                onClick={handleProcessContribution} 
                disabled={isSubmitting || parseNumberBR(cAmount) <= 0 || !cBroker}
                className="w-full bg-emerald-600 py-5 rounded-xl font-black uppercase tracking-widest text-white transition-all hover:bg-emerald-500 active:scale-95 shadow-lg shadow-emerald-600/20 disabled:bg-slate-800 disabled:text-slate-600 disabled:opacity-100 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Sincronizando...
                  </>
                ) : (
                  editingContributionId ? 'Salvar Alterações' : 'Confirmar Lançamento'
                )}
              </button>
              {!cBroker && <p className="text-[9px] text-rose-500 text-center font-black uppercase">Selecione uma instituição para habilitar o lançamento</p>}
            </div>
          </div>
        </div>
      )}

      {showSecurityModal && (
        <SecurityModal 
          onClose={() => { setShowSecurityModal(false); setPendingDelete(null); }}
          onConfirm={handleAuthorizedDelete}
          title="Autorizar Exclusão Crítica"
          description={`Atenção: A remoção de "${pendingDelete?.name}" ativará a Auditoria Interna Cascata. Todos os lançamentos vinculados no Inventário por Ativo e no Extrato Unificado serão permanentemente excluídos para manter a integridade do sistema.`}
        />
      )}
    </div>
  );
};

export default CashManager;
