
import React, { useState, useEffect, useRef } from 'react';
import { B3WeeklyReport, ReportStatus, B3StockData } from '../types';
import { generateB3ReportAsync } from '../services/b3Report';
import { 
  RadarIcon, CheckIcon, AlertIcon, TargetIcon, 
  HistoryIcon, ActivityIcon,
  BriefcaseIcon, ShieldIcon, TrashIcon, ArchiveIcon, EditIcon, CalculatorIcon, XIcon
} from './Icons';

interface FundamentalAnalysisIAProps {
  addNotification?: (type: 'success' | 'error' | 'info', message: string) => void;
}

const STORAGE_REPORTS = 'dg_b3_reports_fast_v2';
const STORAGE_B3_CREDITS = 'dg_b3_report_daily_credits';
const DAILY_LIMIT = 3;

const FundamentalAnalysisIA: React.FC<FundamentalAnalysisIAProps> = ({ addNotification }) => {
  const [history, setHistory] = useState<B3WeeklyReport[]>(() => {
    const saved = localStorage.getItem(STORAGE_REPORTS);
    return saved ? JSON.parse(saved) : [];
  });

  const [activeReport, setActiveReport] = useState<B3WeeklyReport | null>(history.length > 0 ? history[0] : null);
  const [status, setStatus] = useState<ReportStatus>('aguardando');
  const [statusMessage, setStatusMessage] = useState('Pronto para iniciar auditoria.');
  const [countdown, setCountdown] = useState(30);
  const [view, setView] = useState<'current' | 'history'>('current');
  const [editingStockId, setEditingStockId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<string>('');
  const [isRecalculating, setIsRecalculating] = useState(false);
  const [pendingRecalc, setPendingRecalc] = useState<string[]>([]);
  const [credits, setCredits] = useState(DAILY_LIMIT);
  
  const timerRef = useRef<any>(null);

  useEffect(() => {
    const today = new Date().toLocaleDateString('pt-BR');
    const stored = localStorage.getItem(STORAGE_B3_CREDITS);
    
    if (stored) {
      const { date, remaining } = JSON.parse(stored);
      if (date === today) {
        setCredits(remaining);
      } else {
        localStorage.setItem(STORAGE_B3_CREDITS, JSON.stringify({ date: today, remaining: DAILY_LIMIT }));
        setCredits(DAILY_LIMIT);
      }
    } else {
      localStorage.setItem(STORAGE_B3_CREDITS, JSON.stringify({ date: today, remaining: DAILY_LIMIT }));
      setCredits(DAILY_LIMIT);
    }
  }, []);

  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const handleGenerate = async () => {
    if (status === 'processando') return;
    if (credits <= 0) {
      if (addNotification) addNotification('error', "Limite de créditos diários atingido.");
      return;
    }

    setCountdown(45);
    setStatus('processando');
    setStatusMessage('Iniciando motores de busca fundamentalista...');
    
    timerRef.current = setInterval(() => {
      setCountdown(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    try {
      const newReport = await generateB3ReportAsync((p, s, msg) => {
        if (msg) setStatusMessage(msg);
        if (s === 'concluído') {
          clearInterval(timerRef.current);
          setStatus('concluído');
        }
      });
      
      const updatedHistory = [newReport, ...history].slice(0, 15);
      setHistory(updatedHistory);
      localStorage.setItem(STORAGE_REPORTS, JSON.stringify(updatedHistory));
      setActiveReport(newReport);
      setView('current');
      setPendingRecalc([]);

      const today = new Date().toLocaleDateString('pt-BR');
      const newRemaining = Math.max(0, credits - 1);
      setCredits(newRemaining);
      localStorage.setItem(STORAGE_B3_CREDITS, JSON.stringify({ date: today, remaining: newRemaining }));
      
      if (addNotification) addNotification('success', "Novo Relatório de Auditoria Gerado!");
    } catch (err: any) {
      clearInterval(timerRef.current);
      setStatus('erro');
      setStatusMessage(err.message || 'Falha na comunicação com o servidor de dados.');
    }
  };

  const deleteFromHistory = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = history.filter(h => h.id !== id);
    setHistory(updated);
    localStorage.setItem(STORAGE_REPORTS, JSON.stringify(updated));
    if (activeReport?.id === id) setActiveReport(updated[0] || null);
  };

  const setManualPricePending = (stockId: string, newPriceRaw: string) => {
    if (!activeReport) return;
    const newPrice = parseFloat(newPriceRaw);
    if (isNaN(newPrice) || newPrice <= 0) {
      setEditingStockId(null);
      return;
    }

    const updatedStocks = activeReport.top_40.map(stock => {
      if (stock.ativo === stockId) {
        return { 
          ...stock, 
          preco_manual: newPrice,
          ajustado_em: new Date().toLocaleString('pt-BR')
        };
      }
      return stock;
    });

    setActiveReport({ ...activeReport, top_40: updatedStocks });
    if (!pendingRecalc.includes(stockId)) {
      setPendingRecalc(prev => [...prev, stockId]);
    }
    setEditingStockId(null);
  };

  const handleRecalculateMargins = async () => {
    if (!activeReport || pendingRecalc.length === 0) return;
    setIsRecalculating(true);
    await new Promise(r => setTimeout(r, 800));
    const updatedStocks = activeReport.top_40.map(stock => {
      if (stock.preco_manual && pendingRecalc.includes(stock.ativo)) {
        const newPrice = stock.preco_manual;
        const oldPrice = stock.preco_validado;
        const ratio = newPrice / oldPrice;
        const newMargin = ((stock.preco_teto_final / newPrice) - 1) * 100;
        const newDY = stock.dividend_yield / ratio;
        const newPL = stock.pl * ratio;
        const newPVP = stock.pvp * ratio;
        let newClass: B3StockData['classificacao'] = 'Cara';
        if (newMargin > 20) newClass = 'Excelente';
        else if (newMargin > 5) newClass = 'Boa';
        else if (newMargin > -5) newClass = 'Neutra';
        return {
          ...stock,
          preco_validado: newPrice,
          margem_seguranca: newMargin,
          dividend_yield: newDY,
          pl: newPL,
          pvp: newPVP,
          classificacao: newClass
        };
      }
      return stock;
    });
    
    updatedStocks.sort((a, b) => {
      const rank: Record<string, number> = { 'Excelente': 3, 'Boa': 2, 'Neutra': 1, 'Cara': 0 };
      if (rank[b.classificacao] !== rank[a.classificacao]) return rank[b.classificacao] - rank[a.classificacao];
      return b.margem_seguranca - a.margem_seguranca;
    });
    
    const mostDiscounted = [...updatedStocks].sort((a, b) => b.margem_seguranca - a.margem_seguranca)[0];
    const mostExpensive = [...updatedStocks].sort((a, b) => a.margem_seguranca - b.margem_seguranca)[0];
    const avgMargin = updatedStocks.reduce((sum, s) => sum + s.margem_seguranca, 0) / updatedStocks.length;
    
    const updatedReport: B3WeeklyReport = {
      ...activeReport,
      top_40: updatedStocks,
      resumo: {
        ...activeReport.resumo,
        acao_mais_descontada: mostDiscounted.ativo,
        acao_mais_cara: mostExpensive.ativo,
        margem_media: `${avgMargin.toFixed(2)}%`
      }
    };
    
    setActiveReport(updatedReport);
    const newHist = history.map(h => h.id === updatedReport.id ? updatedReport : h);
    setHistory(newHist);
    localStorage.setItem(STORAGE_REPORTS, JSON.stringify(newHist));
    setPendingRecalc([]);
    setIsRecalculating(false);
    if (addNotification) addNotification('success', " Valuation e margens recalculados.");
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-left space-y-1">
          <h1 className="text-2xl font-black flex items-center gap-3 uppercase tracking-tighter text-white">
            <ShieldIcon className="text-emerald-500" size={28} />
            Análise Fundamento IA
          </h1>
          <p className="text-slate-500 text-[11px] font-black uppercase tracking-[0.3em]">IA Auditada • Valuation de Ativos B3</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 px-6 py-3 rounded-[24px] shadow-lg flex items-center gap-4 min-w-[240px]">
          <div className="shrink-0">
             <div className={`w-3 h-3 rounded-full animate-pulse ${credits > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Créditos Diários</span>
              <span className={`text-xs font-mono font-black ${credits > 0 ? 'text-white' : 'text-rose-500'}`}>{credits}/{DAILY_LIMIT}</span>
            </div>
            <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-1000 ${credits > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} 
                style={{ width: `${(credits / DAILY_LIMIT) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex gap-4">
        <button onClick={() => setView('current')} className={`px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${view === 'current' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'bg-slate-900 border border-slate-800 text-slate-500 hover:text-white'}`}>Relatório Atual</button>
        <button onClick={() => setView('history')} className={`px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${view === 'history' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'bg-slate-900 border border-slate-800 text-slate-500 hover:text-white'}`}>Histórico de Auditorias</button>
      </div>

      <div className="min-h-[600px] relative">
        {status === 'processando' ? (
          <div className="bg-slate-900 border border-slate-800 rounded-[48px] p-20 flex flex-col items-center justify-center text-center animate-in fade-in">
            <div className="relative mb-10">
              <div className="w-24 h-24 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <RadarIcon size={32} className="text-emerald-500 animate-pulse" />
              </div>
            </div>
            <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-2">{statusMessage}</h3>
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em]">Varredura em tempo real • {countdown}s restantes</p>
          </div>
        ) : view === 'history' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {history.length === 0 ? (
              <div className="col-span-full py-24 bg-slate-900/20 border-2 border-dashed border-slate-800 rounded-[48px] flex flex-col items-center justify-center text-slate-600">
                <ArchiveIcon size={48} className="mb-4 opacity-10" />
                <p className="text-[10px] font-black uppercase tracking-widest">Nenhuma auditoria arquivada</p>
              </div>
            ) : (
              history.map(rep => (
                <div key={rep.id} className="group bg-slate-900 hover:bg-slate-800 border border-slate-800 p-8 rounded-[40px] flex justify-between items-center transition-all cursor-pointer shadow-xl" onClick={() => { setActiveReport(rep); setView('current'); }}>
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 bg-slate-950 rounded-2xl flex items-center justify-center text-emerald-400 font-mono font-black text-2xl border border-slate-800">{rep.score_dgai}</div>
                    <div>
                      <p className="text-xl font-black text-white">{rep.data_relatorio}</p>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Auditoria DG-AI • Top 40</p>
                    </div>
                  </div>
                  <button onClick={(e) => deleteFromHistory(rep.id, e)} className="p-4 bg-slate-950 hover:bg-rose-900/20 text-slate-600 hover:text-rose-500 rounded-2xl transition-all"><TrashIcon size={20}/></button>
                </div>
              ))
            )}
          </div>
        ) : activeReport ? (
          <div className="space-y-8">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-gradient-to-br from-indigo-900/20 to-emerald-900/20 border border-emerald-500/20 p-6 rounded-[32px] flex items-center gap-4 shadow-xl">
                 <div className="w-14 h-14 bg-emerald-600/20 rounded-2xl flex items-center justify-center text-emerald-400 font-mono font-black text-2xl">{activeReport.score_dgai}</div>
                 <div>
                   <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest mb-1">Score DG-AI</p>
                   <p className="text-xs font-bold text-white uppercase">{activeReport.score_dgai > 50 ? 'Oportuno' : 'Conservador'}</p>
                 </div>
              </div>
              <SummaryCard label="Oportunidade" value={activeReport.resumo.acao_mais_descontada} />
              <SummaryCard label="Maior Ágio" value={activeReport.resumo.acao_mais_cara} />
              <SummaryCard label="Margem Média" value={activeReport.resumo.margem_media} />
              <SummaryCard label="Setor Foco" value={activeReport.resumo.setor_mais_descontado} />
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-[48px] overflow-hidden shadow-2xl">
              <div className="p-8 border-b border-slate-800 bg-slate-800/10 flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <ActivityIcon className="text-emerald-500" />
                  <p className="text-[11px] font-black text-slate-300 uppercase tracking-widest italic">"{activeReport.resumo.texto_informativo}"</p>
                </div>
                <div className="flex gap-4">
                   {pendingRecalc.length > 0 && (
                     <button onClick={handleRecalculateMargins} className="bg-amber-600 hover:bg-amber-500 text-white px-6 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all animate-pulse">Recalcular ({pendingRecalc.length})</button>
                   )}
                   <button onClick={handleGenerate} disabled={credits <= 0} className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white px-8 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all">Nova Auditoria</button>
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-950/40 text-[9px] font-black text-slate-500 uppercase tracking-widest border-b border-slate-800">
                      <th className="px-8 py-6">Ativo / Setor</th>
                      <th className="px-8 py-6">Cotação Atual</th>
                      <th className="px-8 py-6">Preço Teto</th>
                      <th className="px-8 py-6">Margem %</th>
                      <th className="px-8 py-6">DY %</th>
                      <th className="px-8 py-6">P/L</th>
                      <th className="px-8 py-6">P/VP</th>
                      <th className="px-8 py-6 text-right">Classificação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/30">
                    {activeReport.top_40.map((stock) => {
                      const isDirty = pendingRecalc.includes(stock.ativo);
                      const displayPrice = stock.preco_manual || stock.preco_validado;
                      return (
                        <tr key={stock.ativo} className="hover:bg-slate-800/20 transition-colors group">
                          <td className="px-8 py-6">
                            <div className="font-black text-white text-base tracking-tighter uppercase">{stock.ativo}</div>
                            <div className="text-[8px] text-slate-500 font-bold uppercase mt-1 tracking-widest">{stock.setor}</div>
                          </td>
                          <td className="px-8 py-6">
                            {editingStockId === stock.ativo ? (
                              <input 
                                autoFocus 
                                type="number" 
                                step="0.01" 
                                className="bg-slate-950 border border-emerald-500 rounded-lg px-3 py-2 text-xs w-24 text-white font-mono outline-none" 
                                value={tempPrice} 
                                onChange={e => setTempPrice(e.target.value)} 
                                onBlur={() => setManualPricePending(stock.ativo, tempPrice)} 
                                onKeyDown={e => e.key === 'Enter' && setManualPricePending(stock.ativo, tempPrice)} 
                              />
                            ) : (
                              <div className="flex items-center gap-3">
                                <span className={`text-sm font-mono font-black ${stock.preco_manual ? 'text-amber-400' : 'text-slate-300'}`}>R$ {displayPrice.toFixed(2)}</span>
                                <button onClick={() => { setEditingStockId(stock.ativo); setTempPrice(displayPrice.toFixed(2)); }} className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-slate-800 rounded-lg text-slate-500 hover:text-white transition-all"><EditIcon size={12}/></button>
                              </div>
                            )}
                          </td>
                          <td className={`px-8 py-6 font-mono font-black ${isDirty ? 'text-slate-600 italic' : 'text-emerald-400'}`}>
                            {isDirty ? 'Recalcular...' : `R$ ${stock.preco_teto_final.toFixed(2)}`}
                          </td>
                          <td className={`px-8 py-6 font-mono font-black ${isDirty ? 'text-slate-600' : (stock.margem_seguranca > 20 ? 'text-emerald-400' : stock.margem_seguranca > 0 ? 'text-amber-400' : 'text-rose-400')}`}>
                            {isDirty ? '---' : `${stock.margem_seguranca.toFixed(1)}%`}
                          </td>
                          <td className="px-8 py-6 font-mono text-xs text-slate-400">{isDirty ? '---' : `${stock.dividend_yield.toFixed(2)}%`}</td>
                          <td className="px-8 py-6 font-mono text-xs text-slate-400">{isDirty ? '---' : stock.pl.toFixed(1)}</td>
                          <td className="px-8 py-6 font-mono text-xs text-slate-400">{isDirty ? '---' : stock.pvp.toFixed(2)}</td>
                          <td className="px-8 py-6 text-right">
                             <span className={`px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest border border-slate-700 text-slate-300 ${isDirty ? 'opacity-30' : ''}`}>
                               {isDirty ? 'Pendente' : stock.classificacao}
                             </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-[48px] p-24 flex flex-col items-center justify-center text-center shadow-2xl">
             <ShieldIcon size={80} className="text-slate-700 mb-8" />
             <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">Relatório Estratégico B3</h2>
             <p className="text-slate-400 text-sm max-w-md mb-12 leading-relaxed">Extraia o valor intrínseco e múltiplos fundamentalistas em tempo real usando nossa IA Auditada com créditos diários limitados.</p>
             <button 
              onClick={handleGenerate} 
              disabled={credits <= 0}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white px-16 py-6 rounded-[32px] font-black uppercase text-sm tracking-[0.2em] transition-all shadow-2xl shadow-emerald-600/20 active:scale-95"
             >
               {credits > 0 ? 'Gerar Nova Auditoria' : 'Limite Diário Esgotado'}
             </button>
             {credits <= 0 && <p className="text-rose-500 text-[10px] font-black uppercase tracking-widest mt-8">O terminal resetará seus créditos amanhã.</p>}
          </div>
        )}
      </div>
    </div>
  );
};

const SummaryCard = ({ label, value }: { label: string, value: string }) => (
  <div className="bg-slate-900 border border-slate-800 p-6 rounded-[32px] shadow-lg">
     <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">{label}</p>
     <p className="text-xl font-black text-white tracking-tighter truncate">{value}</p>
  </div>
);

export default FundamentalAnalysisIA;
