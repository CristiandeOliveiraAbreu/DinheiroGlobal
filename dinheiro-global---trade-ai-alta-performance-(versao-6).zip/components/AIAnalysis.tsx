
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { analyzeChart } from '../services/gemini';
import { AIAnalysisResult, SavedAnalysis, Asset } from '../types';
import { UploadIcon, BrainIcon, AlertIcon, CheckIcon, SaveIcon, TargetIcon, XIcon, ActivityIcon, BriefcaseIcon, PlusIcon, HistoryIcon } from './Icons';

interface AIAnalysisProps {
  assets: Asset[];
  savedAnalyses: SavedAnalysis[];
  onSaveAnalysis: (analysis: SavedAnalysis) => void;
  onDeleteAnalysis: (id: string) => void;
  onQuickAddAsset: () => void;
}

const DAILY_LIMIT = 10;
const STORAGE_KEY_CREDITS = 'dg_ai_daily_credits';

const AIAnalysis: React.FC<AIAnalysisProps> = ({ assets, savedAnalyses, onSaveAnalysis, onDeleteAnalysis, onQuickAddAsset }) => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AIAnalysisResult | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [processingStep, setProcessingStep] = useState(0);
  const [selectedAsset, setSelectedAsset] = useState('');
  const [isSaved, setIsSaved] = useState(false);
  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [credits, setCredits] = useState(DAILY_LIMIT);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sistema de Gestão de Créditos Diários
  useEffect(() => {
    const today = new Date().toLocaleDateString('pt-BR');
    const stored = localStorage.getItem(STORAGE_KEY_CREDITS);
    
    if (stored) {
      const { date, remaining } = JSON.parse(stored);
      if (date === today) {
        setCredits(remaining);
      } else {
        const newData = { date: today, remaining: DAILY_LIMIT };
        localStorage.setItem(STORAGE_KEY_CREDITS, JSON.stringify(newData));
        setCredits(DAILY_LIMIT);
      }
    } else {
      const newData = { date: today, remaining: DAILY_LIMIT };
      localStorage.setItem(STORAGE_KEY_CREDITS, JSON.stringify(newData));
      setCredits(DAILY_LIMIT);
    }
  }, []);

  const consumeCredit = () => {
    const today = new Date().toLocaleDateString('pt-BR');
    const newRemaining = Math.max(0, credits - 1);
    setCredits(newRemaining);
    localStorage.setItem(STORAGE_KEY_CREDITS, JSON.stringify({ date: today, remaining: newRemaining }));
  };

  const steps = [
    "Mapeando Zonas de Oferta e Demanda...",
    "Localizando Topo/Fundo Institucional Relevante...",
    "Verificando Induções de Liquidez...",
    "Calculando Invalidação da Estrutura...",
    "Validando Relação Risco contra Retorno...",
    "Formatando Relatório de Elite..."
  ];

  useEffect(() => {
    let interval: any;
    if (loading) {
      setProcessingStep(0);
      interval = setInterval(() => {
        setProcessingStep(prev => (prev < steps.length - 1 ? prev + 1 : prev));
      }, 1200);
    } else {
      setProcessingStep(0);
      if (interval) clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const resetAnalysis = () => {
    setResult(null);
    setPreview(null);
    setError(null);
    setSelectedAsset('');
    setIsSaved(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const processAnalysis = useCallback(async (base64: string) => {
    if (credits <= 0) {
      setError("Cota diária de análises esgotada. Retorne amanhã para novos créditos.");
      return;
    }

    setLoading(true); setError(null); setSelectedAsset(''); setIsSaved(false);
    try {
      const analysis = await analyzeChart(base64);
      setResult(analysis);
      consumeCredit();
    } catch (err: any) {
      setError(err.message || "Falha ao analisar a estrutura. Tente novamente.");
      setResult(null); setPreview(null);
    } finally { setLoading(false); }
  }, [credits]);

  const handleImageInput = useCallback((file: File) => {
    if (credits <= 0) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      setPreview(base64String); setResult(null); processAnalysis(base64String);
    };
    reader.readAsDataURL(file);
  }, [processAnalysis, credits]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImageInput(file);
  };

  const handleSave = () => {
    if (!result || !selectedAsset || !preview) return;
    
    const assetNameNormalized = selectedAsset.trim().toUpperCase();
    
    const newSavedAnalysis: SavedAnalysis = {
      id: Math.random().toString(36).substr(2, 9),
      assetName: assetNameNormalized,
      timestamp: Date.now(),
      date: new Date().toLocaleString('pt-BR', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric',
        hour: '2-digit', 
        minute: '2-digit' 
      }),
      image: preview,
      result: result
    };

    onSaveAnalysis(newSavedAnalysis);
    setIsSaved(true);
  };

  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      if (loading || credits <= 0) return;
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf("image") !== -1) {
          const blob = items[i].getAsFile();
          if (blob) { handleImageInput(blob); break; }
        }
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [handleImageInput, loading, credits]);

  const getStatusColor = (status: string) => {
    if (status === 'ALTA') return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
    if (status === 'BAIXA') return 'text-rose-400 bg-rose-500/10 border-rose-500/20';
    if (status === 'ROMPIMENTO') return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
    return 'text-slate-400 bg-slate-800 border-slate-700';
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-left space-y-1">
          <h1 className="text-2xl font-black flex items-center gap-3 uppercase tracking-tighter text-white">
            <BrainIcon className="text-emerald-500" size={28} />
            Análise Técnica IA
          </h1>
          <p className="text-slate-500 text-[11px] font-black uppercase tracking-[0.3em]">IA Conectada • Mapeamento Institucional</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 px-6 py-3 rounded-[24px] shadow-lg flex items-center gap-4 min-w-[240px]">
          <div className="shrink-0">
             <div className={`w-3 h-3 rounded-full animate-pulse ${credits > 5 ? 'bg-emerald-500' : credits > 2 ? 'bg-amber-500' : 'bg-rose-500'}`}></div>
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Créditos Operacionais</span>
              <span className={`text-xs font-mono font-black ${credits > 0 ? 'text-white' : 'text-rose-500'}`}>{credits}/{DAILY_LIMIT}</span>
            </div>
            <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-1000 ${credits > 5 ? 'bg-emerald-500' : credits > 2 ? 'bg-amber-500' : 'bg-rose-500'}`} 
                style={{ width: `${(credits / DAILY_LIMIT) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>
      </header>

      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 p-5 rounded-[32px] flex items-center gap-4 animate-in shake duration-500">
          <div className="w-10 h-10 bg-rose-500/20 rounded-xl flex items-center justify-center text-rose-500 shrink-0">
            <AlertIcon size={20} />
          </div>
          <p className="text-[12px] text-rose-400 font-bold uppercase tracking-widest leading-relaxed">
            {error}
          </p>
          {credits <= 0 && (
            <div className="ml-auto text-[9px] font-black bg-rose-500/20 text-rose-500 px-3 py-1 rounded-full uppercase">Cota Esgotada</div>
          )}
        </div>
      )}

      {!error && (
        <div className="bg-slate-900/40 border border-emerald-500/10 p-5 rounded-[32px] flex items-center gap-5 shadow-lg">
          <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-500 shrink-0">
            <AlertIcon size={20} />
          </div>
          <p className="text-[12px] text-slate-300 font-medium leading-relaxed">
            <span className="text-emerald-400 font-black uppercase tracking-widest text-[10px] mr-2">Diretriz de Elite:</span>
            Priorize <span className="text-white font-bold">Semanal, Diário e 4H</span>. O foco é decodificar o <span className="text-emerald-400/80 underline decoration-emerald-500/30 underline-offset-4">fluxo de ordens macro</span>.
          </p>
        </div>
      )}

      <div className="grid lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-4 space-y-4 sticky top-12">
          <div 
            className={`group relative aspect-[4/5] bg-slate-900/60 border-2 border-dashed rounded-[40px] flex flex-col items-center justify-center transition-all overflow-hidden shadow-2xl 
              ${credits > 0 ? 'border-slate-800' : 'border-rose-900/30 opacity-50 cursor-not-allowed'}
              ${!loading && !preview && credits > 0 ? 'cursor-pointer hover:border-emerald-500/40' : ''}`}
            onClick={() => !loading && !preview && credits > 0 && fileInputRef.current?.click()}
          >
            {preview ? (
              <div className="relative w-full h-full p-4 flex items-center justify-center bg-slate-950">
                <img src={preview} alt="Gráfico" className={`max-w-full max-h-full object-contain cursor-zoom-in transition-all duration-700 ${loading ? 'opacity-20 blur-md grayscale' : 'opacity-100'}`} onClick={(e) => { e.stopPropagation(); if(!loading) setIsZoomOpen(true); }} />
                {loading && <div className="animate-scan z-10"></div>}
                {!loading && (
                  <button onClick={(e) => { e.stopPropagation(); setIsZoomOpen(true); }} className="absolute bottom-6 right-6 p-3 bg-slate-900/90 backdrop-blur-md border border-slate-700 text-slate-200 rounded-2xl opacity-0 group-hover:opacity-100 transition-all flex items-center gap-2">
                    <TargetIcon size={16} /><span className="text-[9px] font-black uppercase tracking-widest px-1">Lupa de Alta Precisão</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="text-center p-8">
                <div className={`inline-flex p-6 rounded-3xl mb-4 group-hover:scale-110 transition-transform ${credits > 0 ? 'bg-slate-800/50' : 'bg-rose-900/20'}`}>
                  <UploadIcon className={credits > 0 ? "text-emerald-500" : "text-rose-500/50"} size={32} />
                </div>
                <p className={`font-black text-sm uppercase tracking-widest ${credits > 0 ? 'text-slate-400' : 'text-rose-500/50'}`}>
                  {credits > 0 ? 'Importar Captura de Tela' : 'Sistema Bloqueado'}
                </p>
                <p className="text-slate-600 text-[9px] mt-4 uppercase tracking-[0.2em] font-black">
                  {credits > 0 ? 'Arraste ou cole (CTRL+V)' : 'Limite diário atingido'}
                </p>
              </div>
            )}
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileUpload} disabled={credits <= 0} />
          </div>

          {!loading && result && (
            <div className={`bg-slate-900/60 border border-slate-800 p-6 rounded-[32px] space-y-4 animate-in fade-in slide-in-from-top-4 duration-500`}>
              <div className="space-y-2">
                <div className="flex justify-between items-center mb-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Vincular ao Ativo</label>
                  {!isSaved && (
                    <button onClick={onQuickAddAsset} className="text-[9px] font-black text-emerald-500 hover:text-white uppercase tracking-widest flex items-center gap-1 transition-colors">
                      <PlusIcon size={10} /> Novo Ativo
                    </button>
                  )}
                </div>
                <select 
                  disabled={isSaved}
                  value={selectedAsset}
                  onChange={e => setSelectedAsset(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 focus:ring-1 focus:ring-emerald-500/50 outline-none text-white text-[11px] font-black uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <option value="">BUSCAR ATIVO NA LISTA...</option>
                  {assets.map(a => <option key={a.id} value={a.name}>{a.name}</option>)}
                </select>
              </div>

              {!isSaved ? (
                <button disabled={!selectedAsset} onClick={handleSave} className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl shadow-emerald-600/10">
                  <SaveIcon size={16} /> Arquivar no Dossiê de Ativos
                </button>
              ) : (
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-center gap-2 bg-emerald-500/10 border border-emerald-500/20 py-3 rounded-xl">
                    <CheckIcon size={14} className="text-emerald-500" />
                    <span className="text-[10px] text-emerald-400 font-black uppercase tracking-widest">Estudo Vinculado</span>
                  </div>
                  <div className="grid grid-cols-1 gap-2">
                    <button 
                      onClick={resetAnalysis}
                      disabled={credits <= 0}
                      className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-black text-[10px] uppercase tracking-[0.15em] flex items-center justify-center gap-2 transition-all disabled:opacity-30"
                    >
                      <PlusIcon size={14} /> Iniciar Nova Varredura
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="lg:col-span-8 min-h-[600px] relative">
          {loading && (
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xl z-30 flex flex-col items-center justify-center rounded-[48px] p-12 text-center animate-in fade-in duration-300">
              <div className="relative mb-8">
                <div className="w-20 h-20 border-t-2 border-emerald-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <BrainIcon className="text-emerald-500 animate-pulse" size={32} />
                </div>
              </div>
              <p className="text-emerald-400 font-black tracking-[0.3em] text-[11px] uppercase animate-pulse">{steps[processingStep]}</p>
            </div>
          )}

          {!result && !loading && (
            <div className="h-full bg-slate-900/20 border border-slate-800 border-dashed rounded-[48px] flex flex-col items-center justify-center p-12 text-slate-600">
               <ActivityIcon size={48} className="mb-4 opacity-10" />
               <p className="text-[10px] font-black uppercase tracking-[0.3em]">
                 {credits > 0 ? 'Aguardando fluxo visual de dados...' : 'Cota de processamento esgotada.'}
               </p>
            </div>
          )}

          {result && !loading && (
            <div className="bg-slate-900 border border-slate-800 rounded-[48px] overflow-hidden shadow-2xl animate-in fade-in slide-in-from-right-10 duration-700">
              <div className="p-8 bg-slate-800/20 border-b border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Pilar Estrutural</p>
                  <div className={`px-4 py-1.5 rounded-full inline-block text-[11px] font-black tracking-widest border ${getStatusColor(result.structureStatus)}`}>
                    {result.structureStatus === 'ALTA' ? 'TENDÊNCIA DE ALTA' : result.structureStatus === 'BAIXA' ? 'TENDÊNCIA DE BAIXA' : result.structureStatus}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">Índice de Assertividade</p>
                  <div className="flex items-center gap-3">
                    <span className={`text-4xl font-black tracking-tighter ${result.confidence > 75 ? 'text-emerald-400' : 'text-amber-400'}`}>{result.confidence}%</span>
                    <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div className={`h-full transition-all duration-1000 ${result.confidence > 75 ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${result.confidence}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-8 space-y-10">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <ReportMetric label="Viés de Execução" value={result.direction} subValue={result.trendContext} color={result.direction === 'COMPRA' ? 'text-emerald-400' : result.direction === 'VENDA' ? 'text-rose-400' : 'text-amber-400'} />
                  <ReportMetric label="Perfil de Volatilidade" value={result.volatility} subValue="Oscilação do Ativo" />
                  <ReportMetric label="Risco Projetado (0-10)" value={result.riskScore.toString()} subValue="Exposição Estrutural" color={result.riskScore < 4 ? 'text-emerald-400' : 'text-rose-400'} />
                </div>

                <div className="bg-slate-950/80 border border-slate-800 p-8 rounded-[40px] text-center relative group overflow-hidden">
                  <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-emerald-500 group-hover:scale-110 transition-transform"><TargetIcon size={120}/></div>
                  <p className="text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] mb-2">Ponto de Interesse (Institucional)</p>
                  <p className="text-5xl font-mono font-black text-white tracking-tighter">{result.entryRegion}</p>
                  <div className="mt-6 flex justify-center gap-6">
                    <div className="text-center">
                      <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Invalidação (Stop)</p>
                      <p className="text-sm font-mono font-black text-rose-500/70">{result.stopLoss.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Expansão (Alvo)</p>
                      <p className="text-sm font-mono font-black text-emerald-500/70">{result.takeProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-8 pt-4 border-t border-slate-800/50">
                  <div className="space-y-4">
                    <h4 className="text-[11px] font-black text-white uppercase tracking-widest flex items-center gap-2">
                      <BriefcaseIcon size={14} className="text-emerald-500" /> Racional Técnico
                    </h4>
                    <p className="text-[13px] text-slate-400 leading-relaxed font-medium">
                      {result.reasoning}
                    </p>
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-[11px] font-black text-white uppercase tracking-widest flex items-center gap-2">
                      <AlertIcon size={14} className="text-amber-500" /> Protocolo de Segurança
                    </h4>
                    <p className="text-[13px] text-slate-400 leading-relaxed font-medium">
                      {result.riskMitigation}
                    </p>
                    {result.trendAlert && (
                      <div className="mt-4 p-4 bg-rose-500/5 border border-rose-500/10 rounded-2xl">
                        <p className="text-[10px] font-black text-rose-400 uppercase tracking-widest mb-1 flex items-center gap-2">
                          <ActivityIcon size={10} /> Alerta Estrutural
                        </p>
                        <p className="text-[12px] text-rose-300/80 font-bold">{result.trendAlert}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {isZoomOpen && preview && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-2xl animate-in fade-in duration-300">
          <button onClick={() => setIsZoomOpen(false)} className="absolute top-8 right-8 p-4 bg-slate-900 hover:bg-slate-800 rounded-full text-white transition-all shadow-2xl border border-slate-700">
            <XIcon size={24} />
          </button>
          <img src={preview} alt="Gráfico Ampliado" className="max-w-full max-h-[90vh] object-contain shadow-[0_0_100px_rgba(0,0,0,0.5)] rounded-2xl" />
        </div>
      )}
    </div>
  );
};

interface ReportMetricProps { label: string; value: string; subValue: string; color?: string; }
const ReportMetric: React.FC<ReportMetricProps> = ({ label, value, subValue, color = "text-white" }) => (
  <div className="bg-slate-950/40 border border-slate-800/60 p-5 rounded-[28px] hover:border-slate-700 transition-colors">
    <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">{label}</p>
    <p className={`text-xl font-black tracking-tight ${color}`}>{value}</p>
    <p className="text-[10px] text-slate-600 font-bold uppercase mt-1 tracking-widest">{subValue}</p>
  </div>
);

export default AIAnalysis;
