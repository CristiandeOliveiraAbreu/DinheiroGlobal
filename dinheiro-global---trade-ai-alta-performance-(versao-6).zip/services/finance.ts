
import { GoogleGenAI } from "@google/genai";

const CACHE_KEY = "usd_brl_rate_cache_v4";
const CACHE_TTL = 60 * 60 * 1000; // 1 Hora de Cache para estabilidade operacional

interface RateCache {
  rate: number;
  timestamp: number;
}

export const getUSDBRLRate = async (): Promise<number> => {
  // 1. Verificação imediata do Cache
  try {
    const cachedData = localStorage.getItem(CACHE_KEY);
    if (cachedData) {
      const { rate, timestamp }: RateCache = JSON.parse(cachedData);
      if (Date.now() - timestamp < CACHE_TTL) return rate;
    }
  } catch (e) {}

  // 2. Busca IA (Background ou Falha silenciosa)
  if (!process.env.API_KEY) return 5.80;

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Retorne apenas o número decimal atual do par USD/BRL comercial.",
      config: { 
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 0 }
      },
    });

    const match = response.text?.match(/\d+([.,]\d+)?/);
    if (match) {
      const rate = parseFloat(match[0].replace(',', '.'));
      if (rate > 2 && rate < 15) {
        localStorage.setItem(CACHE_KEY, JSON.stringify({ rate, timestamp: Date.now() }));
        return rate;
      }
    }
  } catch (error) {
    console.warn("Utilizando fallback de câmbio devido a erro de rede/quota.");
  }

  // 3. Fallback absoluto
  return 5.85; 
};
