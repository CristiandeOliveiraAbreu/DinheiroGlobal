
import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult, DiaryEntry } from "../types";

const getAIClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeChart = async (imageBase64: string): Promise<AIAnalysisResult> => {
  const ai = getAIClient();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: imageBase64.split(',')[1] || imageBase64 } },
          { text: "Analise a estrutura de mercado macro (SMC). Identifique tendência, zonas de oferta/demanda e risco. Retorne em JSON." }
        ],
      },
      config: {
        thinkingConfig: { thinkingBudget: 4000 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            direction: { type: Type.STRING, enum: ["COMPRA", "VENDA", "NEUTRO", "AGUARDAR"] },
            entryRegion: { type: Type.STRING },
            maxSafeBoundary: { type: Type.NUMBER },
            stopLoss: { type: Type.NUMBER },
            takeProfit: { type: Type.NUMBER },
            confidence: { type: Type.NUMBER },
            reasoning: { type: Type.STRING },
            volatility: { type: Type.STRING, enum: ["BAIXA", "MÉDIA", "ALTA"] },
            riskScore: { type: Type.NUMBER },
            riskMitigation: { type: Type.STRING },
            structureStatus: { type: Type.STRING, enum: ["ALTA", "BAIXA", "LATERAL", "EXAUSTÃO", "ROMPIMENTO"] },
            trendContext: { type: Type.STRING },
            trendAlert: { type: Type.STRING }
          },
          required: ["direction", "entryRegion", "maxSafeBoundary", "stopLoss", "takeProfit", "confidence", "reasoning", "volatility", "riskScore", "riskMitigation", "structureStatus", "trendContext"]
        },
      },
    });
    return JSON.parse(response.text || "{}");
  } catch (error: any) {
    console.error("Erro na análise Gemini:", error);
    throw new Error(error?.status === 429 ? "Limite de quota atingido." : "Falha na análise técnica.");
  }
};
