
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://puyunwngoskjhasxjpho.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB1eXVud25nb3Nramhhc3hqcGhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA1MjUyODksImV4cCI6MjA4NjEwMTI4OX0.ZoLNEsTfyE5Rf5s7G5PGPo8UcQezr6omaFEyjxUg0Ko';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * Realiza o upload de uma imagem em base64 para o bucket do Supabase Storage.
 * Retorna a URL pública da imagem.
 */
export const uploadImage = async (bucket: string, path: string, base64: string) => {
  try {
    const base64Data = base64.includes(',') ? base64.split(',')[1] : base64;
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'image/jpeg' });

    const { data, error } = await supabase.storage.from(bucket).upload(path, blob, {
      upsert: true,
      contentType: 'image/jpeg'
    });

    if (error) throw error;
    
    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(data.path);
    return urlData.publicUrl;
  } catch (error) {
    console.error('[Supabase Storage] Erro:', error);
    return null;
  }
};
