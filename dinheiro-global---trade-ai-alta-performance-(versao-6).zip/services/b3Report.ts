
import { GoogleGenAI, Type } from "@google/genai";
import { B3WeeklyReport, ReportStatus, B3StockData } from "../types";

export const generateB3ReportAsync = async (
  onProgress: (prog: number, status: ReportStatus, message?: string) => void
): Promise<B3WeeklyReport> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  onProgress(5, 'processando', 'Iniciando terminal de auditoria...');

  const prompt = `Você é o Analista Senior DG-AI v4.5. Sua tarefa é gerar um Relatório Fundamentalista Estratégico das 40 ações mais relevantes da B3.

  DIRETRIZES DE PROCESSAMENTO:
  1. BUSCA (FONTE YAHOO): Realize busca em tempo real pelas cotações atuais via Yahoo Finance.
  2. SELEÇÃO: Inclua Blue Chips (VALE3, PETR4, Bancos) e Mid Caps relevantes (IDIV/IBOV).
  3. VALUATION (MÉDIA PONDERADA): Calcule o Preço Teto usando a média de:
     - Graham: sqrt(22.5 * LPA * VPA)
     - Décio Bazin (DY 6%)
     - Fluxo de Caixa Descontado simplificado
  4. SEGURANÇA: Aplique margem de conservadorismo de 15% sobre o valor justo calculado.

  REGRAS DE RESPOSTA:
  - Retorne APENAS o JSON.
  - Se os dados de algum ticker falharem, use a última cotação conhecida e marque "validacao_info" como "Estimado/Fallback".
  - Ordene por Classificação (Excelente > Boa > Neutra > Cara).`;

  try {
    onProgress(20, 'processando', 'Sincronizando com Yahoo Finance e Google Search...');
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score_dgai: { type: Type.INTEGER },
            top_40: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  ranking: { type: Type.INTEGER },
                  ativo: { type: Type.STRING },
                  setor: { type: Type.STRING },
                  preco_validado: { type: Type.NUMBER },
                  validacao_info: { type: Type.STRING },
                  preco_teto_final: { type: Type.NUMBER },
                  margem_seguranca: { type: Type.NUMBER },
                  pl: { type: Type.NUMBER },
                  pvp: { type: Type.NUMBER },
                  dividend_yield: { type: Type.NUMBER },
                  classificacao: { type: Type.STRING, enum: ["Excelente", "Boa", "Neutra", "Cara"] },
                  status_cor: { type: Type.STRING, enum: ["Verde", "Amarelo", "Vermelho"] },
                  data_atualizacao: { type: Type.STRING }
                },
                required: ["ativo", "preco_validado", "preco_teto_final", "classificacao"]
              }
            },
            resumo: {
              type: Type.OBJECT,
              properties: {
                acao_mais_descontada: { type: Type.STRING },
                acao_mais_cara: { type: Type.STRING },
                margem_media: { type: Type.STRING },
                setor_mais_descontado: { type: Type.STRING },
                texto_informativo: { type: Type.STRING }
              }
            }
          }
        }
      }
    });

    onProgress(80, 'processando', 'Validando integridade dos cálculos de valuation...');

    const text = response.text;
    if (!text) throw new Error("A IA retornou um corpo de resposta vazio.");
    
    const rawData = JSON.parse(text);
    onProgress(100, 'concluído', 'Relatório gerado com sucesso!');
    
    return {
      id: `fast_b3_${Date.now()}`,
      data_relatorio: new Date().toLocaleDateString('pt-BR'),
      timestamp: Date.now(),
      status: 'concluído',
      progresso: 100,
      mode: 'MODO_RAPIDO',
      score_dgai: rawData.score_dgai,
      top_40: rawData.top_40,
      resumo: rawData.resumo
    };
  } catch (error: any) {
    console.error("Erro na geração do relatório B3:", error);
    onProgress(0, 'erro', error.message || 'Erro desconhecido na API de Inteligência.');
    throw error;
  }
};
